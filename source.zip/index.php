<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4df64db6b             |
    |_______________________________________|
*/
 use Pmpr\Common\Foundation\Foundation; if (!function_exists("\160\162\x5f\x67\x65\164\137\x66\x6f\x75\x6e\144\x61\164\151\x6f\x6e")) { function pr_get_foundation() : Foundation { return Foundation::symcgieuakksimmu(); } } if (!function_exists("\x70\155\160\162\x5f\x61\160\x70\x6c\171\x5f\146\151\x6c\164\x65\x72")) { function pmpr_apply_filters($iaakskwmyqceoscy, ...$ywmkwiwkosakssii) { return pr_get_foundation()->caokeucsksukesyo()->mmsykuomogaqoaye()->ocksiywmkyaqseou($iaakskwmyqceoscy, ...$ywmkwiwkosakssii); } } if (!function_exists("\x70\155\160\x72\137\144\x6f\137\x61\x63\x74\x69\157\x6e")) { function pmpr_do_action($iaakskwmyqceoscy, ...$ywmkwiwkosakssii) { pr_get_foundation()->caokeucsksukesyo()->mmsykuomogaqoaye()->ewcsyqaaigkicgse($iaakskwmyqceoscy, ...$ywmkwiwkosakssii); } } pr_get_foundation();
