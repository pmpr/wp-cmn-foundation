<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670e55c403173             |
    |_______________________________________|
*/
 use Pmpr\Common\Foundation\Foundation; if (!function_exists("\x70\x72\x5f\147\x65\164\x5f\x66\x6f\x75\x6e\144\x61\164\151\x6f\156")) { function pr_get_foundation() : Foundation { return Foundation::symcgieuakksimmu(); } } if (!function_exists("\160\155\160\x72\137\x61\x70\160\x6c\171\x5f\x66\151\154\x74\145\x72")) { function pmpr_apply_filters($iaakskwmyqceoscy, ...$ywmkwiwkosakssii) { return pr_get_foundation()->caokeucsksukesyo()->mmsykuomogaqoaye()->ocksiywmkyaqseou($iaakskwmyqceoscy, ...$ywmkwiwkosakssii); } } if (!function_exists("\160\x6d\x70\x72\x5f\x64\157\137\x61\x63\164\151\x6f\156")) { function pmpr_do_action($iaakskwmyqceoscy, ...$ywmkwiwkosakssii) { pr_get_foundation()->caokeucsksukesyo()->mmsykuomogaqoaye()->ewcsyqaaigkicgse($iaakskwmyqceoscy, ...$ywmkwiwkosakssii); } } pr_get_foundation();
