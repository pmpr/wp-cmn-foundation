<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             692d5cd12ed82             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Interfaces\Constants; class TaxonomyFilter extends AbstractFilter { public function ikcgmcycisiccyuc() { $this->type = Constants::gmmygyiecgmggaam; } function egkeamycaysqsoma(array $tsuauommsquiesmk, $gqgemcmoicmgaqie, $eqgoocgaqwqcimie) { } }
