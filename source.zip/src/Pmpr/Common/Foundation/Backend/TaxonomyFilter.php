<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             699992793a35d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Interfaces\Constants; class TaxonomyFilter extends AbstractFilter { public function ikcgmcycisiccyuc() { $this->type = Constants::gmmygyiecgmggaam; } function egkeamycaysqsoma(array $tsuauommsquiesmk, $gqgemcmoicmgaqie, $eqgoocgaqwqcimie) { } }
