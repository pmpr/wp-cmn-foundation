<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             69a0a1216424e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Interfaces\Constants; class TaxonomyFilter extends AbstractFilter { public function ikcgmcycisiccyuc() { $this->type = Constants::gmmygyiecgmggaam; } function egkeamycaysqsoma(array $tsuauommsquiesmk, $gqgemcmoicmgaqie, $eqgoocgaqwqcimie) { } }
