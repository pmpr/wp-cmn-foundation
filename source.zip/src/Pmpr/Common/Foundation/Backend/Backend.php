<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebdb08957             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\155\x69\156\137\x66\x6f\157\x74\145\162", [$this, "\147\147\x73\x6b\x63\x67\x67\141\x61\x65\x61\153\147\141\x71\143"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\146\157\165\156\x64\141\x74\x69\157\x6e\x5f\x62\x61\143\x6b\x65\x6e\x64\137\x67\x65\156\145\162\x61\x74\145\x5f\x6d\x6f\144\x61\x6c\x5f\141\143\x74\151\157\x6e", [$this, "\x69\x67\x69\x61\x77\x6b\157\x71\x69\157\147\x6f\143\x73\141\165"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\160\162\137\x67\145\x6e\x65\162\x61\x6c"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
