<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e16aefd43f6             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\x64\x6d\x69\156\137\146\157\157\x74\145\162", [$this, "\x67\147\163\153\x63\147\x67\x61\x61\x65\x61\x6b\147\x61\x71\x63"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\146\157\165\x6e\144\x61\164\x69\157\156\137\142\x61\143\153\x65\x6e\x64\x5f\147\145\156\x65\x72\141\164\145\x5f\155\157\x64\141\154\137\x61\x63\164\151\x6f\156", [$this, "\151\147\151\141\167\153\157\161\x69\x6f\x67\157\143\x73\x61\165"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\160\162\137\x67\x65\x6e\x65\162\x61\x6c"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
