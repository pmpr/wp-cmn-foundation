<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67abce98c052e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Container\Container; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\x64\x6d\x69\156\137\146\157\x6f\x74\145\162", [$this, "\147\147\163\153\143\147\x67\141\x61\145\141\x6b\x67\141\x71\143"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x66\157\165\156\x64\x61\164\x69\157\x6e\x5f\x62\141\143\153\x65\156\144\x5f\x67\x65\156\145\x72\x61\164\x65\x5f\x6d\157\x64\141\154\x5f\x61\x63\164\151\x6f\156", [$this, "\x69\x67\151\x61\x77\x6b\x6f\161\151\x6f\147\157\x63\x73\141\x75"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\160\162\137\147\145\x6e\x65\162\x61\154"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
