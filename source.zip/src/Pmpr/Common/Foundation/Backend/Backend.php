<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ced75618540             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\155\x69\x6e\137\x66\x6f\x6f\164\x65\162", [$this, "\x67\x67\x73\x6b\x63\x67\x67\x61\x61\145\x61\153\x67\141\x71\x63"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x66\157\165\156\144\141\164\x69\157\x6e\x5f\x62\x61\143\x6b\145\156\144\x5f\x67\145\156\145\x72\x61\x74\x65\137\155\x6f\144\141\x6c\137\141\143\164\151\157\x6e", [$this, "\x69\x67\151\141\x77\x6b\x6f\x71\151\157\147\x6f\143\x73\x61\165"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\160\x72\137\x67\145\156\x65\162\x61\154"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
