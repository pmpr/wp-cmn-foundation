<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec0c5dc5dae             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\x64\155\151\156\137\x66\x6f\x6f\164\145\162", [$this, "\147\x67\x73\153\143\x67\x67\x61\141\145\141\153\147\141\161\x63"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x66\157\165\x6e\144\141\x74\x69\x6f\156\137\x62\x61\x63\153\145\156\144\137\147\x65\156\x65\162\141\164\x65\x5f\x6d\157\x64\x61\154\137\141\x63\164\x69\157\x6e", [$this, "\151\147\x69\141\x77\153\157\161\x69\x6f\147\x6f\143\163\x61\x75"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\160\162\x5f\x67\x65\x6e\x65\162\x61\154"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
