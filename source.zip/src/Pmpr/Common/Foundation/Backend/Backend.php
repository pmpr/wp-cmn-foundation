<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec08eec428e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\x64\x6d\151\156\137\x66\157\x6f\164\x65\162", [$this, "\x67\x67\x73\153\143\x67\147\141\x61\x65\141\x6b\147\141\161\x63"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x66\157\x75\156\144\141\164\151\x6f\x6e\x5f\142\x61\x63\x6b\x65\156\144\x5f\147\x65\156\145\162\x61\164\145\x5f\x6d\157\144\141\x6c\x5f\141\143\x74\x69\x6f\156", [$this, "\151\147\x69\141\167\153\x6f\x71\151\157\x67\x6f\x63\x73\x61\165"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\160\162\x5f\x67\145\x6e\145\162\x61\154"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
