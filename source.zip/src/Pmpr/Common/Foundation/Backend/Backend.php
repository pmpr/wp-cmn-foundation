<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f6b04b9a178             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\x64\155\151\156\x5f\146\157\157\164\x65\x72", [$this, "\x67\x67\163\x6b\x63\x67\x67\141\x61\x65\x61\153\147\x61\161\x63"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\146\x6f\x75\x6e\x64\x61\164\x69\x6f\x6e\x5f\142\141\143\x6b\145\x6e\x64\137\147\x65\x6e\x65\x72\x61\x74\x65\x5f\x6d\x6f\144\141\154\x5f\141\x63\164\x69\157\x6e", [$this, "\x69\x67\151\141\x77\x6b\x6f\x71\x69\157\x67\157\x63\163\141\165"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\x70\162\137\147\x65\156\145\x72\x61\x6c"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
