<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678d3d485c530             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Container\Container; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\155\x69\156\137\146\x6f\x6f\164\x65\x72", [$this, "\147\147\163\153\143\147\147\141\x61\145\x61\153\147\x61\x71\x63"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\146\157\165\156\x64\141\164\x69\157\156\x5f\x62\x61\143\153\145\156\x64\x5f\x67\145\x6e\145\x72\x61\164\x65\x5f\x6d\157\x64\x61\x6c\137\141\x63\x74\x69\x6f\156", [$this, "\151\x67\151\x61\167\153\157\x71\x69\157\147\x6f\x63\x73\141\165"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\x70\x72\x5f\x67\x65\x6e\145\x72\141\x6c"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
