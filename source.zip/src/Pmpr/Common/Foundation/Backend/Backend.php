<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1e2ec7c9c7             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\x6d\151\156\x5f\x66\157\x6f\x74\145\162", [$this, "\147\147\163\153\x63\x67\x67\x61\x61\x65\141\x6b\x67\141\x71\143"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\146\x6f\165\156\x64\x61\x74\x69\x6f\x6e\137\x62\x61\143\153\145\x6e\x64\137\147\145\156\145\162\x61\164\145\x5f\155\157\144\141\x6c\x5f\141\x63\x74\x69\157\156", [$this, "\x69\147\151\141\167\x6b\157\x71\x69\x6f\x67\x6f\143\163\141\x75"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\x70\x72\137\147\145\156\145\162\x61\154"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
