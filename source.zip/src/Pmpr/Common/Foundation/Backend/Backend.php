<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cf4bac87f58             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\x64\x6d\151\156\x5f\x66\x6f\x6f\164\145\162", [$this, "\x67\x67\163\153\x63\x67\x67\141\x61\145\141\153\147\x61\x71\x63"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\146\x6f\165\x6e\x64\x61\164\x69\x6f\x6e\137\x62\141\x63\153\x65\x6e\x64\137\x67\x65\156\x65\162\141\164\145\137\155\157\144\x61\x6c\x5f\x61\x63\x74\151\157\156", [$this, "\151\x67\151\141\167\x6b\157\x71\151\x6f\x67\157\143\x73\x61\x75"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\160\x72\137\147\145\x6e\x65\x72\141\x6c"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
