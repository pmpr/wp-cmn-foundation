<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67abd9c8f1e03             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Container\Container; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\155\x69\156\x5f\x66\x6f\157\164\x65\162", [$this, "\147\x67\x73\x6b\x63\147\x67\141\x61\145\x61\x6b\147\x61\x71\143"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\146\x6f\165\x6e\x64\x61\164\151\157\x6e\x5f\142\x61\x63\153\x65\x6e\x64\137\147\145\156\145\x72\141\164\x65\137\x6d\x6f\x64\141\154\137\x61\x63\164\151\x6f\x6e", [$this, "\x69\147\x69\141\x77\x6b\157\161\x69\x6f\147\157\143\x73\141\x75"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\x70\162\x5f\x67\145\156\x65\162\x61\154"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
