<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f27b578294c             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\155\151\x6e\x5f\x66\x6f\x6f\164\145\162", [$this, "\x67\147\163\x6b\x63\x67\x67\141\x61\145\141\x6b\x67\141\161\143"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x66\x6f\165\156\144\141\x74\x69\157\x6e\x5f\x62\141\143\153\145\156\144\x5f\147\145\156\x65\x72\x61\164\145\x5f\155\157\144\x61\154\x5f\x61\x63\164\151\x6f\156", [$this, "\x69\147\x69\x61\167\153\157\x71\x69\157\x67\x6f\x63\x73\141\165"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\x70\162\x5f\x67\x65\x6e\145\162\x61\154"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
