<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ebe0a571651             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\x6d\x69\x6e\x5f\146\157\x6f\x74\145\162", [$this, "\x67\147\163\153\143\147\x67\x61\x61\145\x61\153\147\x61\161\x63"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x66\x6f\x75\156\x64\141\164\151\x6f\156\x5f\x62\141\x63\x6b\145\x6e\x64\137\x67\x65\156\145\x72\x61\164\x65\137\155\x6f\144\141\x6c\x5f\x61\x63\164\151\157\156", [$this, "\x69\147\x69\141\167\153\x6f\161\x69\157\147\x6f\143\x73\141\165"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\x70\162\137\147\145\156\x65\162\x61\x6c"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
