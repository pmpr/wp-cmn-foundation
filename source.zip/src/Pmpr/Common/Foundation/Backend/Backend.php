<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f43a7ad132d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\155\x69\156\x5f\x66\157\x6f\164\145\162", [$this, "\x67\147\163\153\x63\x67\147\x61\141\145\141\153\147\141\x71\x63"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x66\x6f\x75\156\x64\x61\x74\x69\157\x6e\137\142\x61\x63\x6b\145\156\144\137\147\x65\156\145\162\x61\164\x65\137\155\x6f\x64\x61\154\137\x61\143\x74\x69\157\156", [$this, "\151\x67\x69\x61\167\x6b\157\161\x69\x6f\147\157\143\163\x61\165"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\x70\162\137\147\145\156\145\x72\141\x6c"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
