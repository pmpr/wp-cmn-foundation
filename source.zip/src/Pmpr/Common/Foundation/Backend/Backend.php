<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d1dbc474879             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\x64\x6d\x69\x6e\x5f\146\157\x6f\164\145\162", [$this, "\147\147\163\153\x63\147\147\x61\x61\145\x61\x6b\x67\141\161\143"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\146\157\165\x6e\x64\x61\x74\151\157\x6e\137\142\x61\143\153\145\156\144\x5f\147\x65\156\145\x72\141\164\145\137\x6d\157\x64\141\x6c\137\141\143\x74\x69\157\x6e", [$this, "\151\x67\151\141\167\153\157\x71\151\x6f\x67\157\x63\x73\x61\165"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\160\162\x5f\147\x65\x6e\145\162\141\154"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
