<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce6343424e0             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\x64\x6d\x69\x6e\x5f\146\x6f\x6f\x74\x65\162", [$this, "\147\147\x73\153\x63\147\x67\141\x61\145\141\153\147\x61\161\143"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\146\157\165\156\x64\141\164\x69\157\x6e\137\x62\x61\143\153\x65\x6e\x64\x5f\x67\x65\x6e\x65\162\x61\x74\x65\x5f\155\x6f\144\141\x6c\137\x61\143\164\x69\157\156", [$this, "\151\x67\151\x61\x77\153\157\x71\x69\x6f\147\x6f\x63\163\x61\x75"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\160\162\137\147\x65\156\145\x72\x61\154"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
