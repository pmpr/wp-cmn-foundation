<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716d8b4c5936             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Container\Container; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\x64\155\151\x6e\137\146\x6f\x6f\x74\145\x72", [$this, "\147\147\x73\153\x63\147\x67\x61\x61\x65\x61\x6b\x67\141\161\x63"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\146\x6f\x75\x6e\x64\141\164\x69\157\x6e\137\x62\x61\143\153\x65\156\144\137\147\145\156\145\162\x61\164\x65\137\155\157\x64\x61\154\x5f\141\143\x74\151\157\x6e", [$this, "\x69\x67\x69\141\167\153\157\x71\x69\157\147\157\x63\x73\141\165"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\160\x72\137\147\x65\x6e\145\162\141\x6c"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
