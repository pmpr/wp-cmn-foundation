<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce54af64690             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\155\151\x6e\137\146\157\157\x74\145\162", [$this, "\x67\147\x73\153\x63\147\147\141\x61\145\141\x6b\147\x61\161\x63"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x66\x6f\x75\x6e\x64\x61\164\151\157\x6e\x5f\x62\x61\x63\x6b\145\x6e\x64\x5f\x67\x65\x6e\145\x72\x61\x74\x65\137\155\157\144\x61\154\137\x61\143\x74\x69\157\x6e", [$this, "\x69\147\x69\141\x77\x6b\x6f\161\151\157\x67\x6f\143\163\x61\165"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\x70\x72\137\x67\145\x6e\145\x72\x61\x6c"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
