<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6758160d13747             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Container\Container; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\x6d\151\156\137\x66\x6f\x6f\x74\145\x72", [$this, "\147\147\x73\x6b\143\x67\147\141\141\x65\x61\153\147\x61\x71\x63"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x66\157\165\156\x64\141\164\151\157\156\x5f\x62\141\x63\x6b\145\156\144\137\147\145\x6e\x65\x72\141\x74\x65\137\x6d\157\x64\x61\x6c\x5f\141\143\x74\151\157\x6e", [$this, "\151\147\x69\x61\167\x6b\157\161\x69\157\x67\157\143\163\x61\x75"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\x70\162\x5f\147\145\x6e\x65\x72\x61\x6c"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
