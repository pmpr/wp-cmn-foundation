<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f0d2c87384d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\x6d\x69\x6e\137\146\157\x6f\x74\x65\x72", [$this, "\147\147\163\x6b\x63\147\x67\x61\x61\145\141\x6b\x67\141\161\143"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\146\157\x75\156\144\141\164\x69\157\x6e\x5f\142\x61\143\x6b\x65\x6e\144\137\147\145\x6e\x65\162\141\164\145\137\155\x6f\144\x61\x6c\137\x61\143\x74\x69\157\x6e", [$this, "\151\x67\151\x61\x77\153\157\161\151\x6f\x67\x6f\143\163\141\x75"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\x70\x72\137\x67\x65\156\x65\x72\x61\154"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
