<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675819f57c47e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Container\Container; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\155\x69\x6e\x5f\146\157\157\x74\145\162", [$this, "\x67\x67\163\153\x63\147\147\141\x61\x65\x61\x6b\x67\141\161\143"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x66\x6f\x75\156\x64\x61\164\x69\157\156\137\x62\141\x63\x6b\x65\x6e\x64\137\x67\145\156\x65\162\141\164\x65\137\x6d\157\144\x61\x6c\x5f\141\x63\x74\x69\x6f\156", [$this, "\151\x67\151\x61\x77\x6b\x6f\161\151\157\147\157\x63\163\141\165"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\160\162\x5f\147\145\156\x65\162\x61\154"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
