<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbd6d87474a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\155\x69\156\x5f\146\157\x6f\164\145\162", [$this, "\147\147\x73\153\x63\x67\x67\x61\x61\x65\141\x6b\x67\141\x71\x63"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\146\157\165\156\144\141\x74\151\157\x6e\x5f\142\141\x63\x6b\x65\x6e\x64\x5f\x67\x65\156\145\x72\x61\164\145\137\155\x6f\x64\141\x6c\137\x61\143\x74\151\157\x6e", [$this, "\151\x67\x69\141\x77\x6b\x6f\161\151\x6f\x67\x6f\143\163\141\x75"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\x70\162\137\x67\x65\x6e\x65\162\141\154"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
