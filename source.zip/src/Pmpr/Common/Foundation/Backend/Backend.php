<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670dbd405b5c8             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Backend; use Pmpr\Common\Foundation\Container\Container; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\155\x69\156\137\146\157\157\164\x65\162", [$this, "\x67\x67\x73\x6b\143\147\x67\x61\141\145\x61\x6b\147\x61\x71\143"]); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\146\157\165\156\144\141\x74\151\157\156\137\142\x61\x63\153\145\156\x64\137\147\x65\x6e\x65\x72\x61\x74\145\x5f\155\157\x64\x61\x6c\x5f\x61\x63\x74\151\157\156", [$this, "\151\147\151\141\167\x6b\x6f\x71\x69\157\x67\157\143\163\x61\165"], 10, 4); } public function ggskcggaaeakgaqc() { echo $this->caokeucsksukesyo()->wmkogisswkckmeua()->icqkogwskuwscskk([Constants::PREFIX => "\160\x72\x5f\x67\x65\x6e\145\x72\x61\x6c"]); } public function igiawkoqiogocsau($aiamqeawckcsuaou, array $ywmkwiwkosakssii = [], string $meqocwsecsywiiqs = '', array $wwgucssaecqekuek = []) : string { return $this->caokeucsksukesyo()->wmkogisswkckmeua()->igiawkoqiogocsau($ywmkwiwkosakssii, $meqocwsecsywiiqs, $wwgucssaecqekuek); } }
