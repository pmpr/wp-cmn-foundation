<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675fac6c7c17d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\MobileApp; use Pmpr\Common\Foundation\Container\Container; use Pmpr\Common\Foundation\MobileApp\Backward\Backward; class MobileApp extends Container { public function mameiwsayuyquoeq() { Listing::ksyueceqagwomguk(); Backward::ksyueceqagwomguk(); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x68\x74\164\x70\x5f\150\x65\141\x64\145\162\163\x5f\x75\163\145\162\141\x67\145\156\x74", [$this, "\155\x65\151\x65\155\x79\x69\157\161\x61\x69\147\163\x75\143\x73"], 9999); } public function meiemyioqaigsucs($yucuiaqgmwimgcoy) : string { return $this->uwkmaywceaaaigwo()->giiecckwoyiawoyy()->auksikwsewaywikq(); } }
