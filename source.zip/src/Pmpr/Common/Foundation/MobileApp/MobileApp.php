<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ced35949c89             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\MobileApp; use Pmpr\Common\Foundation\MobileApp\Backward\Backward; class MobileApp extends Common { public function mameiwsayuyquoeq() { Listing::ksyueceqagwomguk(); Backward::ksyueceqagwomguk(); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\150\x74\164\x70\x5f\x68\145\141\x64\145\162\x73\x5f\x75\163\145\x72\x61\147\x65\x6e\164", [$this, "\155\x65\151\145\155\171\x69\157\161\x61\x69\x67\163\x75\143\163"], 9999); } public function meiemyioqaigsucs($yucuiaqgmwimgcoy) : string { return $this->uwkmaywceaaaigwo()->giiecckwoyiawoyy()->auksikwsewaywikq(); } }
