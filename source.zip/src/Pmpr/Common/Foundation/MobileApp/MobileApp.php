<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d8c7809438d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\MobileApp; use Pmpr\Common\Foundation\MobileApp\Backward\Backward; class MobileApp extends Common { public function mameiwsayuyquoeq() { Listing::ksyueceqagwomguk(); Backward::ksyueceqagwomguk(); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\150\164\164\160\x5f\x68\x65\x61\x64\x65\162\x73\137\165\163\145\x72\x61\147\x65\x6e\x74", [$this, "\155\x65\x69\145\155\x79\151\x6f\x71\x61\x69\x67\x73\165\x63\x73"], 9999); } public function meiemyioqaigsucs($yucuiaqgmwimgcoy) : string { return $this->uwkmaywceaaaigwo()->giiecckwoyiawoyy()->auksikwsewaywikq(); } }
