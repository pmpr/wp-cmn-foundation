<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d31c5675355             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\MobileApp; use Pmpr\Common\Foundation\MobileApp\Backward\Backward; class MobileApp extends Common { public function mameiwsayuyquoeq() { Listing::ksyueceqagwomguk(); Backward::ksyueceqagwomguk(); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x68\x74\164\x70\137\x68\145\141\x64\x65\x72\163\x5f\165\163\x65\x72\141\x67\x65\x6e\x74", [$this, "\x6d\x65\151\x65\x6d\x79\x69\157\x71\x61\x69\x67\x73\x75\143\x73"], 9999); } public function meiemyioqaigsucs($yucuiaqgmwimgcoy) : string { return $this->uwkmaywceaaaigwo()->giiecckwoyiawoyy()->auksikwsewaywikq(); } }
