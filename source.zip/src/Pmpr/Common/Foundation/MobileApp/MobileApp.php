<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             679576175075e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\MobileApp; use Pmpr\Common\Foundation\Container\Container; use Pmpr\Common\Foundation\MobileApp\Backward\Backward; class MobileApp extends Container { public function mameiwsayuyquoeq() { Listing::ksyueceqagwomguk(); Backward::ksyueceqagwomguk(); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x68\x74\164\160\137\150\x65\141\144\145\x72\x73\x5f\165\x73\x65\162\x61\147\x65\156\x74", [$this, "\155\145\151\145\x6d\171\x69\157\161\x61\151\147\163\x75\x63\163"], 9999); } public function meiemyioqaigsucs($yucuiaqgmwimgcoy) : string { return $this->uwkmaywceaaaigwo()->giiecckwoyiawoyy()->auksikwsewaywikq(); } }
