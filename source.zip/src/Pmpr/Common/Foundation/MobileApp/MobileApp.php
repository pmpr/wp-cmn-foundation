<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce6343424e0             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\MobileApp; use Pmpr\Common\Foundation\MobileApp\Backward\Backward; class MobileApp extends Common { public function mameiwsayuyquoeq() { Listing::ksyueceqagwomguk(); Backward::ksyueceqagwomguk(); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\150\x74\164\160\137\x68\145\x61\144\x65\x72\x73\137\x75\163\145\162\x61\147\x65\x6e\164", [$this, "\x6d\x65\x69\145\x6d\x79\151\157\x71\141\151\x67\x73\165\x63\163"], 9999); } public function meiemyioqaigsucs($yucuiaqgmwimgcoy) : string { return $this->uwkmaywceaaaigwo()->giiecckwoyiawoyy()->auksikwsewaywikq(); } }
