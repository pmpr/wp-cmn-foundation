<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec0c5dc5dae             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template; use Pmpr\Common\Foundation\Template\Twig\Twig; class Template extends Common { public function mameiwsayuyquoeq() { Twig::symcgieuakksimmu(); } }
