<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e16aefd43f6             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; class Twig extends Common { public function uykissogmuaaocsg() : ?Engine { return Engine::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\x6c\x75\147\x69\x6e\x73\137\x6c\157\x61\144\145\144", [$this, "\154\157\x61\144"])->qcsmikeggeemccuu("\141\x66\x74\145\162\x5f\163\x65\x74\165\160\137\164\x68\x65\x6d\145", [$this, "\x6b\x67\153\155\167\165\143\155\153\143\x71\141\x6b\163\x6d\x6f"], 99, 2); $this->waqewsckuayqguos("\x61\144\x64\137\164\x65\x6d\160\154\141\x74\x69\156\x67\x5f\160\141\164\x68", [$this, "\167\x6b\157\163\151\x63\163\145\153\167\153\x69\147\171\163\163"], 10, 2); parent::wigskegsqequoeks(); } public function load() { $this->uykissogmuaaocsg()->load(); } public function wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca) { $this->uykissogmuaaocsg()->wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca); } public function kgkmwucmkcqaksmo() { $goqqimcssiyagkwy = $this->uykissogmuaaocsg(); Filter::symcgieuakksimmu($goqqimcssiyagkwy); Action::symcgieuakksimmu($goqqimcssiyagkwy); } }
