<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce54af64690             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; class Twig extends Common { public function uykissogmuaaocsg() : ?Engine { return Engine::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\154\x75\x67\151\156\x73\x5f\154\x6f\141\144\145\144", [$this, "\154\157\141\144"])->qcsmikeggeemccuu("\141\146\164\x65\x72\137\x73\x65\164\x75\160\x5f\164\150\145\x6d\x65", [$this, "\x6b\147\x6b\x6d\167\x75\143\155\x6b\x63\161\141\x6b\163\x6d\x6f"], 99, 2); $this->waqewsckuayqguos("\x61\144\x64\137\164\x65\155\160\x6c\141\164\x69\156\147\137\160\141\x74\150", [$this, "\x77\153\x6f\163\151\x63\x73\145\153\167\x6b\x69\147\171\x73\x73"], 10, 2); parent::wigskegsqequoeks(); } public function load() { $this->uykissogmuaaocsg()->load(); } public function wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca) { $this->uykissogmuaaocsg()->wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca); } public function kgkmwucmkcqaksmo() { $goqqimcssiyagkwy = $this->uykissogmuaaocsg(); Filter::symcgieuakksimmu($goqqimcssiyagkwy); Action::symcgieuakksimmu($goqqimcssiyagkwy); } }
