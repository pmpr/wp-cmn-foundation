<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce3480d954f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; class Twig extends Common { public function uykissogmuaaocsg() : ?Engine { return Engine::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\154\x75\147\151\x6e\x73\x5f\x6c\157\x61\144\x65\144", [$this, "\154\157\x61\x64"])->qcsmikeggeemccuu("\x61\x66\164\x65\162\x5f\163\145\x74\x75\x70\x5f\164\150\145\155\145", [$this, "\153\147\x6b\155\167\x75\143\155\153\143\161\141\x6b\x73\x6d\x6f"], 99, 2); $this->waqewsckuayqguos("\141\x64\144\137\x74\x65\155\160\x6c\x61\x74\151\x6e\x67\x5f\160\x61\164\x68", [$this, "\167\153\x6f\x73\151\x63\163\x65\x6b\167\x6b\x69\147\x79\163\x73"], 10, 2); parent::wigskegsqequoeks(); } public function load() { $this->uykissogmuaaocsg()->load(); } public function wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca) { $this->uykissogmuaaocsg()->wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca); } public function kgkmwucmkcqaksmo() { $goqqimcssiyagkwy = $this->uykissogmuaaocsg(); Filter::symcgieuakksimmu($goqqimcssiyagkwy); Action::symcgieuakksimmu($goqqimcssiyagkwy); } }
