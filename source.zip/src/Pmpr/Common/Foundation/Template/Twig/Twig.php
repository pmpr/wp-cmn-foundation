<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1e3829f9fd             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; class Twig extends Common { public function uykissogmuaaocsg() : ?Engine { return Engine::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\154\165\x67\151\x6e\x73\x5f\x6c\x6f\x61\144\145\x64", [$this, "\154\157\x61\x64"])->qcsmikeggeemccuu("\141\x66\164\x65\162\137\x73\x65\164\165\160\137\164\x68\145\155\x65", [$this, "\x6b\147\x6b\x6d\167\x75\143\x6d\153\x63\x71\x61\x6b\x73\x6d\x6f"], 99, 2); $this->waqewsckuayqguos("\141\144\144\x5f\164\x65\155\160\154\x61\164\x69\156\x67\137\160\141\164\150", [$this, "\167\x6b\157\163\x69\143\163\x65\153\167\153\151\x67\x79\x73\x73"], 10, 2); parent::wigskegsqequoeks(); } public function load() { $this->uykissogmuaaocsg()->load(); } public function wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca) { $this->uykissogmuaaocsg()->wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca); } public function kgkmwucmkcqaksmo() { $goqqimcssiyagkwy = $this->uykissogmuaaocsg(); Filter::symcgieuakksimmu($goqqimcssiyagkwy); Action::symcgieuakksimmu($goqqimcssiyagkwy); } }
