<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce373d0ef0a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; class Twig extends Common { public function uykissogmuaaocsg() : ?Engine { return Engine::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\x6c\x75\147\x69\x6e\163\137\x6c\x6f\x61\144\145\144", [$this, "\154\x6f\x61\144"])->qcsmikeggeemccuu("\141\x66\164\145\x72\137\x73\145\x74\x75\x70\137\x74\150\145\155\145", [$this, "\x6b\147\153\155\167\x75\x63\155\x6b\143\x71\x61\153\163\x6d\x6f"], 99, 2); $this->waqewsckuayqguos("\141\144\144\x5f\164\145\155\160\154\141\x74\x69\x6e\x67\x5f\x70\x61\164\x68", [$this, "\x77\x6b\157\163\x69\143\x73\x65\x6b\x77\x6b\151\147\171\163\x73"], 10, 2); parent::wigskegsqequoeks(); } public function load() { $this->uykissogmuaaocsg()->load(); } public function wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca) { $this->uykissogmuaaocsg()->wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca); } public function kgkmwucmkcqaksmo() { $goqqimcssiyagkwy = $this->uykissogmuaaocsg(); Filter::symcgieuakksimmu($goqqimcssiyagkwy); Action::symcgieuakksimmu($goqqimcssiyagkwy); } }
