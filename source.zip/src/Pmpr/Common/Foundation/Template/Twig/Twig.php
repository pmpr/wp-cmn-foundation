<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ced35949c89             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; class Twig extends Common { public function uykissogmuaaocsg() : ?Engine { return Engine::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\x6c\165\147\151\x6e\163\x5f\x6c\x6f\141\144\145\144", [$this, "\x6c\157\141\144"])->qcsmikeggeemccuu("\141\146\x74\145\162\137\x73\x65\164\x75\160\137\x74\x68\x65\x6d\x65", [$this, "\153\147\x6b\x6d\x77\165\143\x6d\153\x63\x71\141\x6b\163\x6d\x6f"], 99, 2); $this->waqewsckuayqguos("\141\x64\144\137\x74\x65\x6d\160\154\141\x74\x69\x6e\x67\137\x70\141\164\150", [$this, "\x77\153\157\x73\151\x63\163\145\x6b\167\x6b\151\147\171\163\163"], 10, 2); parent::wigskegsqequoeks(); } public function load() { $this->uykissogmuaaocsg()->load(); } public function wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca) { $this->uykissogmuaaocsg()->wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca); } public function kgkmwucmkcqaksmo() { $goqqimcssiyagkwy = $this->uykissogmuaaocsg(); Filter::symcgieuakksimmu($goqqimcssiyagkwy); Action::symcgieuakksimmu($goqqimcssiyagkwy); } }
