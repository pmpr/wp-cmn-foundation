<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec08eec428e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; class Twig extends Common { public function uykissogmuaaocsg() : ?Engine { return Engine::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\x6c\x75\x67\151\x6e\x73\x5f\x6c\x6f\x61\144\x65\x64", [$this, "\154\x6f\141\144"])->qcsmikeggeemccuu("\141\x66\x74\x65\x72\137\x73\145\x74\165\160\x5f\164\x68\145\x6d\145", [$this, "\x6b\x67\153\x6d\x77\165\143\155\x6b\143\161\x61\x6b\x73\155\x6f"], 99, 2); $this->waqewsckuayqguos("\x61\x64\144\137\x74\145\155\160\x6c\x61\164\151\156\147\137\160\x61\164\150", [$this, "\167\153\157\163\x69\x63\x73\145\x6b\167\x6b\151\147\x79\x73\x73"], 10, 2); parent::wigskegsqequoeks(); } public function load() { $this->uykissogmuaaocsg()->load(); } public function wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca) { $this->uykissogmuaaocsg()->wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca); } public function kgkmwucmkcqaksmo() { $goqqimcssiyagkwy = $this->uykissogmuaaocsg(); Filter::symcgieuakksimmu($goqqimcssiyagkwy); Action::symcgieuakksimmu($goqqimcssiyagkwy); } }
