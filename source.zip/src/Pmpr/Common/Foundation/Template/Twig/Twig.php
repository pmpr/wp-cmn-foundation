<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec0c5dc5dae             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; class Twig extends Common { public function uykissogmuaaocsg() : ?Engine { return Engine::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\x6c\165\x67\x69\x6e\163\x5f\154\157\141\x64\145\x64", [$this, "\x6c\157\x61\144"])->qcsmikeggeemccuu("\141\x66\x74\145\162\137\x73\145\164\165\160\137\x74\x68\145\155\x65", [$this, "\x6b\x67\x6b\x6d\x77\165\143\155\153\x63\x71\141\x6b\163\155\157"], 99, 2); $this->waqewsckuayqguos("\x61\x64\144\137\x74\145\x6d\160\x6c\x61\x74\x69\156\x67\x5f\160\141\x74\150", [$this, "\x77\x6b\157\x73\151\143\163\145\x6b\167\x6b\151\x67\171\x73\x73"], 10, 2); parent::wigskegsqequoeks(); } public function load() { $this->uykissogmuaaocsg()->load(); } public function wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca) { $this->uykissogmuaaocsg()->wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca); } public function kgkmwucmkcqaksmo() { $goqqimcssiyagkwy = $this->uykissogmuaaocsg(); Filter::symcgieuakksimmu($goqqimcssiyagkwy); Action::symcgieuakksimmu($goqqimcssiyagkwy); } }
