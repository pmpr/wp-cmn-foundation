<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f15ee33c813             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; class Twig extends Common { public function uykissogmuaaocsg() : ?Engine { return Engine::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\154\165\x67\x69\x6e\163\137\154\x6f\141\144\145\x64", [$this, "\x6c\157\141\144"])->qcsmikeggeemccuu("\141\146\164\145\x72\137\x73\x65\x74\165\160\137\164\x68\145\155\x65", [$this, "\153\147\153\x6d\x77\165\x63\155\153\x63\161\x61\x6b\x73\155\157"], 99, 2); $this->waqewsckuayqguos("\x61\x64\x64\137\x74\145\155\x70\154\x61\x74\151\156\147\137\160\x61\x74\x68", [$this, "\167\153\157\x73\x69\143\x73\x65\153\167\x6b\x69\147\x79\163\163"], 10, 2); parent::wigskegsqequoeks(); } public function load() { $this->uykissogmuaaocsg()->load(); } public function wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca) { $this->uykissogmuaaocsg()->wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca); } public function kgkmwucmkcqaksmo() { $goqqimcssiyagkwy = $this->uykissogmuaaocsg(); Filter::symcgieuakksimmu($goqqimcssiyagkwy); Action::symcgieuakksimmu($goqqimcssiyagkwy); } }
