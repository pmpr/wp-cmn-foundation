<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d2eee324173             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; class Twig extends Common { public function uykissogmuaaocsg() : ?Engine { return Engine::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\154\x75\x67\151\x6e\163\x5f\154\157\x61\144\145\x64", [$this, "\x6c\x6f\x61\144"])->qcsmikeggeemccuu("\x61\x66\x74\145\162\x5f\163\145\x74\x75\x70\137\164\150\145\155\x65", [$this, "\153\x67\153\155\x77\165\x63\155\153\143\x71\141\x6b\x73\x6d\157"], 99, 2); $this->waqewsckuayqguos("\x61\x64\x64\x5f\164\145\155\x70\x6c\x61\164\151\156\147\x5f\160\x61\164\x68", [$this, "\x77\x6b\157\x73\x69\143\163\x65\x6b\x77\x6b\151\x67\171\163\x73"], 10, 2); parent::wigskegsqequoeks(); } public function load() { $this->uykissogmuaaocsg()->load(); } public function wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca) { $this->uykissogmuaaocsg()->wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca); } public function kgkmwucmkcqaksmo() { $goqqimcssiyagkwy = $this->uykissogmuaaocsg(); Filter::symcgieuakksimmu($goqqimcssiyagkwy); Action::symcgieuakksimmu($goqqimcssiyagkwy); } }
