<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d1dbc474879             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; class Twig extends Common { public function uykissogmuaaocsg() : ?Engine { return Engine::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\154\165\147\151\x6e\163\137\x6c\157\141\144\145\x64", [$this, "\154\x6f\x61\144"])->qcsmikeggeemccuu("\x61\146\164\x65\x72\137\x73\x65\164\x75\160\x5f\x74\x68\145\x6d\145", [$this, "\x6b\x67\153\x6d\167\x75\143\x6d\153\143\161\141\x6b\x73\155\157"], 99, 2); $this->waqewsckuayqguos("\x61\x64\144\x5f\x74\145\x6d\x70\x6c\141\164\x69\x6e\147\x5f\160\x61\164\150", [$this, "\167\x6b\157\x73\x69\x63\x73\145\153\x77\153\151\x67\171\163\163"], 10, 2); parent::wigskegsqequoeks(); } public function load() { $this->uykissogmuaaocsg()->load(); } public function wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca) { $this->uykissogmuaaocsg()->wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca); } public function kgkmwucmkcqaksmo() { $goqqimcssiyagkwy = $this->uykissogmuaaocsg(); Filter::symcgieuakksimmu($goqqimcssiyagkwy); Action::symcgieuakksimmu($goqqimcssiyagkwy); } }
