<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d303622917b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; class Twig extends Common { public function uykissogmuaaocsg() : ?Engine { return Engine::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\154\x75\x67\151\156\x73\x5f\154\x6f\141\x64\145\144", [$this, "\154\157\141\x64"])->qcsmikeggeemccuu("\x61\x66\x74\x65\162\137\163\x65\x74\165\160\137\164\150\x65\155\145", [$this, "\x6b\x67\153\x6d\x77\165\143\155\x6b\x63\x71\x61\x6b\163\155\157"], 99, 2); $this->waqewsckuayqguos("\x61\144\144\137\164\145\x6d\x70\x6c\141\164\151\x6e\147\137\x70\x61\164\x68", [$this, "\x77\153\x6f\x73\151\143\x73\x65\x6b\167\153\x69\147\x79\x73\163"], 10, 2); parent::wigskegsqequoeks(); } public function load() { $this->uykissogmuaaocsg()->load(); } public function wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca) { $this->uykissogmuaaocsg()->wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca); } public function kgkmwucmkcqaksmo() { $goqqimcssiyagkwy = $this->uykissogmuaaocsg(); Filter::symcgieuakksimmu($goqqimcssiyagkwy); Action::symcgieuakksimmu($goqqimcssiyagkwy); } }
