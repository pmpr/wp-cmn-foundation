<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d31c5675355             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; class Twig extends Common { public function uykissogmuaaocsg() : ?Engine { return Engine::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\x6c\x75\147\151\x6e\x73\137\x6c\x6f\x61\144\x65\x64", [$this, "\154\157\141\x64"])->qcsmikeggeemccuu("\141\146\x74\x65\162\137\x73\145\164\x75\160\x5f\x74\150\x65\x6d\x65", [$this, "\153\147\x6b\155\x77\165\143\x6d\153\143\161\141\x6b\x73\x6d\157"], 99, 2); $this->waqewsckuayqguos("\141\144\144\137\x74\x65\155\160\x6c\141\x74\x69\156\147\x5f\160\141\x74\x68", [$this, "\167\153\x6f\x73\x69\x63\163\x65\153\167\153\151\147\x79\163\x73"], 10, 2); parent::wigskegsqequoeks(); } public function load() { $this->uykissogmuaaocsg()->load(); } public function wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca) { $this->uykissogmuaaocsg()->wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca); } public function kgkmwucmkcqaksmo() { $goqqimcssiyagkwy = $this->uykissogmuaaocsg(); Filter::symcgieuakksimmu($goqqimcssiyagkwy); Action::symcgieuakksimmu($goqqimcssiyagkwy); } }
