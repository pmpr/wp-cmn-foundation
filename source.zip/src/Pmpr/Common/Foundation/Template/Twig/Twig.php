<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d2f79b4e2f3             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; class Twig extends Common { public function uykissogmuaaocsg() : ?Engine { return Engine::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\154\165\147\151\156\x73\x5f\x6c\x6f\x61\144\145\144", [$this, "\154\157\141\x64"])->qcsmikeggeemccuu("\141\146\164\145\162\x5f\x73\x65\164\165\160\137\x74\150\145\155\145", [$this, "\x6b\147\153\155\x77\x75\x63\155\x6b\143\161\x61\x6b\163\x6d\157"], 99, 2); $this->waqewsckuayqguos("\x61\144\x64\x5f\x74\x65\155\x70\x6c\x61\164\x69\156\x67\137\x70\141\164\150", [$this, "\167\153\x6f\163\151\143\163\x65\x6b\x77\x6b\x69\x67\171\163\x73"], 10, 2); parent::wigskegsqequoeks(); } public function load() { $this->uykissogmuaaocsg()->load(); } public function wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca) { $this->uykissogmuaaocsg()->wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca); } public function kgkmwucmkcqaksmo() { $goqqimcssiyagkwy = $this->uykissogmuaaocsg(); Filter::symcgieuakksimmu($goqqimcssiyagkwy); Action::symcgieuakksimmu($goqqimcssiyagkwy); } }
