<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d8c7809438d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; class Twig extends Common { public function uykissogmuaaocsg() : ?Engine { return Engine::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\154\x75\x67\x69\x6e\x73\137\154\157\x61\144\145\x64", [$this, "\x6c\157\x61\x64"])->qcsmikeggeemccuu("\x61\146\164\x65\162\x5f\x73\x65\x74\x75\160\137\164\150\x65\155\x65", [$this, "\x6b\147\x6b\x6d\x77\x75\x63\155\x6b\x63\x71\x61\x6b\x73\x6d\157"], 99, 2); $this->waqewsckuayqguos("\141\x64\x64\x5f\x74\x65\155\x70\154\x61\x74\x69\156\147\137\x70\x61\164\x68", [$this, "\x77\x6b\157\x73\x69\x63\163\x65\153\167\x6b\151\x67\x79\163\x73"], 10, 2); parent::wigskegsqequoeks(); } public function load() { $this->uykissogmuaaocsg()->load(); } public function wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca) { $this->uykissogmuaaocsg()->wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca); } public function kgkmwucmkcqaksmo() { $goqqimcssiyagkwy = $this->uykissogmuaaocsg(); Filter::symcgieuakksimmu($goqqimcssiyagkwy); Action::symcgieuakksimmu($goqqimcssiyagkwy); } }
