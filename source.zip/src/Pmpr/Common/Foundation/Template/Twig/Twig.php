<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae85ba078b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; class Twig extends Common { public function uykissogmuaaocsg() : ?Engine { return Engine::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\x6c\165\147\151\156\x73\x5f\154\157\141\144\x65\144", [$this, "\154\x6f\141\144"])->qcsmikeggeemccuu("\141\146\x74\145\162\137\x73\145\x74\165\160\x5f\164\x68\145\x6d\x65", [$this, "\153\x67\153\155\x77\165\x63\155\x6b\143\x71\x61\x6b\163\x6d\157"], 99, 2); $this->waqewsckuayqguos("\x61\144\x64\137\x74\145\155\160\x6c\x61\x74\x69\x6e\x67\x5f\x70\x61\164\150", [$this, "\167\x6b\x6f\163\151\x63\x73\x65\x6b\x77\153\151\147\171\x73\163"], 10, 2); parent::wigskegsqequoeks(); } public function load() { $this->uykissogmuaaocsg()->load(); } public function wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca) { $this->uykissogmuaaocsg()->wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca); } public function kgkmwucmkcqaksmo() { $goqqimcssiyagkwy = $this->uykissogmuaaocsg(); Filter::symcgieuakksimmu($goqqimcssiyagkwy); Action::symcgieuakksimmu($goqqimcssiyagkwy); } }
