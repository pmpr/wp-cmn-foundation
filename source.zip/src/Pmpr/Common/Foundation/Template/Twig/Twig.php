<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ebf559ba6b4             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; class Twig extends Common { public function uykissogmuaaocsg() : ?Engine { return Engine::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\x6c\x75\x67\151\156\163\x5f\x6c\157\x61\144\x65\144", [$this, "\x6c\157\x61\144"])->qcsmikeggeemccuu("\141\146\x74\145\162\137\163\145\x74\165\x70\x5f\x74\x68\145\x6d\145", [$this, "\153\x67\153\155\167\x75\x63\x6d\x6b\143\161\141\x6b\x73\x6d\157"], 99, 2); $this->waqewsckuayqguos("\x61\144\144\137\164\x65\x6d\x70\154\x61\x74\151\x6e\x67\137\160\141\x74\x68", [$this, "\167\x6b\157\x73\x69\x63\x73\x65\153\x77\x6b\x69\147\x79\x73\x73"], 10, 2); parent::wigskegsqequoeks(); } public function load() { $this->uykissogmuaaocsg()->load(); } public function wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca) { $this->uykissogmuaaocsg()->wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca); } public function kgkmwucmkcqaksmo() { $goqqimcssiyagkwy = $this->uykissogmuaaocsg(); Filter::symcgieuakksimmu($goqqimcssiyagkwy); Action::symcgieuakksimmu($goqqimcssiyagkwy); } }
