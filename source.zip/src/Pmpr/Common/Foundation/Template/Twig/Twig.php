<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce38dda53fd             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; class Twig extends Common { public function uykissogmuaaocsg() : ?Engine { return Engine::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\x6c\165\x67\151\156\163\137\154\x6f\x61\x64\x65\x64", [$this, "\x6c\x6f\141\x64"])->qcsmikeggeemccuu("\141\x66\164\x65\x72\137\163\x65\x74\165\160\137\x74\x68\x65\155\145", [$this, "\x6b\147\153\155\167\x75\143\x6d\153\x63\161\x61\153\163\x6d\x6f"], 99, 2); $this->waqewsckuayqguos("\x61\x64\144\x5f\x74\x65\155\x70\154\141\x74\x69\156\x67\x5f\x70\141\164\150", [$this, "\167\x6b\x6f\163\151\143\x73\145\153\x77\x6b\x69\147\171\x73\163"], 10, 2); parent::wigskegsqequoeks(); } public function load() { $this->uykissogmuaaocsg()->load(); } public function wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca) { $this->uykissogmuaaocsg()->wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca); } public function kgkmwucmkcqaksmo() { $goqqimcssiyagkwy = $this->uykissogmuaaocsg(); Filter::symcgieuakksimmu($goqqimcssiyagkwy); Action::symcgieuakksimmu($goqqimcssiyagkwy); } }
