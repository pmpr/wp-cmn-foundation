<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f132f156703             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; class Twig extends Common { public function uykissogmuaaocsg() : ?Engine { return Engine::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\154\x75\147\151\156\163\137\x6c\x6f\141\x64\145\144", [$this, "\154\157\x61\x64"])->qcsmikeggeemccuu("\141\x66\164\x65\x72\137\x73\x65\x74\x75\160\x5f\164\150\145\x6d\x65", [$this, "\x6b\x67\153\x6d\167\x75\143\155\x6b\143\161\x61\x6b\x73\x6d\157"], 99, 2); $this->waqewsckuayqguos("\x61\144\x64\137\164\145\x6d\160\x6c\x61\x74\x69\156\147\137\x70\x61\164\150", [$this, "\167\x6b\x6f\163\151\x63\x73\x65\153\167\x6b\x69\147\171\163\x73"], 10, 2); parent::wigskegsqequoeks(); } public function load() { $this->uykissogmuaaocsg()->load(); } public function wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca) { $this->uykissogmuaaocsg()->wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca); } public function kgkmwucmkcqaksmo() { $goqqimcssiyagkwy = $this->uykissogmuaaocsg(); Filter::symcgieuakksimmu($goqqimcssiyagkwy); Action::symcgieuakksimmu($goqqimcssiyagkwy); } }
