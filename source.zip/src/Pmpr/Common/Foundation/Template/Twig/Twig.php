<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce6343424e0             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; class Twig extends Common { public function uykissogmuaaocsg() : ?Engine { return Engine::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\154\165\147\x69\x6e\163\x5f\x6c\157\x61\144\145\144", [$this, "\154\157\141\144"])->qcsmikeggeemccuu("\141\146\x74\145\x72\x5f\163\145\164\x75\160\x5f\164\x68\x65\155\145", [$this, "\x6b\147\x6b\x6d\167\x75\143\155\153\x63\161\141\153\x73\x6d\x6f"], 99, 2); $this->waqewsckuayqguos("\x61\x64\x64\x5f\x74\x65\155\160\154\141\164\151\156\x67\137\x70\141\x74\x68", [$this, "\x77\153\x6f\x73\151\x63\163\145\153\x77\x6b\x69\x67\171\x73\163"], 10, 2); parent::wigskegsqequoeks(); } public function load() { $this->uykissogmuaaocsg()->load(); } public function wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca) { $this->uykissogmuaaocsg()->wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca); } public function kgkmwucmkcqaksmo() { $goqqimcssiyagkwy = $this->uykissogmuaaocsg(); Filter::symcgieuakksimmu($goqqimcssiyagkwy); Action::symcgieuakksimmu($goqqimcssiyagkwy); } }
