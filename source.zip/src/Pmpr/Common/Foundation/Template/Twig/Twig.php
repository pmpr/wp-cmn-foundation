<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cf4bac87f58             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; class Twig extends Common { public function uykissogmuaaocsg() : ?Engine { return Engine::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\x6c\165\147\x69\156\163\x5f\154\x6f\x61\x64\145\144", [$this, "\x6c\x6f\141\x64"])->qcsmikeggeemccuu("\x61\146\x74\x65\x72\137\163\x65\x74\x75\x70\137\164\x68\145\x6d\x65", [$this, "\153\x67\153\x6d\167\x75\x63\155\153\x63\x71\x61\x6b\163\155\x6f"], 99, 2); $this->waqewsckuayqguos("\141\144\x64\137\x74\x65\x6d\160\154\x61\164\151\156\x67\137\x70\141\x74\150", [$this, "\167\153\x6f\x73\x69\143\x73\145\x6b\x77\153\151\x67\171\x73\x73"], 10, 2); parent::wigskegsqequoeks(); } public function load() { $this->uykissogmuaaocsg()->load(); } public function wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca) { $this->uykissogmuaaocsg()->wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca); } public function kgkmwucmkcqaksmo() { $goqqimcssiyagkwy = $this->uykissogmuaaocsg(); Filter::symcgieuakksimmu($goqqimcssiyagkwy); Action::symcgieuakksimmu($goqqimcssiyagkwy); } }
