<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ebe0a571651             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; class Twig extends Common { public function uykissogmuaaocsg() : ?Engine { return Engine::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\154\x75\147\x69\x6e\x73\x5f\x6c\157\141\144\145\144", [$this, "\x6c\157\x61\x64"])->qcsmikeggeemccuu("\141\x66\x74\x65\162\137\x73\x65\164\165\160\137\x74\x68\145\155\x65", [$this, "\x6b\x67\x6b\x6d\167\x75\143\x6d\x6b\x63\161\x61\x6b\163\155\157"], 99, 2); $this->waqewsckuayqguos("\x61\144\x64\x5f\164\145\x6d\x70\x6c\x61\164\x69\x6e\x67\137\x70\x61\x74\150", [$this, "\167\x6b\157\163\x69\143\x73\145\153\167\x6b\x69\147\x79\x73\x73"], 10, 2); parent::wigskegsqequoeks(); } public function load() { $this->uykissogmuaaocsg()->load(); } public function wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca) { $this->uykissogmuaaocsg()->wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca); } public function kgkmwucmkcqaksmo() { $goqqimcssiyagkwy = $this->uykissogmuaaocsg(); Filter::symcgieuakksimmu($goqqimcssiyagkwy); Action::symcgieuakksimmu($goqqimcssiyagkwy); } }
