<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1d819504ee             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; class Twig extends Common { public function uykissogmuaaocsg() : ?Engine { return Engine::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\x6c\165\147\x69\156\x73\x5f\x6c\x6f\141\144\145\144", [$this, "\154\157\x61\144"])->qcsmikeggeemccuu("\141\x66\x74\x65\x72\x5f\163\x65\164\x75\x70\137\x74\x68\145\155\145", [$this, "\153\147\x6b\x6d\x77\x75\143\x6d\x6b\x63\161\141\153\x73\155\x6f"], 99, 2); $this->waqewsckuayqguos("\x61\x64\144\x5f\164\145\155\x70\x6c\141\164\x69\156\x67\x5f\x70\141\x74\150", [$this, "\167\x6b\157\x73\151\143\163\x65\153\x77\x6b\x69\147\x79\163\163"], 10, 2); parent::wigskegsqequoeks(); } public function load() { $this->uykissogmuaaocsg()->load(); } public function wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca) { $this->uykissogmuaaocsg()->wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca); } public function kgkmwucmkcqaksmo() { $goqqimcssiyagkwy = $this->uykissogmuaaocsg(); Filter::symcgieuakksimmu($goqqimcssiyagkwy); Action::symcgieuakksimmu($goqqimcssiyagkwy); } }
