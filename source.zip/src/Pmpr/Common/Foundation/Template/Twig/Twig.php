<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d3160ad4f5b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; class Twig extends Common { public function uykissogmuaaocsg() : ?Engine { return Engine::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\154\165\147\x69\156\x73\x5f\x6c\x6f\141\x64\145\x64", [$this, "\154\157\x61\144"])->qcsmikeggeemccuu("\x61\146\164\145\162\137\x73\x65\164\165\160\x5f\164\150\145\155\x65", [$this, "\153\x67\153\155\x77\165\143\x6d\x6b\x63\161\141\x6b\163\x6d\x6f"], 99, 2); $this->waqewsckuayqguos("\x61\x64\144\137\x74\145\155\160\154\141\x74\x69\x6e\147\x5f\x70\141\x74\150", [$this, "\167\x6b\157\x73\151\x63\163\x65\153\x77\x6b\x69\147\x79\x73\163"], 10, 2); parent::wigskegsqequoeks(); } public function load() { $this->uykissogmuaaocsg()->load(); } public function wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca) { $this->uykissogmuaaocsg()->wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca); } public function kgkmwucmkcqaksmo() { $goqqimcssiyagkwy = $this->uykissogmuaaocsg(); Filter::symcgieuakksimmu($goqqimcssiyagkwy); Action::symcgieuakksimmu($goqqimcssiyagkwy); } }
