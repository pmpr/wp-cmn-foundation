<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f0d2c87384d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; class Twig extends Common { public function uykissogmuaaocsg() : ?Engine { return Engine::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\x6c\x75\x67\x69\156\163\x5f\154\x6f\141\x64\145\x64", [$this, "\x6c\157\141\144"])->qcsmikeggeemccuu("\x61\146\x74\145\162\137\163\x65\x74\x75\160\137\164\x68\145\x6d\145", [$this, "\153\x67\x6b\155\167\x75\x63\155\153\x63\161\141\153\x73\155\x6f"], 99, 2); $this->waqewsckuayqguos("\141\x64\144\x5f\x74\145\155\x70\154\141\164\x69\x6e\147\x5f\x70\x61\164\150", [$this, "\x77\153\x6f\163\x69\x63\163\x65\x6b\167\x6b\151\147\171\163\x73"], 10, 2); parent::wigskegsqequoeks(); } public function load() { $this->uykissogmuaaocsg()->load(); } public function wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca) { $this->uykissogmuaaocsg()->wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca); } public function kgkmwucmkcqaksmo() { $goqqimcssiyagkwy = $this->uykissogmuaaocsg(); Filter::symcgieuakksimmu($goqqimcssiyagkwy); Action::symcgieuakksimmu($goqqimcssiyagkwy); } }
