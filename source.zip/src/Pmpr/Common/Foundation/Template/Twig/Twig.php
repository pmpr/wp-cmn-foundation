<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1e2ec7c9c7             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; class Twig extends Common { public function uykissogmuaaocsg() : ?Engine { return Engine::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\x6c\165\x67\x69\x6e\x73\137\x6c\157\141\144\x65\144", [$this, "\154\157\141\x64"])->qcsmikeggeemccuu("\141\x66\x74\145\x72\x5f\163\145\x74\165\x70\x5f\164\x68\145\x6d\x65", [$this, "\153\x67\x6b\155\167\x75\143\x6d\x6b\x63\x71\x61\153\x73\155\157"], 99, 2); $this->waqewsckuayqguos("\141\144\x64\x5f\x74\145\x6d\x70\x6c\141\164\x69\156\147\137\160\141\164\150", [$this, "\x77\153\x6f\163\x69\x63\163\x65\x6b\x77\x6b\x69\x67\171\x73\163"], 10, 2); parent::wigskegsqequoeks(); } public function load() { $this->uykissogmuaaocsg()->load(); } public function wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca) { $this->uykissogmuaaocsg()->wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca); } public function kgkmwucmkcqaksmo() { $goqqimcssiyagkwy = $this->uykissogmuaaocsg(); Filter::symcgieuakksimmu($goqqimcssiyagkwy); Action::symcgieuakksimmu($goqqimcssiyagkwy); } }
