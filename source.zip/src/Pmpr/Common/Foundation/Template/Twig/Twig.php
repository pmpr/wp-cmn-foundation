<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebdb08957             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; class Twig extends Common { public function uykissogmuaaocsg() : ?Engine { return Engine::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\154\x75\x67\151\156\163\x5f\154\x6f\141\x64\x65\144", [$this, "\x6c\x6f\x61\x64"])->qcsmikeggeemccuu("\x61\x66\x74\x65\162\137\163\x65\164\165\160\137\x74\x68\145\155\x65", [$this, "\x6b\x67\153\x6d\167\165\143\x6d\x6b\143\161\141\153\x73\155\157"], 99, 2); $this->waqewsckuayqguos("\x61\x64\x64\137\164\x65\x6d\160\x6c\141\x74\151\156\x67\137\160\141\164\150", [$this, "\x77\x6b\x6f\163\x69\143\163\x65\x6b\x77\x6b\x69\x67\x79\163\x73"], 10, 2); parent::wigskegsqequoeks(); } public function load() { $this->uykissogmuaaocsg()->load(); } public function wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca) { $this->uykissogmuaaocsg()->wkosicsekwkigyss($aiieyweysaukqemc, $mkomwsiykqigmqca); } public function kgkmwucmkcqaksmo() { $goqqimcssiyagkwy = $this->uykissogmuaaocsg(); Filter::symcgieuakksimmu($goqqimcssiyagkwy); Action::symcgieuakksimmu($goqqimcssiyagkwy); } }
