<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4a8d73504             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig\Extension; use Twig\Attribute\YieldReady; use Twig\Compiler; use Twig\Node\Node; #[YieldReady] class BreakNode extends Node { public function compile(Compiler $wikuywwagioieuau) { $wikuywwagioieuau->addDebugInfo($this); $wikuywwagioieuau->write("\142\x72\x65\x61\x6b\x3b\12"); } }
