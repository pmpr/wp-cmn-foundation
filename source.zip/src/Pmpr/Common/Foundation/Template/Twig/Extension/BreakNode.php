<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6758160d13747             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig\Extension; use Twig\Attribute\YieldReady; use Twig\Compiler; use Twig\Node\Node; #[YieldReady] class BreakNode extends Node { public function compile(Compiler $wikuywwagioieuau) { $wikuywwagioieuau->addDebugInfo($this); $wikuywwagioieuau->write("\142\162\145\x61\x6b\73\12"); } }
