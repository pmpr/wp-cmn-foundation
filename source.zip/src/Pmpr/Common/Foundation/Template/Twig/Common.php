<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f0d2c87384d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; use Pmpr\Common\Foundation\Template\Common as BaseClass; class Common extends BaseClass { }
