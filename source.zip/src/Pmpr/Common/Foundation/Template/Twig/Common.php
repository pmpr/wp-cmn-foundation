<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e16aefd43f6             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Template\Twig; use Pmpr\Common\Foundation\Template\Common as BaseClass; class Common extends BaseClass { }
