<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d303622917b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\DB; use Pmpr\Common\Foundation\ORM\Common as BaseClass; class Common extends BaseClass { }
