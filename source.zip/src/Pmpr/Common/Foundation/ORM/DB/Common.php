<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ebf63ece5a6             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\DB; use Pmpr\Common\Foundation\ORM\Common as BaseClass; class Common extends BaseClass { }
