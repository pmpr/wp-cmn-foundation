<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f15ee33c813             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\DB\Schema; class SmallInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->originType = "\x73\x6d\x61\x6c\x6c\x69\x6e\x74"; parent::__construct("\163\155\x61\x6c\x6c\x49\x6e\x74\145\147\145\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
