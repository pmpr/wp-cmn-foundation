<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d31f49a6686             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\DB\Schema; class SmallInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->originType = "\x73\x6d\141\154\154\151\156\164"; parent::__construct("\163\155\141\154\x6c\x49\x6e\x74\x65\x67\145\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
