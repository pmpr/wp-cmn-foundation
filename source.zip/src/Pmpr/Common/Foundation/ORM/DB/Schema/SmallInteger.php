<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebdb08957             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\DB\Schema; class SmallInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->originType = "\163\155\141\154\154\x69\156\164"; parent::__construct("\x73\155\x61\x6c\x6c\111\x6e\x74\x65\147\x65\x72", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
