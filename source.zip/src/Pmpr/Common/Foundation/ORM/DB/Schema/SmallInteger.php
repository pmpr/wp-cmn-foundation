<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1d819504ee             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\DB\Schema; class SmallInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->originType = "\x73\x6d\x61\x6c\154\151\x6e\164"; parent::__construct("\163\x6d\x61\x6c\154\111\x6e\164\x65\x67\x65\x72", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
