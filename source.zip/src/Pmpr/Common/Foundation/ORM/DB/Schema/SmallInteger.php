<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d2eee324173             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\DB\Schema; class SmallInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->originType = "\x73\155\141\x6c\154\151\156\164"; parent::__construct("\163\x6d\141\x6c\x6c\111\x6e\164\145\x67\x65\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
