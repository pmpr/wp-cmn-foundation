<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec0c5dc5dae             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\DB\Schema; class SmallInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->originType = "\x73\155\141\154\x6c\151\156\164"; parent::__construct("\x73\155\141\x6c\x6c\111\x6e\x74\145\147\x65\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
