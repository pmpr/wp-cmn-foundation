<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ced35949c89             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\DB\Schema; class SmallInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->originType = "\x73\x6d\x61\154\154\x69\x6e\x74"; parent::__construct("\163\x6d\x61\x6c\154\111\x6e\x74\145\x67\x65\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
