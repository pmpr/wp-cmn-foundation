<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d1dbc474879             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\DB\Schema; class SmallInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->originType = "\163\155\141\x6c\154\x69\x6e\x74"; parent::__construct("\163\155\x61\154\x6c\111\x6e\x74\145\x67\x65\x72", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
