<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d3160ad4f5b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\DB\Schema; class Str extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->originType = "\166\141\x72\143\x68\141\x72"; parent::__construct("\163\x74\162\x69\156\x67", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
