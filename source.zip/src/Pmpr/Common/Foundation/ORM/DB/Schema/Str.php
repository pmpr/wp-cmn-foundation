<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f15ee33c813             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\DB\Schema; class Str extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->originType = "\166\141\x72\x63\150\x61\x72"; parent::__construct("\163\x74\162\151\156\x67", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
