<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e16aefd43f6             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\DB\Schema; class Str extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->originType = "\166\141\x72\143\x68\141\162"; parent::__construct("\163\x74\162\x69\x6e\x67", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
