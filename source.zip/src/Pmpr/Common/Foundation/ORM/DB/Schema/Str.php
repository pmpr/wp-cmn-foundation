<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce373d0ef0a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\DB\Schema; class Str extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->originType = "\x76\141\162\x63\x68\141\x72"; parent::__construct("\x73\164\162\x69\x6e\147", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
