<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce6343424e0             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\DB\Schema; class Str extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->originType = "\x76\141\x72\143\x68\x61\162"; parent::__construct("\163\x74\x72\x69\156\x67", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
