<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1e3829f9fd             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\DB\Schema; class Str extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->originType = "\x76\141\162\143\150\x61\x72"; parent::__construct("\163\x74\x72\x69\156\x67", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
