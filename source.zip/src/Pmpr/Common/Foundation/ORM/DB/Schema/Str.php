<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f6c272cccf4             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\DB\Schema; class Str extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->originType = "\x76\141\x72\143\150\x61\x72"; parent::__construct("\163\164\162\x69\x6e\147", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
