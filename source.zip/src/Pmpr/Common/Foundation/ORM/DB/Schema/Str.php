<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec0c5dc5dae             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\DB\Schema; class Str extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->originType = "\x76\x61\162\x63\150\x61\x72"; parent::__construct("\x73\x74\x72\x69\x6e\x67", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
