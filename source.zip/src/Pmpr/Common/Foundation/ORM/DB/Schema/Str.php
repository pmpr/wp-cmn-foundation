<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce54af64690             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\DB\Schema; class Str extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->originType = "\x76\x61\162\x63\150\x61\162"; parent::__construct("\x73\164\162\x69\x6e\147", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
