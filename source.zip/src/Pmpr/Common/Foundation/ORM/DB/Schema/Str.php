<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce38dda53fd             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\DB\Schema; class Str extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->originType = "\x76\141\162\143\x68\141\162"; parent::__construct("\x73\164\x72\x69\156\x67", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
