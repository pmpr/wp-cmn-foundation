<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f6c19d6f1c9             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\DB\Schema; class BigInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->originType = "\x62\x69\147\x69\x6e\164"; parent::__construct("\142\x69\147\111\156\164\145\x67\145\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
