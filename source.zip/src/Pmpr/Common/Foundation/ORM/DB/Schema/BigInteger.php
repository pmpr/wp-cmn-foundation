<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec08eec428e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\DB\Schema; class BigInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->originType = "\x62\151\x67\x69\156\x74"; parent::__construct("\x62\151\x67\x49\x6e\x74\145\x67\145\x72", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
