<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce54af64690             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\DB\Schema; class BigInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->originType = "\x62\151\147\151\x6e\x74"; parent::__construct("\x62\151\147\111\156\x74\145\147\x65\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
