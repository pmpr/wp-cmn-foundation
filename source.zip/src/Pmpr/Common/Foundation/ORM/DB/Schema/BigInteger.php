<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d2eee324173             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\DB\Schema; class BigInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->originType = "\x62\151\147\x69\156\x74"; parent::__construct("\142\x69\147\x49\156\x74\145\x67\x65\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
