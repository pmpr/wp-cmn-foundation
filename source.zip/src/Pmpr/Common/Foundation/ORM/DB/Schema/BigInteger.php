<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce38dda53fd             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\DB\Schema; class BigInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->originType = "\x62\x69\147\x69\x6e\164"; parent::__construct("\142\x69\147\111\156\x74\x65\147\145\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
