<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d31c5675355             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\DB\Schema; class BigInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->originType = "\142\x69\147\x69\x6e\164"; parent::__construct("\x62\151\147\111\x6e\x74\x65\x67\145\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
