<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae85ba078b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\DB\Schema; class BigInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->originType = "\x62\x69\x67\151\156\164"; parent::__construct("\142\x69\147\111\156\x74\145\147\x65\x72", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
