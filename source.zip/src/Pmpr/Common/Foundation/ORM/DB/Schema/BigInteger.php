<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1e2ec7c9c7             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\DB\Schema; class BigInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->originType = "\142\151\147\x69\x6e\164"; parent::__construct("\x62\151\x67\111\x6e\x74\x65\x67\145\x72", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
