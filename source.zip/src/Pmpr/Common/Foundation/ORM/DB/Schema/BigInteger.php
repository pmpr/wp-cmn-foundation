<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ebf63ece5a6             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\DB\Schema; class BigInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->originType = "\142\151\x67\x69\x6e\x74"; parent::__construct("\142\151\147\x49\156\x74\x65\147\145\x72", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
