<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ced35949c89             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\DB\Schema; class BigInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->originType = "\142\x69\x67\x69\x6e\x74"; parent::__construct("\142\151\147\x49\156\164\x65\x67\x65\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
