<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             694c72e59ae51             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Traits; trait ObjectTrait { protected int $id = 0; protected ?object $object = null; public function xauiwawimomcgksy(?int $aokagokqyuysuksm) : self { $this->id = $aokagokqyuysuksm; return $this; } public function iooowgsqoyqseyuu() : int { return $this->id; } public function kwmiaokywwmwecuc(?object $mksyucucyswaukig) : self { $this->object = $mksyucucyswaukig; return $this; } public function imgymusqgccqsqqq() : ?object { return $this->object; } }
