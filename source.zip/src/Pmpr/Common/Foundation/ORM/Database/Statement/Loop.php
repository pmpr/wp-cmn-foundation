<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68aed6301bda9             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Statement; use Illuminate\Database\Query\Builder; class Loop extends Statement { protected function run($siykeiywomwwuoiw) { return $this->igyyscwegckkkkya($siykeiywomwwuoiw); } }
