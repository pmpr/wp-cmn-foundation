<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675fac6c7c17d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Boolean extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\164\x69\x6e\171\x69\x6e\x74"); parent::__construct("\142\x6f\157\154\x65\x61\x6e", $aokagokqyuysuksm, $meqocwsecsywiiqs); $this->iwwmociiuayuwssq(function ($eqgoocgaqwqcimie) { if ($this->caokeucsksukesyo()->gyecsegqciqykomu()->ascqkksqiiwaouic($eqgoocgaqwqcimie)) { $eqgoocgaqwqcimie = $this->caokeucsksukesyo()->wgqqgewcmcemoewo()->cuoygaaeqeqcuggu(IconInterface::sucyqiucaqowyomk, ["\x63\x6c\x61\x73\163" => "\151\143\157\156\55\x73\x75\143\x63\x65\163\x73"]); } else { $eqgoocgaqwqcimie = $this->caokeucsksukesyo()->wgqqgewcmcemoewo()->cuoygaaeqeqcuggu(IconInterface::kcyyouekgyaqyqak, ["\x63\154\141\x73\163" => "\x69\x63\157\x6e\55\x64\x61\x6e\x67\145\162"]); } return $eqgoocgaqwqcimie; }); $this->aguakyuusmksagai()->eyygsasuqmommkua(0); } }
