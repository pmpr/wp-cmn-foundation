<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675fac6c7c17d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class NoneSchema extends Schema { public function __construct(string $aokagokqyuysuksm) { parent::__construct("\156\x6f\156\145\x73\x63\150\145\155\x61", $aokagokqyuysuksm); } }
