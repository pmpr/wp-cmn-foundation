<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6723ec7ab976d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class DateTime extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { parent::__construct("\x64\141\164\145\164\151\x6d\145", $aokagokqyuysuksm, $meqocwsecsywiiqs); $eqwoegegiamegqsm = $this->caokeucsksukesyo()->skckwsgymkimyuwo(); $this->iwwmociiuayuwssq([$eqwoegegiamegqsm, "\167\x67\151\145\143\x71\143\x67\141\153\x6b\x61\x75\171\167\165"]); } }
