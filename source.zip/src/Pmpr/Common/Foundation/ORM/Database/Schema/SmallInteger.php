<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678030cf21023             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class SmallInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\163\155\141\x6c\x6c\x69\x6e\164"); parent::__construct("\163\155\x61\154\x6c\111\x6e\x74\x65\147\145\x72", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
