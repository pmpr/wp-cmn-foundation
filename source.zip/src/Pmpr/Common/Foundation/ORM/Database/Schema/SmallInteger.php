<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d8808b3d38             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class SmallInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\x73\155\x61\154\154\x69\x6e\x74"); parent::__construct("\163\155\141\x6c\154\x49\x6e\164\145\147\x65\x72", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
