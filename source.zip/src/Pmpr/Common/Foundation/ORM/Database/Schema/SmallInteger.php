<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67522ae918e5f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class SmallInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\163\x6d\x61\154\154\x69\x6e\x74"); parent::__construct("\163\x6d\141\154\x6c\x49\x6e\164\145\x67\145\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
