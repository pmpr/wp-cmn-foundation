<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67235720c72e8             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class SmallInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\x73\155\x61\154\x6c\x69\x6e\x74"); parent::__construct("\163\155\141\154\154\111\156\164\145\x67\145\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
