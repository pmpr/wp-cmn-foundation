<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6714d8c066478             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class SmallInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\x73\155\x61\154\x6c\x69\x6e\164"); parent::__construct("\163\155\x61\154\x6c\x49\156\x74\145\x67\x65\x72", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
