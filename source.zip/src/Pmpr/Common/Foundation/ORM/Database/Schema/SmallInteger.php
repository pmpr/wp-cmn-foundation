<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b649567cd             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class SmallInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\163\x6d\141\x6c\x6c\x69\x6e\164"); parent::__construct("\163\155\141\154\x6c\111\156\164\145\x67\x65\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
