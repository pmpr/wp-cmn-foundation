<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4df64db6b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class SmallInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\163\x6d\141\x6c\x6c\x69\x6e\x74"); parent::__construct("\163\x6d\141\154\154\x49\x6e\164\145\147\x65\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
