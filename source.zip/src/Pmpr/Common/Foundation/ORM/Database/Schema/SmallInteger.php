<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678038cba6aad             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class SmallInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\163\155\141\x6c\154\151\156\x74"); parent::__construct("\163\155\x61\x6c\154\x49\x6e\164\145\147\x65\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
