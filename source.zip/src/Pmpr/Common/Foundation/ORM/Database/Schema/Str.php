<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67143a3375b94             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class Str extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\166\x61\x72\x63\150\141\x72"); parent::__construct("\x73\164\x72\x69\156\147", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
