<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67abd9c8f1e03             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class Str extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\166\141\x72\x63\x68\141\x72"); parent::__construct("\x73\164\x72\x69\156\x67", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
