<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6799ffdc32257             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class Str extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\166\x61\162\x63\x68\x61\x72"); parent::__construct("\163\x74\162\x69\156\147", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
