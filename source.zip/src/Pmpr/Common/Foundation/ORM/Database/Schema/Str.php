<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67522ae918e5f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class Str extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\166\141\x72\x63\150\141\x72"); parent::__construct("\x73\x74\x72\x69\156\x67", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
