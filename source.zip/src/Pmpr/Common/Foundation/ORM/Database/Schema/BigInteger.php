<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67abd9c8f1e03             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class BigInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\x62\151\147\151\156\x74"); parent::__construct("\x62\x69\x67\111\x6e\164\145\x67\x65\x72", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
