<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4df64db6b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class BigInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\142\x69\147\x69\x6e\164"); parent::__construct("\142\x69\x67\x49\156\164\x65\x67\145\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
