<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d8808b3d38             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class BigInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\x62\x69\147\151\156\164"); parent::__construct("\142\151\x67\111\156\164\145\147\x65\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
