<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d83a3160ed             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class BigInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\x62\151\147\151\x6e\164"); parent::__construct("\x62\x69\147\111\x6e\164\x65\x67\x65\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
