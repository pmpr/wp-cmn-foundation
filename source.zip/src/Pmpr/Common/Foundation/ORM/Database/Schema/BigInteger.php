<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d43c49e811             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class BigInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\142\151\x67\x69\156\164"); parent::__construct("\142\x69\147\111\x6e\x74\145\147\x65\x72", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
