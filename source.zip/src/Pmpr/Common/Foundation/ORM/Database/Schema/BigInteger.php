<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67143a3375b94             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class BigInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\142\151\147\x69\156\x74"); parent::__construct("\142\151\147\111\156\x74\x65\x67\x65\x72", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
