<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6799ffdc32257             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class BigInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\142\x69\147\151\x6e\x74"); parent::__construct("\x62\x69\x67\x49\156\x74\x65\147\x65\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
