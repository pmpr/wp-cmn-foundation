<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678030cf21023             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM\Database\Schema; class BigInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\142\x69\x67\x69\156\164"); parent::__construct("\142\x69\x67\x49\x6e\x74\145\x67\x65\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
