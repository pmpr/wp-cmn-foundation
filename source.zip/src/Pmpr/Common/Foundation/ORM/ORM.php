<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d8808b3d38             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM; use Pmpr\Common\Foundation\Container\Container; class ORM extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x61\x64\x64\x5f\155\x65\156\x75\x5f\x63\154\x61\x73\163\x65\x73", [$this, "\x71\x71\x67\x69\x67\x69\165\165\143\x6f\155\x73\x77\143\x79\147"]); } public function mameiwsayuyquoeq() { if ($this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq(Ajax::wiysygukkaksueso)) { Ajax::symcgieuakksimmu(); } } public function qqgigiuucomswcyg($ewuukoycimkekouc) { foreach ($ewuukoycimkekouc as $uusmaiomayssaecw => $icwicymcioeyeyek) { if (isset($icwicymcioeyeyek[2]) && ($aaokuekaimigoyue = $icwicymcioeyeyek[2])) { $gaeqamemwmwsyukm = $this->ocksiywmkyaqseou("{$aaokuekaimigoyue}\x5f\142\165\142\142\x6c\145\137\x6e\157\164\x69\x66\151\143\x61\164\x69\x6f\x6e\163", 0); if ($gaeqamemwmwsyukm > 0) { $ewuukoycimkekouc[$uusmaiomayssaecw][0] .= $this->caokeucsksukesyo()->wmkogisswkckmeua()->uyouiyyykmoqmicg($gaeqamemwmwsyukm); } } } return $ewuukoycimkekouc; } }
