<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6705246332371             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\ORM; class ORM extends Common { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x61\144\x64\x5f\x6d\x65\x6e\165\137\x63\x6c\141\x73\x73\145\x73", [$this, "\x71\161\147\151\147\x69\x75\165\143\157\155\163\x77\143\x79\x67"]); } public function mameiwsayuyquoeq() { if ($this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq(Ajax::wiysygukkaksueso)) { Ajax::symcgieuakksimmu(); } } public function qqgigiuucomswcyg($ewuukoycimkekouc) { foreach ($ewuukoycimkekouc as $uusmaiomayssaecw => $icwicymcioeyeyek) { if (isset($icwicymcioeyeyek[2]) && ($aaokuekaimigoyue = $icwicymcioeyeyek[2])) { $gaeqamemwmwsyukm = $this->ocksiywmkyaqseou("{$aaokuekaimigoyue}\x5f\x62\x75\142\142\x6c\145\x5f\x6e\x6f\164\151\x66\151\x63\141\164\151\157\x6e\x73", 0); if ($gaeqamemwmwsyukm > 0) { $ewuukoycimkekouc[$uusmaiomayssaecw][0] .= $this->caokeucsksukesyo()->wmkogisswkckmeua()->uyouiyyykmoqmicg($gaeqamemwmwsyukm); } } } return $ewuukoycimkekouc; } }
