<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce38dda53fd             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator; use Pmpr\Common\Foundation\FormGenerator\Backend\Backend; class FormGenerator extends Common { public function mameiwsayuyquoeq() { Backend::ksyueceqagwomguk(); } }
