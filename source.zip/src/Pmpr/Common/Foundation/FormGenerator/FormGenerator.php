<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cf4bac87f58             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator; use Pmpr\Common\Foundation\FormGenerator\Backend\Backend; class FormGenerator extends Common { public function mameiwsayuyquoeq() { Backend::ksyueceqagwomguk(); } }
