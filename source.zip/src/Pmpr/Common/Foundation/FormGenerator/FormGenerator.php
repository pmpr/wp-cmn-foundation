<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d2f79b4e2f3             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator; use Pmpr\Common\Foundation\FormGenerator\Backend\Backend; class FormGenerator extends Common { public function mameiwsayuyquoeq() { Backend::ksyueceqagwomguk(); } }
