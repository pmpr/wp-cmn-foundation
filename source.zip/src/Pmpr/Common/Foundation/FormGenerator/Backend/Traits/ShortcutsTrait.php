<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68b43fcd85ca1             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Traits; trait ShortcutsTrait { protected $placeholders = []; public function auqyiaissiuomqgs() { return $this->placeholders; } public function uokyeqicycwwikwi(string $uusmaiomayssaecw, string $meqocwsecsywiiqs) : self { $this->placeholders[$uusmaiomayssaecw] = $meqocwsecsywiiqs; return $this; } public function euokiigekgwygigi(array $iyuoemwqumwyekia) : self { foreach ($iyuoemwqumwyekia as $uusmaiomayssaecw => $meqocwsecsywiiqs) { $this->uokyeqicycwwikwi($uusmaiomayssaecw, $meqocwsecsywiiqs); } return $this; } public function cosayasseegkqiii() : self { $iyuoemwqumwyekia = $this->auqyiaissiuomqgs(); if (is_array($iyuoemwqumwyekia)) { $this->placeholders = $this->caokeucsksukesyo()->wmkogisswkckmeua()->cosayasseegkqiii($iyuoemwqumwyekia); } return $this; } }
