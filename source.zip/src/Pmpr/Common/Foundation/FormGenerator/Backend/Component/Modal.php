<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce373d0ef0a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Component; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\FormGenerator\Backend\Traits\SegmentsTrait; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Modal extends Component { use SegmentsTrait; protected ?string $contentTemplate = null; public function qiccuiwooiquycsg() { if ($this->mwikyscisascoeea()) { goto wsemeeocquawyauo; } $yyauwyaeewsickwk = $this->caokeucsksukesyo()->owgcciayoweymuws(); $this->id = $yyauwyaeewsickwk->ogimogiceeekegoi($yyauwyaeewsickwk->mkwcwqkqeqkqyggc(static::class)); wsemeeocquawyauo: if ($this->contentTemplate) { goto ocgkwqqmgasuoies; } $this->contentTemplate = $this->eskggqsasgsiommy($this->mwikyscisascoeea()); ocgkwqqmgasuoies: $this->type = Constants::ismwycwsasweqomi; $this->template = Constants::ismwycwsasweqomi; $this->templateClass = self::class; } public function rsysgcucogueguuk() : array { return []; } public function uqawesackiomqgga($kkeqqkkkqwkocsyu, array $ywmkwiwkosakssii = []) : ?array { $kkeqqkkkqwkocsyu["\143\154\x6f\x73\x65\137\x69\143\x6f\x6e"] = IconInterface::ucomcyskmkiqysee; return $kkeqqkkkqwkocsyu; } }
