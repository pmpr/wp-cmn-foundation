<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f2a5b59cf46             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Component; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\FormGenerator\Backend\Traits\SegmentsTrait; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Modal extends Component { use SegmentsTrait; protected ?string $contentTemplate = null; public function qiccuiwooiquycsg() { if ($this->mwikyscisascoeea()) { goto ysswaukcymggikui; } $yyauwyaeewsickwk = $this->caokeucsksukesyo()->owgcciayoweymuws(); $this->id = $yyauwyaeewsickwk->ogimogiceeekegoi($yyauwyaeewsickwk->mkwcwqkqeqkqyggc(static::class)); ysswaukcymggikui: if ($this->contentTemplate) { goto uksgyweoymomgqos; } $this->contentTemplate = $this->eskggqsasgsiommy($this->mwikyscisascoeea()); uksgyweoymomgqos: $this->type = Constants::ismwycwsasweqomi; $this->template = Constants::ismwycwsasweqomi; $this->templateClass = self::class; } public function rsysgcucogueguuk() : array { return []; } public function uqawesackiomqgga($kkeqqkkkqwkocsyu, array $ywmkwiwkosakssii = []) : ?array { $kkeqqkkkqwkocsyu["\143\x6c\157\x73\145\x5f\151\143\x6f\156"] = IconInterface::ucomcyskmkiqysee; return $kkeqqkkkqwkocsyu; } }
