<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d2f79b4e2f3             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Field; class SwitchCheckbox extends Checkbox { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm); $this->aseocggwwegcmqes("\163\167\151\164\x63\150"); } public function qgsieamsswkgysow(array $ywmkwiwkosakssii = []) : void { $this->igiywquyccyiaucw("\x61\x63\164\x69\x76\x65\x2d\x74\151\164\154\x65", __("\x4f\116", PR__CMN__FOUNDATION))->igiywquyccyiaucw("\151\x6e\141\x63\164\x69\x76\x65\55\x74\x69\164\154\145", __("\x4f\106\x46", PR__CMN__FOUNDATION)); parent::qgsieamsswkgysow($ywmkwiwkosakssii); } }
