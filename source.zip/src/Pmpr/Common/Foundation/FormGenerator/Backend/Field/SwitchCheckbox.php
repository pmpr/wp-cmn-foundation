<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f6c272cccf4             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Field; class SwitchCheckbox extends Checkbox { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm); $this->aseocggwwegcmqes("\x73\167\x69\x74\143\150"); } public function qgsieamsswkgysow(array $ywmkwiwkosakssii = []) : void { $this->igiywquyccyiaucw("\x61\x63\164\151\x76\145\x2d\x74\151\164\154\x65", __("\x4f\x4e", PR__CMN__FOUNDATION))->igiywquyccyiaucw("\x69\x6e\141\143\164\151\166\x65\x2d\164\x69\164\x6c\x65", __("\x4f\x46\x46", PR__CMN__FOUNDATION)); parent::qgsieamsswkgysow($ywmkwiwkosakssii); } }
