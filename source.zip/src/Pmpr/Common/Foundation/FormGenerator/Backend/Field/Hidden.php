<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d3160ad4f5b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Hidden extends Input { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::soqecysmeyiyyyys); } public function mawcogsqogkauasq(?string $aiamqeawckcsuaou = null) : self { if ($aiamqeawckcsuaou) { goto mcqucouuiuoagqwc; } $aiamqeawckcsuaou = $this->aakmagwggmkoiiyu(); mcqucouuiuoagqwc: $this->iygyugseyaqwywyg($this->uwkmaywceaaaigwo()->giiecckwoyiawoyy()->ikkqcccaweckukug($aiamqeawckcsuaou)); return $this; } public function iygyugseyaqwywyg($eqgoocgaqwqcimie) : self { $this->qcgocuceocquqcuw(Constants::ciyoccqkiamemcmm, $eqgoocgaqwqcimie); return parent::iygyugseyaqwywyg($eqgoocgaqwqcimie); } public function qgsieamsswkgysow(array $ywmkwiwkosakssii = []) : void { if (!(Constants::soqecysmeyiyyyys === $this->gueasuouwqysmomu())) { goto eweaaismksecwagy; } $this->kakecegieeqyyayu()->qigsyyqgewgskemg("\160\x72\x2d\x66\151\145\154\144\x2d\x69\x6e\x76\151\163\x69\142\x6c\x65"); eweaaismksecwagy: parent::qgsieamsswkgysow($ywmkwiwkosakssii); } }
