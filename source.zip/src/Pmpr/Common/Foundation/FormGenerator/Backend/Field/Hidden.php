<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d8c7809438d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Hidden extends Input { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::soqecysmeyiyyyys); } public function mawcogsqogkauasq(?string $aiamqeawckcsuaou = null) : self { if ($aiamqeawckcsuaou) { goto amoygaweoeymiuiy; } $aiamqeawckcsuaou = $this->aakmagwggmkoiiyu(); amoygaweoeymiuiy: $this->iygyugseyaqwywyg($this->uwkmaywceaaaigwo()->giiecckwoyiawoyy()->ikkqcccaweckukug($aiamqeawckcsuaou)); return $this; } public function iygyugseyaqwywyg($eqgoocgaqwqcimie) : self { $this->qcgocuceocquqcuw(Constants::ciyoccqkiamemcmm, $eqgoocgaqwqcimie); return parent::iygyugseyaqwywyg($eqgoocgaqwqcimie); } public function qgsieamsswkgysow(array $ywmkwiwkosakssii = []) : void { if (!(Constants::soqecysmeyiyyyys === $this->gueasuouwqysmomu())) { goto kcomueysiyyqagus; } $this->kakecegieeqyyayu()->qigsyyqgewgskemg("\x70\x72\55\x66\x69\145\x6c\144\x2d\151\156\x76\151\163\151\x62\x6c\x65"); kcomueysiyyqagus: parent::qgsieamsswkgysow($ywmkwiwkosakssii); } }
