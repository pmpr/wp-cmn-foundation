<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e16aefd43f6             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Hidden extends Input { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::soqecysmeyiyyyys); } public function mawcogsqogkauasq(?string $aiamqeawckcsuaou = null) : self { if ($aiamqeawckcsuaou) { goto amoygaweoeymiuiy; } $aiamqeawckcsuaou = $this->aakmagwggmkoiiyu(); amoygaweoeymiuiy: $this->iygyugseyaqwywyg($this->uwkmaywceaaaigwo()->giiecckwoyiawoyy()->ikkqcccaweckukug($aiamqeawckcsuaou)); return $this; } public function iygyugseyaqwywyg($eqgoocgaqwqcimie) : self { $this->qcgocuceocquqcuw(Constants::ciyoccqkiamemcmm, $eqgoocgaqwqcimie); return parent::iygyugseyaqwywyg($eqgoocgaqwqcimie); } public function qgsieamsswkgysow(array $ywmkwiwkosakssii = []) : void { if (!(Constants::soqecysmeyiyyyys === $this->gueasuouwqysmomu())) { goto kcomueysiyyqagus; } $this->kakecegieeqyyayu()->qigsyyqgewgskemg("\x70\x72\x2d\146\151\145\154\x64\x2d\x69\x6e\166\151\x73\151\x62\154\x65"); kcomueysiyyqagus: parent::qgsieamsswkgysow($ywmkwiwkosakssii); } }
