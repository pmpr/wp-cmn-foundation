<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce3480d954f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Hidden extends Input { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::soqecysmeyiyyyys); } public function mawcogsqogkauasq(?string $aiamqeawckcsuaou = null) : self { if ($aiamqeawckcsuaou) { goto syusgosewwkoagoq; } $aiamqeawckcsuaou = $this->aakmagwggmkoiiyu(); syusgosewwkoagoq: $this->iygyugseyaqwywyg($this->uwkmaywceaaaigwo()->giiecckwoyiawoyy()->ikkqcccaweckukug($aiamqeawckcsuaou)); return $this; } public function iygyugseyaqwywyg($eqgoocgaqwqcimie) : self { $this->qcgocuceocquqcuw(Constants::ciyoccqkiamemcmm, $eqgoocgaqwqcimie); return parent::iygyugseyaqwywyg($eqgoocgaqwqcimie); } public function qgsieamsswkgysow(array $ywmkwiwkosakssii = []) : void { if (!(Constants::soqecysmeyiyyyys === $this->gueasuouwqysmomu())) { goto mcqucouuiuoagqwc; } $this->kakecegieeqyyayu()->qigsyyqgewgskemg("\x70\162\55\146\x69\x65\154\x64\x2d\x69\x6e\166\151\163\x69\x62\x6c\145"); mcqucouuiuoagqwc: parent::qgsieamsswkgysow($ywmkwiwkosakssii); } }
