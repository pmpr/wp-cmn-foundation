<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6953da8edcb6b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Field; use Pmpr\Common\Foundation\FormGenerator\Traits\SelectorTrait; use Pmpr\Common\Foundation\Interfaces\Constants; class Selector extends Field { use SelectorTrait; public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, 'selector'); $this->qcgocuceocquqcuw(Constants::squoamkioomemiyi, Constants::soqecysmeyiyyyys); $this->qigsyyqgewgskemg('pr-field-selector-input'); $this->enqueue(); } public function enqueue() { $this->caokeucsksukesyo()->usugyumcgeaaowsi()->kyiqommgeuoiocgk(); } }
