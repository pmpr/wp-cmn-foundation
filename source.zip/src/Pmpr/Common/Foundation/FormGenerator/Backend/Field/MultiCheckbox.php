<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68096110c71c5             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class MultiCheckbox extends OptionAware { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, 'multicheckbox'); $this->qcgocuceocquqcuw(Constants::squoamkioomemiyi, Constants::soqecysmeyiyyyys); } public function yiiiqewsseywemqu($eqgoocgaqwqcimie) : array { $ksaameoqigiaoigg = []; if (is_string($eqgoocgaqwqcimie) && $eqgoocgaqwqcimie) { $eqgoocgaqwqcimie = $this->caokeucsksukesyo()->owgcciayoweymuws()->queuakuqucciemcc($eqgoocgaqwqcimie); } if (is_array($eqgoocgaqwqcimie)) { $ksaameoqigiaoigg = array_keys($eqgoocgaqwqcimie); } return $ksaameoqigiaoigg; } }
