<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae85ba078b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class MultiCheckbox extends OptionAware { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, "\155\x75\154\x74\x69\x63\150\145\143\x6b\x62\157\170"); $this->qcgocuceocquqcuw(Constants::squoamkioomemiyi, Constants::soqecysmeyiyyyys); } public function yiiiqewsseywemqu($eqgoocgaqwqcimie) : array { $ksaameoqigiaoigg = []; if (!(is_string($eqgoocgaqwqcimie) && $eqgoocgaqwqcimie)) { goto ossyqogewmggmaoc; } $eqgoocgaqwqcimie = $this->caokeucsksukesyo()->owgcciayoweymuws()->queuakuqucciemcc($eqgoocgaqwqcimie); ossyqogewmggmaoc: if (!is_array($eqgoocgaqwqcimie)) { goto ggkoiouwecyiosym; } $ksaameoqigiaoigg = array_keys($eqgoocgaqwqcimie); ggkoiouwecyiosym: return $ksaameoqigiaoigg; } }
