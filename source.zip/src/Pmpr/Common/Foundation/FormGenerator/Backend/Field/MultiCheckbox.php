<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa77cb5a35c             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class MultiCheckbox extends OptionAware { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, "\x6d\x75\154\x74\151\143\x68\x65\143\x6b\x62\x6f\x78"); $this->qcgocuceocquqcuw(Constants::squoamkioomemiyi, Constants::soqecysmeyiyyyys); } public function yiiiqewsseywemqu($eqgoocgaqwqcimie) : array { $ksaameoqigiaoigg = []; if (!(is_string($eqgoocgaqwqcimie) && $eqgoocgaqwqcimie)) { goto akiuyguwqaukuugs; } $eqgoocgaqwqcimie = $this->caokeucsksukesyo()->owgcciayoweymuws()->queuakuqucciemcc($eqgoocgaqwqcimie); akiuyguwqaukuugs: if (!is_array($eqgoocgaqwqcimie)) { goto emiyocoiuwcucuwu; } $ksaameoqigiaoigg = array_keys($eqgoocgaqwqcimie); emiyocoiuwcucuwu: return $ksaameoqigiaoigg; } }
