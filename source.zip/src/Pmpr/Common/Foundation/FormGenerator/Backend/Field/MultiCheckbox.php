<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e16aefd43f6             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class MultiCheckbox extends OptionAware { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, "\155\x75\x6c\x74\x69\143\x68\145\143\153\x62\x6f\x78"); $this->qcgocuceocquqcuw(Constants::squoamkioomemiyi, Constants::soqecysmeyiyyyys); } public function yiiiqewsseywemqu($eqgoocgaqwqcimie) : array { $ksaameoqigiaoigg = []; if (!(is_string($eqgoocgaqwqcimie) && $eqgoocgaqwqcimie)) { goto kgeggsckmgcgwcqm; } $eqgoocgaqwqcimie = $this->caokeucsksukesyo()->owgcciayoweymuws()->queuakuqucciemcc($eqgoocgaqwqcimie); kgeggsckmgcgwcqm: if (!is_array($eqgoocgaqwqcimie)) { goto qimieogaimwmukmu; } $ksaameoqigiaoigg = array_keys($eqgoocgaqwqcimie); qimieogaimwmukmu: return $ksaameoqigiaoigg; } }
