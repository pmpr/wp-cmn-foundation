<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d303622917b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Traits\SectionsTrait; abstract class Section extends Component { use SectionsTrait; protected string $segment; public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse($this->caokeucsksukesyo()->mmsykuomogaqoaye()->wysmcwgiaskkoeam($this->msaksssmsuscmwaq(), $this->eooumquaoewwauoo()), [$this, "\x67\167\x67\x75\x79\161\171\151\x6d\x61\147\151\x71\x73\143\x79"]); parent::kgquecmsgcouyaya(); } public function gwguyqyimagiqscy($mgiqqesweuqmsymo) { if (!$this->mgwewyykukaawcmo()) { goto gswcoeiisamakwii; } $mgiqqesweuqmsymo = array_merge($mgiqqesweuqmsymo, $this->suuogccckocgseyg()); gswcoeiisamakwii: return $mgiqqesweuqmsymo; } public function qmgcisuuikgmqcsu() : string { return $this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->yqymaqmqiqmmmsoo(["\163\145\x67\155\145\156\x74" => $this->eooumquaoewwauoo()], $this->mggwieqomgcuskme()->oiucukewkckkwiqc()); } public function eooumquaoewwauoo() : string { return $this->segment; } }
