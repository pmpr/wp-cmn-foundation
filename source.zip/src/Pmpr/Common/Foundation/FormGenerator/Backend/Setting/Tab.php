<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1e3829f9fd             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Traits\TabsTrait; class Tab extends Component { use TabsTrait; protected string $segment = ''; protected $section = false; public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse($this->caokeucsksukesyo()->mmsykuomogaqoaye()->wysmcwgiaskkoeam($this->msaksssmsuscmwaq(), $this->eooumquaoewwauoo(), $this->kosacuuaeuweoqau(), true), [$this, "\167\161\155\x73\x61\155\x77\x61\153\165\x79\161\153\x6f\171\x79"]); parent::kgquecmsgcouyaya(); } public function wqmsamwakuyqkoyy($ywoucyskcquysiwc) { if (!$this->myomgmiksogoikuc()) { goto asoweekcciigkweo; } $ywoucyskcquysiwc = array_merge($ywoucyskcquysiwc, $this->equiyaoamqmaeckc()); asoweekcciigkweo: return $ywoucyskcquysiwc; } public function kosacuuaeuweoqau() { return $this->section; } public function eooumquaoewwauoo() : string { return $this->segment; } }
