<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678d3d485c530             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Tool; use Pmpr\Common\Foundation\FormGenerator\Backend\Traits\SectionsTrait; abstract class Section extends Component { use SectionsTrait; protected string $segment; public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse($this->ygyygikyocoymgaw("{$this->asgqmkcukouykiie()}\137\x73\x65\x67\155\145\156\x74\137{$this->eooumquaoewwauoo()}\137\x73\145\x63\164\x69\157\x6e\163"), [$this, "\x67\167\147\x75\171\161\171\151\155\141\147\x69\x71\163\x63\171"]); parent::kgquecmsgcouyaya(); } public function gwguyqyimagiqscy($mgiqqesweuqmsymo) { if ($this->mgwewyykukaawcmo()) { $mgiqqesweuqmsymo = array_merge($mgiqqesweuqmsymo, $this->suuogccckocgseyg()); } return $mgiqqesweuqmsymo; } public function eooumquaoewwauoo() : string { return $this->segment; } }
