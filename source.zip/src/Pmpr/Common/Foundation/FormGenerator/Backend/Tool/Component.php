<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678d3d485c530             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Tool; use Pmpr\Common\Foundation\Container\Traits\SingletonTrait; use Pmpr\Common\Foundation\Container\Traits\CommonTrait; use Pmpr\Common\Foundation\FormGenerator\Backend\Traits\ObjectTrait; use Pmpr\Common\Foundation\Functions\Traits\HelperTrait; use Pmpr\Common\Foundation\Functions\Traits\WrapperTrait; use Pmpr\Common\Foundation\Template\Traits\TemplateTrait; use Pmpr\Common\Foundation\Traits\HookTrait; abstract class Component { use SingletonTrait, TemplateTrait, WrapperTrait, CommonTrait, HelperTrait, ObjectTrait, HookTrait; protected string $tool; public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse($this->ygyygikyocoymgaw("\141\146\x74\x65\162\x5f\147\x65\x6e\145\x72\141\x74\145\137{$this->asgqmkcukouykiie()}\137\x70\141\156\145\154"), [$this, "\171\x6b\167\x71\x61\x75\153\153\x79\143\x6f\147\x6f\x6f\151\151"]); } public function asgqmkcukouykiie() : string { return $this->tool; } public function ykwqaukkycogooii() { } }
