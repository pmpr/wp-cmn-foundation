<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6797767677d97             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Tool; use Pmpr\Common\Foundation\Container\Traits\SingletonTrait; use Pmpr\Common\Foundation\Container\Traits\CommonTrait; use Pmpr\Common\Foundation\FormGenerator\Backend\Traits\ObjectTrait; use Pmpr\Common\Foundation\Functions\Traits\HelperTrait; use Pmpr\Common\Foundation\Functions\Traits\WrapperTrait; use Pmpr\Common\Foundation\Template\Traits\TemplateTrait; use Pmpr\Common\Foundation\Traits\HookTrait; abstract class Component { use SingletonTrait, TemplateTrait, WrapperTrait, CommonTrait, HelperTrait, ObjectTrait, HookTrait; protected string $tool; public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse($this->ygyygikyocoymgaw("\141\146\x74\x65\162\x5f\147\145\x6e\x65\162\141\164\x65\137{$this->asgqmkcukouykiie()}\x5f\x70\141\156\x65\154"), [$this, "\x79\x6b\x77\161\x61\165\x6b\153\171\143\157\x67\x6f\x6f\x69\x69"]); } public function asgqmkcukouykiie() : string { return $this->tool; } public function ykwqaukkycogooii() { } }
