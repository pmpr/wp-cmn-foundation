<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f6c272cccf4             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Tool; use Pmpr\Common\Foundation\FormGenerator\Backend\Traits\SegmentsTrait; abstract class Segment extends Component { use SegmentsTrait; public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse($this->ygyygikyocoymgaw("{$this->asgqmkcukouykiie()}\137\163\145\x67\155\x65\x6e\x74\163"), [$this, "\167\x69\145\143\x67\161\x63\155\x61\141\163\151\141\x65\157\x77"]); parent::kgquecmsgcouyaya(); } public final function wiecgqcmaasiaeow($wsqkgswwooewwekw) { if (!$this->skgwcckoyoqsascq()) { goto ummgomwmsqygiqcy; } $wsqkgswwooewwekw = array_merge($wsqkgswwooewwekw, $this->gsesiocqciggmauo()); ummgomwmsqygiqcy: return $wsqkgswwooewwekw; } }
