<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d83a3160ed             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Tool; use Pmpr\Common\Foundation\FormGenerator\Backend\Traits\SegmentsTrait; abstract class Segment extends Component { use SegmentsTrait; public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse($this->ygyygikyocoymgaw("{$this->asgqmkcukouykiie()}\x5f\163\145\x67\x6d\x65\x6e\x74\163"), [$this, "\167\151\x65\x63\147\x71\143\155\141\x61\x73\x69\x61\145\157\x77"]); parent::kgquecmsgcouyaya(); } public final function wiecgqcmaasiaeow($wsqkgswwooewwekw) { if ($this->skgwcckoyoqsascq()) { $wsqkgswwooewwekw = array_merge($wsqkgswwooewwekw, $this->gsesiocqciggmauo()); } return $wsqkgswwooewwekw; } }
