<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ced35949c89             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Model; use Pmpr\Common\Foundation\Interfaces\Constants; class Option extends Common { public function ckgmycmaukqgkosk() { $this->oyeskqayoscwciem()->guiaswksukmgageq(__("\x4f\160\164\x69\x6f\156", PR__CMN__FOUNDATION))->muuwuqssqkaieqge(__("\117\160\164\x69\x6f\x6e\163", PR__CMN__FOUNDATION)); parent::ckgmycmaukqgkosk(); } public function ewaqwooqoqmcoomi() { $this->cquokmemekqqywgi($this->gysoeyaguiyewoes(Constants::ascagqcquwgmygkm)->gswweykyogmsyawy(__("\x4b\145\171", PR__CMN__FOUNDATION)))->cquokmemekqqywgi($this->gysoeyaguiyewoes(Constants::ciyoccqkiamemcmm)->gswweykyogmsyawy(__("\126\141\154\165\x65", PR__CMN__FOUNDATION)))->cquokmemekqqywgi($this->eoaomaokwkwqyqiq(Constants::yocqkmeouaamomke)->wuuqgaekqeymecag(Origin::class)->gswweykyogmsyawy(__("\117\x70\x74\x69\157\x6e\163", PR__CMN__FOUNDATION))->eewuieiqoqmekwmw(Constants::sayycgcceusuyycg)); parent::ewaqwooqoqmcoomi(); } }
