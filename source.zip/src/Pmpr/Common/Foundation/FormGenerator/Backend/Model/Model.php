<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d3160ad4f5b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Model; use Pmpr\Common\Foundation\FormGenerator\Backend\Common; class Model extends Common { public function aqyikqugcomoqqqi() { Origin::symcgieuakksimmu(); Option::symcgieuakksimmu(); } }
