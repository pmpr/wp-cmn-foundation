<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1d819504ee             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Backend\Model; use Pmpr\Common\Foundation\ORM\DB\Model; abstract class Common extends Model { public function ckgmycmaukqgkosk() { $quowyokcwswmuois = $this->akuociswqmoigkas(); $this->oyeskqayoscwciem()->myysgyqcumekoueo()->okgmqaeuaeymaocm($quowyokcwswmuois); parent::ckgmycmaukqgkosk(); } }
