<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1d819504ee             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Traits\MultistepTrait; class Multistep extends Component { use MultistepTrait; public function qiccuiwooiquycsg() { $this->template = "\x6d\165\x6c\164\151\x73\x74\145\x70"; $this->templateClass = self::class; $this->qigsyyqgewgskemg("\160\162\55\155\x75\x6c\x74\x69\163\x74\145\160\x2d\167\x72\141\x70"); parent::qiccuiwooiquycsg(); } }
