<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678a9fdd7a21e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Traits\MultistepTrait; class Multistep extends Component { use MultistepTrait; public function qiccuiwooiquycsg() { $this->template = "\155\165\154\164\151\x73\x74\145\160"; $this->templateClass = self::class; $this->qigsyyqgewgskemg("\x70\162\x2d\155\165\154\164\151\163\x74\145\160\55\x77\x72\141\x70"); parent::qiccuiwooiquycsg(); } }
