<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ced35949c89             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Traits\MultistepTrait; class Multistep extends Component { use MultistepTrait; public function qiccuiwooiquycsg() { $this->template = "\x6d\x75\x6c\164\151\163\x74\x65\x70"; $this->templateClass = self::class; $this->qigsyyqgewgskemg("\160\162\55\155\165\x6c\x74\x69\163\x74\145\160\x2d\167\162\141\x70"); parent::qiccuiwooiquycsg(); } }
