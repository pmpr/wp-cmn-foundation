<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1e3829f9fd             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Traits\MultistepTrait; class Multistep extends Component { use MultistepTrait; public function qiccuiwooiquycsg() { $this->template = "\155\165\x6c\x74\x69\x73\164\145\160"; $this->templateClass = self::class; $this->qigsyyqgewgskemg("\160\162\x2d\155\165\154\164\151\x73\x74\x65\160\55\167\162\x61\x70"); parent::qiccuiwooiquycsg(); } }
