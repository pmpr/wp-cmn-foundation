<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67d02dbf4efea             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Traits\MultistepTrait; class Multistep extends Component { use MultistepTrait; public function qiccuiwooiquycsg() { $this->template = 'multistep'; $this->templateClass = self::class; $this->qigsyyqgewgskemg('pr-multistep-wrap'); parent::qiccuiwooiquycsg(); } }
