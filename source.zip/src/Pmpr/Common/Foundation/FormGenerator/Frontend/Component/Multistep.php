<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce54af64690             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Traits\MultistepTrait; class Multistep extends Component { use MultistepTrait; public function qiccuiwooiquycsg() { $this->template = "\x6d\165\x6c\164\x69\x73\x74\x65\x70"; $this->templateClass = self::class; $this->qigsyyqgewgskemg("\160\x72\x2d\x6d\x75\154\164\x69\163\x74\x65\x70\55\167\162\141\160"); parent::qiccuiwooiquycsg(); } }
