<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f15ee33c813             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Traits\MultistepTrait; class Multistep extends Component { use MultistepTrait; public function qiccuiwooiquycsg() { $this->template = "\x6d\x75\x6c\x74\x69\163\x74\x65\x70"; $this->templateClass = self::class; $this->qigsyyqgewgskemg("\160\162\55\x6d\165\x6c\x74\x69\163\x74\145\x70\55\x77\x72\x61\160"); parent::qiccuiwooiquycsg(); } }
