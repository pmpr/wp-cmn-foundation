<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6714d8c066478             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Traits\MultistepTrait; class Multistep extends Component { use MultistepTrait; public function qiccuiwooiquycsg() { $this->template = "\155\x75\x6c\164\151\x73\x74\x65\x70"; $this->templateClass = self::class; $this->qigsyyqgewgskemg("\x70\x72\55\x6d\x75\x6c\164\x69\x73\x74\x65\x70\x2d\167\162\141\160"); parent::qiccuiwooiquycsg(); } }
