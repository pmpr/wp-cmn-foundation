<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d1dbc474879             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Traits\MultistepTrait; class Multistep extends Component { use MultistepTrait; public function qiccuiwooiquycsg() { $this->template = "\155\165\154\164\151\x73\x74\x65\160"; $this->templateClass = self::class; $this->qigsyyqgewgskemg("\160\x72\55\155\x75\154\x74\151\x73\x74\145\x70\x2d\167\x72\x61\x70"); parent::qiccuiwooiquycsg(); } }
