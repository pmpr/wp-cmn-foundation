<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d2f79b4e2f3             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Traits\MultistepTrait; class Multistep extends Component { use MultistepTrait; public function qiccuiwooiquycsg() { $this->template = "\155\165\x6c\x74\151\x73\x74\145\x70"; $this->templateClass = self::class; $this->qigsyyqgewgskemg("\x70\162\55\x6d\x75\154\x74\x69\163\x74\145\x70\55\167\x72\x61\160"); parent::qiccuiwooiquycsg(); } }
