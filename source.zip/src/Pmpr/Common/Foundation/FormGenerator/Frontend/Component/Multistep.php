<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cf4bac87f58             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Traits\MultistepTrait; class Multistep extends Component { use MultistepTrait; public function qiccuiwooiquycsg() { $this->template = "\x6d\165\154\x74\x69\163\x74\x65\160"; $this->templateClass = self::class; $this->qigsyyqgewgskemg("\x70\x72\x2d\155\165\x6c\x74\x69\x73\164\x65\160\x2d\x77\162\x61\160"); parent::qiccuiwooiquycsg(); } }
