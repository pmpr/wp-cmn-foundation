<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6723ec7ab976d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Traits\MultistepTrait; class Multistep extends Component { use MultistepTrait; public function qiccuiwooiquycsg() { $this->template = "\155\x75\154\164\x69\x73\164\x65\160"; $this->templateClass = self::class; $this->qigsyyqgewgskemg("\160\x72\x2d\155\165\154\164\151\163\x74\145\160\x2d\x77\x72\141\160"); parent::qiccuiwooiquycsg(); } }
