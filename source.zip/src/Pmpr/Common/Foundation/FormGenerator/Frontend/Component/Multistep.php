<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae85ba078b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Traits\MultistepTrait; class Multistep extends Component { use MultistepTrait; public function qiccuiwooiquycsg() { $this->template = "\155\165\154\x74\151\163\x74\145\160"; $this->templateClass = self::class; $this->qigsyyqgewgskemg("\160\162\55\155\x75\x6c\x74\x69\x73\164\145\160\x2d\167\x72\x61\160"); parent::qiccuiwooiquycsg(); } }
