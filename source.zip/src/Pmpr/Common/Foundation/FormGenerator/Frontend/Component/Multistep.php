<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6796bb94d52e6             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Traits\MultistepTrait; class Multistep extends Component { use MultistepTrait; public function qiccuiwooiquycsg() { $this->template = "\155\165\x6c\x74\151\163\164\145\160"; $this->templateClass = self::class; $this->qigsyyqgewgskemg("\x70\x72\55\x6d\165\x6c\164\x69\x73\x74\x65\160\55\x77\162\x61\160"); parent::qiccuiwooiquycsg(); } }
