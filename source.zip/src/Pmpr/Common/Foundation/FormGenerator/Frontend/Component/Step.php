<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6793da3275295             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Component; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Button; use Pmpr\Common\Foundation\FormGenerator\Traits\FieldsTrait; use Pmpr\Common\Foundation\FormGenerator\Traits\StepTrait; class Step extends Component { use StepTrait, FieldsTrait; public function qiccuiwooiquycsg() { $this->templateClass = self::class; $this->esmoocwowesymqma(); parent::qiccuiwooiquycsg(); } private function cyeuiyggkcqmoecc(?string $meqocwsecsywiiqs, ?string $uusmaiomayssaecw) : ?Button { $gskauacumcmekigs = null; if ($meqocwsecsywiiqs) { $gskauacumcmekigs = $this->qoeiescseggagsqs($uusmaiomayssaecw)->gswweykyogmsyawy($meqocwsecsywiiqs)->qiqckusosoksgaua()->ckccqugcgucieugo()->eskgwaywimqcwcyy("\x6d\x75\154\164\x69\x73\164\x65\x70\x2d\x74\x79\160\x65", "\x61\143\164\151\x6f\156\x2d{$uusmaiomayssaecw}"); } return $gskauacumcmekigs; } }
