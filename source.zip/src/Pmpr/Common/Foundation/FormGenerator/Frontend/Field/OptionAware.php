<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             695a950e08368             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\FormGenerator\Traits\OptionsTrait; class OptionAware extends Field { use OptionsTrait; }
