<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671269d4e15e3             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Nonce extends Input { public function __construct(?string $aokagokqyuysuksm) { parent::__construct($aokagokqyuysuksm, Constants::soqecysmeyiyyyys); } public function uwaiagiwycmiokqi(?string $aiamqeawckcsuaou = '', ?string $ymqmyyeuycgmigyo = '') : self { $this->kakecegieeqyyayu()->eskgwaywimqcwcyy(Constants::NAME, $ymqmyyeuycgmigyo)->eskgwaywimqcwcyy(Constants::uqgcmmosieyimiku, $aiamqeawckcsuaou)->qigsyyqgewgskemg("\x6e\157\x6e\143\x65\55\x63\157\156\x74\141\151\x6e\x65\162"); return $this; } public function vkwmugmaqcawygqm(string $aiamqeawckcsuaou, string $ymqmyyeuycgmigyo = Constants::icwieiwoqeocywss, bool $emaumsqyoyqcimcm = true) : self { $gwgqcsmomamyqsmy = $this->uwkmaywceaaaigwo()->ogciwyoqgciosgcw()->ewgquygaowykwacc($aiamqeawckcsuaou, $ymqmyyeuycgmigyo, $emaumsqyoyqcimcm, false); $this->igiywquyccyiaucw(Constants::oomaageiyqkaiekk, $gwgqcsmomamyqsmy); return $this; } }
