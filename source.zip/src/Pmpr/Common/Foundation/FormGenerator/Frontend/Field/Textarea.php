<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6799ffdc32257             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Textarea extends Field { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::msmkiouagmwoseqk); $this->qigsyyqgewgskemg("\146\x6f\162\x6d\x2d\x63\x6f\x6e\x74\162\x6f\154")->askmmuauqcuuqsea("\x54\x65\x78\164\141\x72\x65\141")->kakecegieeqyyayu()->qigsyyqgewgskemg("\146\157\162\x6d\55\x67\x72\x6f\x75\160"); } public function qsecygiycssgacqs($essikcmqiyqaqoaq) : self { $this->igmaewykumgwoaoy("\162\157\167\163", (string) $essikcmqiyqaqoaq); return $this; } public function uqamgcwceyasmoki(int $essikcmqiyqaqoaq = 2) : self { $this->qigsyyqgewgskemg(sprintf("\x68\55\x25\144\x70\x78", 100 * $essikcmqiyqaqoaq)); return parent::uqamgcwceyasmoki(); } }
