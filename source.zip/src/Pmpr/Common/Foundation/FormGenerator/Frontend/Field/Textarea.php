<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6876c61308a40             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Textarea extends Field { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::msmkiouagmwoseqk); $this->qigsyyqgewgskemg('form-control')->askmmuauqcuuqsea('Textarea')->kakecegieeqyyayu()->qigsyyqgewgskemg('form-group'); } public function qsecygiycssgacqs($essikcmqiyqaqoaq) : self { $this->igmaewykumgwoaoy('rows', (string) $essikcmqiyqaqoaq); return $this; } public function uqamgcwceyasmoki(int $essikcmqiyqaqoaq = 2) : self { $this->qigsyyqgewgskemg(sprintf('h-%dpx', 100 * $essikcmqiyqaqoaq)); return parent::uqamgcwceyasmoki(); } }
