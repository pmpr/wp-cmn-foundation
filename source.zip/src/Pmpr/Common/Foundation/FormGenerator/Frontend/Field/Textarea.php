<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce373d0ef0a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Textarea extends Field { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::msmkiouagmwoseqk); $this->qigsyyqgewgskemg("\x66\x6f\162\x6d\55\x63\157\x6e\164\x72\157\x6c")->kakecegieeqyyayu()->qigsyyqgewgskemg("\146\x6f\162\x6d\55\x67\x72\x6f\x75\160"); } public function qsecygiycssgacqs($essikcmqiyqaqoaq) : self { $this->igmaewykumgwoaoy("\162\157\167\x73", (string) $essikcmqiyqaqoaq); return $this; } public function uqamgcwceyasmoki(int $essikcmqiyqaqoaq = 2) : self { $this->qigsyyqgewgskemg(sprintf("\x68\55\x25\x64\x70\170", 100 * $essikcmqiyqaqoaq)); return parent::uqamgcwceyasmoki(); } }
