<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d8c7809438d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Textarea extends Field { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::msmkiouagmwoseqk); $this->qigsyyqgewgskemg("\x66\157\162\155\55\x63\157\156\164\162\x6f\154")->kakecegieeqyyayu()->qigsyyqgewgskemg("\x66\x6f\162\155\x2d\x67\162\x6f\x75\x70"); } public function qsecygiycssgacqs($essikcmqiyqaqoaq) : self { $this->igmaewykumgwoaoy("\162\x6f\x77\x73", (string) $essikcmqiyqaqoaq); return $this; } public function uqamgcwceyasmoki(int $essikcmqiyqaqoaq = 2) : self { $this->qigsyyqgewgskemg(sprintf("\150\55\x25\x64\x70\170", 100 * $essikcmqiyqaqoaq)); return parent::uqamgcwceyasmoki(); } }
