<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d31f49a6686             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\FormGenerator\Traits\TextFieldTrait; use Pmpr\Common\Foundation\Interfaces\Constants; class Text extends Input { use TextFieldTrait; public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::TEXT); $this->qigsyyqgewgskemg("\146\x6f\x72\x6d\55\x63\157\156\164\x72\157\154")->askmmuauqcuuqsea("\124\x65\x78\164")->kakecegieeqyyayu()->qigsyyqgewgskemg("\x66\157\x72\x6d\x2d\x67\x72\x6f\165\160"); } }
