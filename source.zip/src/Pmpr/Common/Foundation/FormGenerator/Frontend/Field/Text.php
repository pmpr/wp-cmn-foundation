<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebdb08957             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\FormGenerator\Traits\TextFieldTrait; use Pmpr\Common\Foundation\Interfaces\Constants; class Text extends Input { use TextFieldTrait; public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::TEXT); $this->qigsyyqgewgskemg("\x66\157\x72\x6d\55\x63\157\156\x74\162\x6f\154")->askmmuauqcuuqsea("\124\x65\x78\164")->kakecegieeqyyayu()->qigsyyqgewgskemg("\x66\157\x72\x6d\x2d\x67\162\157\165\160"); } }
