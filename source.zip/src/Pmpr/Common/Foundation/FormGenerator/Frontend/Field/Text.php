<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec08eec428e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\FormGenerator\Traits\TextFieldTrait; use Pmpr\Common\Foundation\Interfaces\Constants; class Text extends Input { use TextFieldTrait; public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::TEXT); $this->qigsyyqgewgskemg("\146\x6f\162\155\x2d\143\x6f\156\x74\162\x6f\x6c")->askmmuauqcuuqsea("\124\145\170\164")->kakecegieeqyyayu()->qigsyyqgewgskemg("\x66\157\162\x6d\55\147\x72\x6f\x75\x70"); } }
