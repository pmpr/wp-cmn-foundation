<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b649567cd             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\FormGenerator\Traits\TextFieldTrait; use Pmpr\Common\Foundation\Interfaces\Constants; class Text extends Input { use TextFieldTrait; public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::TEXT); $this->qigsyyqgewgskemg("\x66\x6f\x72\155\55\x63\157\x6e\x74\162\157\x6c")->askmmuauqcuuqsea("\124\145\x78\x74")->kakecegieeqyyayu()->qigsyyqgewgskemg("\146\157\162\155\55\147\162\157\165\x70"); } }
