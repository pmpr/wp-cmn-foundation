<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6791523fa4639             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\FormGenerator\Traits\TextFieldTrait; use Pmpr\Common\Foundation\Interfaces\Constants; class Text extends Input { use TextFieldTrait; public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::TEXT); $this->qigsyyqgewgskemg("\146\157\162\x6d\55\x63\x6f\156\164\x72\157\x6c")->askmmuauqcuuqsea("\x54\145\x78\x74")->kakecegieeqyyayu()->qigsyyqgewgskemg("\x66\x6f\x72\155\55\147\x72\157\x75\x70"); } }
