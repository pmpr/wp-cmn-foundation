<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cf4bac87f58             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\FormGenerator\Traits\TextFieldTrait; use Pmpr\Common\Foundation\Interfaces\Constants; class Text extends Input { use TextFieldTrait; public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::TEXT); $this->qigsyyqgewgskemg("\x66\x6f\162\x6d\55\x63\157\x6e\x74\x72\157\154")->askmmuauqcuuqsea("\124\145\x78\x74")->kakecegieeqyyayu()->qigsyyqgewgskemg("\x66\x6f\162\x6d\55\147\162\x6f\x75\160"); } }
