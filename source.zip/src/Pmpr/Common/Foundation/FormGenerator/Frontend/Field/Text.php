<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1d819504ee             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\FormGenerator\Traits\TextFieldTrait; use Pmpr\Common\Foundation\Interfaces\Constants; class Text extends Input { use TextFieldTrait; public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::TEXT); $this->qigsyyqgewgskemg("\x66\x6f\x72\155\x2d\143\157\156\x74\x72\x6f\x6c")->askmmuauqcuuqsea("\124\x65\170\x74")->kakecegieeqyyayu()->qigsyyqgewgskemg("\x66\x6f\x72\155\x2d\147\162\157\x75\160"); } }
