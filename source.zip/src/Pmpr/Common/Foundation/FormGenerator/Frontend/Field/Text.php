<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6714d8c066478             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\FormGenerator\Traits\TextFieldTrait; use Pmpr\Common\Foundation\Interfaces\Constants; class Text extends Input { use TextFieldTrait; public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::TEXT); $this->qigsyyqgewgskemg("\x66\157\x72\155\x2d\143\x6f\156\164\x72\x6f\x6c")->askmmuauqcuuqsea("\x54\x65\x78\x74")->kakecegieeqyyayu()->qigsyyqgewgskemg("\x66\157\162\155\55\147\162\157\165\x70"); } }
