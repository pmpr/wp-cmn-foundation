<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d2f79b4e2f3             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; class Media extends File { public function scmsukieucuekmki() : self { $this->ycueqsmmommygueu(); return $this->askmmuauqcuuqsea("\x41\x76\141\x74\141\x72"); } public function ycueqsmmommygueu(array $yemgmmgogcwccuky = []) : self { return $this->hsgemasguekogiui(["\152\160\x67", "\152\160\x65\147", "\x77\x65\x62\160"], "\151\155\141\x67\x65", $yemgmmgogcwccuky); } }
