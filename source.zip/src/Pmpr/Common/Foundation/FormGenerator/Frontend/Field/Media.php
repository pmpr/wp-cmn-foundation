<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675fac6c7c17d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; class Media extends File { public function scmsukieucuekmki() : self { $this->ycueqsmmommygueu(); return $this->askmmuauqcuuqsea("\x41\166\141\164\x61\x72"); } public function ycueqsmmommygueu(array $yemgmmgogcwccuky = []) : self { return $this->hsgemasguekogiui(["\x6a\160\x67", "\x6a\160\x65\x67", "\x77\x65\142\160"], "\151\155\141\x67\145", $yemgmmgogcwccuky); } }
