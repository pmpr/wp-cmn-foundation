<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             679574b80d243             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; class Media extends File { public function scmsukieucuekmki() : self { $this->ycueqsmmommygueu(); return $this->askmmuauqcuuqsea("\x41\x76\x61\x74\x61\x72"); } public function ycueqsmmommygueu(array $yemgmmgogcwccuky = []) : self { return $this->hsgemasguekogiui(["\x6a\x70\x67", "\152\160\x65\x67", "\x77\145\142\x70"], "\x69\x6d\141\x67\x65", $yemgmmgogcwccuky); } }
