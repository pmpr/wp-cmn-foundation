<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68a37199e98c9             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; class Media extends File { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm); $this->askmmuauqcuuqsea('Media'); } public function kogekgsaaqoeosuc(array $yemgmmgogcwccuky = []) : self { return $this->hsgemasguekogiui(['jpg', 'jpeg', 'webp'], 'image', $yemgmmgogcwccuky); } }
