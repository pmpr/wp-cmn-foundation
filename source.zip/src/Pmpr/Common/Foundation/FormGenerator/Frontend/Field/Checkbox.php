<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f15ee33c813             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Checkbox extends Field { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::semqugiuwygamias); $this->uekikuwmokqsqoga(Constants::semqugiuwygamias); $this->qigsyyqgewgskemg("\x63\165\x73\164\157\x6d\x2d\143\x6f\156\164\x72\157\x6c\55\151\x6e\x70\165\164")->askmmuauqcuuqsea("\103\150\145\143\153\142\x6f\x78"); } public function gayqqwwuycceosii(array $ywmkwiwkosakssii = []) : array { $ywmkwiwkosakssii = parent::gayqqwwuycceosii($ywmkwiwkosakssii); $ywmkwiwkosakssii["\x66\151\145\154\x64\137\x63\157\156\164\x61\151\x6e\145\x72\x5f\143\x6c\141\x73\x73"] = "\143\165\x73\x74\157\155\x2d\143\x6f\156\x74\162\x6f\x6c\40\143\165\x73\x74\157\x6d\55\143\x68\145\x63\x6b\142\x6f\170"; return $ywmkwiwkosakssii; } }
