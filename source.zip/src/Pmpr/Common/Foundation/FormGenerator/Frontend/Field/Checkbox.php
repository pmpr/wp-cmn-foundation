<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f6c19d6f1c9             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Checkbox extends Field { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::semqugiuwygamias); $this->uekikuwmokqsqoga(Constants::semqugiuwygamias); $this->qigsyyqgewgskemg("\x63\165\x73\164\157\x6d\55\143\x6f\x6e\164\162\x6f\154\x2d\151\156\x70\x75\164")->askmmuauqcuuqsea("\103\150\145\x63\x6b\142\x6f\170"); } public function gayqqwwuycceosii(array $ywmkwiwkosakssii = []) : array { $ywmkwiwkosakssii = parent::gayqqwwuycceosii($ywmkwiwkosakssii); $ywmkwiwkosakssii["\x66\x69\145\154\x64\x5f\x63\157\156\164\x61\151\x6e\145\x72\137\143\x6c\x61\163\x73"] = "\x63\165\x73\164\x6f\x6d\x2d\143\157\156\x74\162\x6f\x6c\40\143\x75\163\x74\157\155\55\143\x68\145\x63\153\142\x6f\170"; return $ywmkwiwkosakssii; } }
