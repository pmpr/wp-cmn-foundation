<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ebe0a571651             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Checkbox extends Field { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::semqugiuwygamias); $this->uekikuwmokqsqoga(Constants::semqugiuwygamias); $this->qigsyyqgewgskemg("\143\x75\x73\x74\157\155\x2d\x63\157\x6e\164\162\157\x6c\55\x69\x6e\160\x75\x74")->askmmuauqcuuqsea("\x43\150\x65\143\153\142\157\170"); } public function gayqqwwuycceosii(array $ywmkwiwkosakssii = []) : array { $ywmkwiwkosakssii = parent::gayqqwwuycceosii($ywmkwiwkosakssii); $ywmkwiwkosakssii["\x66\151\x65\154\x64\x5f\x63\x6f\156\164\x61\151\x6e\145\x72\137\143\x6c\x61\163\x73"] = "\143\x75\x73\x74\x6f\155\55\x63\157\x6e\x74\x72\157\154\40\143\165\x73\x74\x6f\155\x2d\x63\x68\x65\143\153\x62\157\x78"; return $ywmkwiwkosakssii; } }
