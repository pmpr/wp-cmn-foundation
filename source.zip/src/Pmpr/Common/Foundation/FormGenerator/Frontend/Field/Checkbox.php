<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670e55c403173             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Checkbox extends Field { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::semqugiuwygamias); $this->uekikuwmokqsqoga(Constants::semqugiuwygamias); $this->qigsyyqgewgskemg("\x63\x75\163\x74\157\155\55\x63\157\x6e\x74\x72\157\x6c\x2d\x69\156\x70\x75\x74")->askmmuauqcuuqsea("\103\150\x65\x63\153\142\157\170"); } public function gayqqwwuycceosii(array $ywmkwiwkosakssii = []) : array { $ywmkwiwkosakssii = parent::gayqqwwuycceosii($ywmkwiwkosakssii); $ywmkwiwkosakssii["\x66\x69\x65\154\144\x5f\143\x6f\x6e\164\x61\x69\156\x65\x72\137\x63\154\141\163\163"] = "\x63\165\163\164\x6f\x6d\55\143\157\x6e\164\x72\x6f\154\40\x63\165\x73\164\157\x6d\x2d\x63\x68\x65\x63\153\x62\157\170"; return $ywmkwiwkosakssii; } }
