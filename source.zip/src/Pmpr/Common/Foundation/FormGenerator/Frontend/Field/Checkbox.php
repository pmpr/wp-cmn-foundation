<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce373d0ef0a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Checkbox extends Field { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::semqugiuwygamias); $this->uekikuwmokqsqoga(Constants::semqugiuwygamias); $this->qigsyyqgewgskemg("\143\x75\x73\x74\x6f\x6d\55\143\157\x6e\x74\162\x6f\154\x2d\x69\x6e\160\x75\164")->askmmuauqcuuqsea("\103\150\145\x63\x6b\x62\x6f\170"); } public function gayqqwwuycceosii(array $ywmkwiwkosakssii = []) : array { $ywmkwiwkosakssii = parent::gayqqwwuycceosii($ywmkwiwkosakssii); $ywmkwiwkosakssii["\x66\x69\x65\x6c\x64\137\143\x6f\x6e\164\141\x69\x6e\x65\x72\x5f\x63\x6c\141\x73\163"] = "\143\x75\x73\x74\x6f\x6d\x2d\143\157\156\x74\x72\157\x6c\x20\x63\x75\x73\164\157\155\55\x63\150\145\143\x6b\142\157\170"; return $ywmkwiwkosakssii; } }
