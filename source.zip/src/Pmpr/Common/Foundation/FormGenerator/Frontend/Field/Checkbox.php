<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67abd9c8f1e03             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Checkbox extends Field { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::semqugiuwygamias); $this->uekikuwmokqsqoga(Constants::semqugiuwygamias); $this->qigsyyqgewgskemg("\143\165\163\164\157\x6d\55\x63\x6f\156\x74\x72\157\x6c\55\151\156\160\165\164")->askmmuauqcuuqsea("\x43\x68\x65\x63\x6b\x62\x6f\170"); } public function gayqqwwuycceosii(array $ywmkwiwkosakssii = []) : array { $ywmkwiwkosakssii = parent::gayqqwwuycceosii($ywmkwiwkosakssii); $ywmkwiwkosakssii["\146\151\x65\154\144\137\143\157\x6e\x74\x61\x69\x6e\145\162\x5f\143\x6c\141\x73\163"] = "\x63\x75\x73\164\157\x6d\x2d\143\157\156\x74\x72\157\154\40\143\165\163\164\157\155\x2d\143\x68\x65\143\x6b\x62\x6f\170"; return $ywmkwiwkosakssii; } }
