<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce3480d954f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Checkbox extends Field { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::semqugiuwygamias); $this->uekikuwmokqsqoga(Constants::semqugiuwygamias); $this->qigsyyqgewgskemg("\143\165\x73\x74\157\155\55\x63\x6f\156\x74\162\157\x6c\x2d\151\x6e\160\165\164")->askmmuauqcuuqsea("\x43\150\x65\143\153\142\157\170"); } public function gayqqwwuycceosii(array $ywmkwiwkosakssii = []) : array { $ywmkwiwkosakssii = parent::gayqqwwuycceosii($ywmkwiwkosakssii); $ywmkwiwkosakssii["\x66\x69\x65\154\144\137\x63\x6f\x6e\164\x61\x69\x6e\x65\162\x5f\143\154\141\x73\x73"] = "\143\x75\163\164\157\155\x2d\143\157\156\164\x72\157\154\x20\143\165\x73\164\157\x6d\55\x63\150\x65\143\x6b\142\x6f\x78"; return $ywmkwiwkosakssii; } }
