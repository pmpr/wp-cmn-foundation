<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675819f57c47e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Checkbox extends Field { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::semqugiuwygamias); $this->uekikuwmokqsqoga(Constants::semqugiuwygamias); $this->qigsyyqgewgskemg("\143\x75\163\164\157\155\x2d\143\x6f\156\164\162\157\154\x2d\151\x6e\x70\x75\164")->askmmuauqcuuqsea("\103\150\145\143\153\x62\157\170"); } public function gayqqwwuycceosii(array $ywmkwiwkosakssii = []) : array { $ywmkwiwkosakssii = parent::gayqqwwuycceosii($ywmkwiwkosakssii); $ywmkwiwkosakssii["\146\151\x65\x6c\144\x5f\x63\157\x6e\164\141\151\156\x65\162\137\143\x6c\141\163\x73"] = "\143\x75\x73\x74\x6f\155\55\143\157\x6e\x74\x72\x6f\x6c\40\x63\x75\x73\164\x6f\155\x2d\x63\150\145\143\x6b\142\157\170"; return $ywmkwiwkosakssii; } }
