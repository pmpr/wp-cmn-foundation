<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67522ae918e5f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Checkbox extends Field { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::semqugiuwygamias); $this->uekikuwmokqsqoga(Constants::semqugiuwygamias); $this->qigsyyqgewgskemg("\x63\x75\163\164\x6f\155\x2d\x63\x6f\156\164\x72\x6f\154\55\151\x6e\x70\165\x74")->askmmuauqcuuqsea("\103\x68\x65\143\153\x62\x6f\x78"); } public function gayqqwwuycceosii(array $ywmkwiwkosakssii = []) : array { $ywmkwiwkosakssii = parent::gayqqwwuycceosii($ywmkwiwkosakssii); $ywmkwiwkosakssii["\146\x69\x65\154\144\137\x63\x6f\156\164\141\151\x6e\x65\x72\137\x63\x6c\x61\163\x73"] = "\x63\x75\x73\x74\x6f\x6d\55\143\x6f\x6e\x74\x72\x6f\x6c\x20\x63\165\x73\164\157\155\55\x63\150\x65\x63\x6b\142\x6f\170"; return $ywmkwiwkosakssii; } }
