<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa77cb5a35c             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Checkbox extends Field { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::semqugiuwygamias); $this->uekikuwmokqsqoga(Constants::semqugiuwygamias); $this->qigsyyqgewgskemg("\x63\x75\163\x74\157\x6d\55\x63\x6f\x6e\164\162\x6f\154\x2d\151\x6e\160\x75\x74")->askmmuauqcuuqsea("\103\150\x65\143\x6b\x62\x6f\x78"); } public function gayqqwwuycceosii(array $ywmkwiwkosakssii = []) : array { $ywmkwiwkosakssii = parent::gayqqwwuycceosii($ywmkwiwkosakssii); $ywmkwiwkosakssii["\146\x69\145\x6c\144\x5f\x63\157\156\164\x61\151\156\x65\x72\137\x63\154\x61\163\x73"] = "\143\165\x73\x74\157\155\x2d\143\x6f\x6e\x74\162\x6f\154\40\x63\165\x73\164\157\x6d\x2d\x63\x68\x65\x63\x6b\142\157\x78"; return $ywmkwiwkosakssii; } }
