<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6791523fa4639             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Checkbox extends Field { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::semqugiuwygamias); $this->uekikuwmokqsqoga(Constants::semqugiuwygamias); $this->qigsyyqgewgskemg("\x63\165\x73\164\157\x6d\55\x63\157\x6e\x74\162\157\x6c\55\151\x6e\160\165\164")->askmmuauqcuuqsea("\x43\150\145\143\x6b\x62\157\170"); } public function gayqqwwuycceosii(array $ywmkwiwkosakssii = []) : array { $ywmkwiwkosakssii = parent::gayqqwwuycceosii($ywmkwiwkosakssii); $ywmkwiwkosakssii["\146\151\145\x6c\144\137\x63\x6f\156\x74\141\151\x6e\145\162\x5f\x63\x6c\141\163\163"] = "\143\x75\163\164\x6f\155\x2d\143\x6f\x6e\164\x72\x6f\154\40\143\x75\x73\164\x6f\155\x2d\x63\x68\x65\x63\x6b\x62\x6f\170"; return $ywmkwiwkosakssii; } }
