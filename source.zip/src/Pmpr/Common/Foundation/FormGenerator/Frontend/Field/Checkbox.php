<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6723ec7ab976d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Checkbox extends Field { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::semqugiuwygamias); $this->uekikuwmokqsqoga(Constants::semqugiuwygamias); $this->qigsyyqgewgskemg("\x63\165\x73\164\x6f\x6d\x2d\x63\x6f\156\164\x72\157\154\55\x69\156\160\165\x74")->askmmuauqcuuqsea("\103\150\145\x63\x6b\x62\157\x78"); } public function gayqqwwuycceosii(array $ywmkwiwkosakssii = []) : array { $ywmkwiwkosakssii = parent::gayqqwwuycceosii($ywmkwiwkosakssii); $ywmkwiwkosakssii["\x66\151\x65\154\x64\137\x63\157\x6e\164\141\x69\156\x65\x72\x5f\x63\x6c\141\x73\x73"] = "\143\165\x73\164\x6f\155\x2d\143\x6f\156\164\162\157\154\40\143\165\x73\164\x6f\x6d\55\143\150\x65\143\153\142\157\x78"; return $ywmkwiwkosakssii; } }
