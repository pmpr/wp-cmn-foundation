<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6751a9817f249             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\Interfaces\Constants; class Checkbox extends Field { public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::semqugiuwygamias); $this->uekikuwmokqsqoga(Constants::semqugiuwygamias); $this->qigsyyqgewgskemg("\x63\x75\x73\x74\157\x6d\x2d\x63\157\156\164\162\x6f\x6c\x2d\151\156\x70\x75\x74")->askmmuauqcuuqsea("\103\x68\x65\x63\153\142\x6f\x78"); } public function gayqqwwuycceosii(array $ywmkwiwkosakssii = []) : array { $ywmkwiwkosakssii = parent::gayqqwwuycceosii($ywmkwiwkosakssii); $ywmkwiwkosakssii["\146\x69\x65\154\x64\137\x63\157\x6e\164\x61\x69\x6e\x65\162\137\143\x6c\141\163\x73"] = "\143\165\163\x74\157\x6d\55\143\x6f\156\164\162\x6f\x6c\x20\x63\165\x73\164\157\155\55\143\x68\x65\x63\153\x62\157\x78"; return $ywmkwiwkosakssii; } }
