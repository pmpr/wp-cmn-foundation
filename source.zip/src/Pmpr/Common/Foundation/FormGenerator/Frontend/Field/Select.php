<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68aed6301bda9             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\FormGenerator\Field; use Pmpr\Common\Foundation\FormGenerator\Traits\SelectTrait; use Pmpr\Common\Foundation\Interfaces\Constants; class Select extends OptionAware { use SelectTrait; public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::SELECT); $this->qigsyyqgewgskemg('form-control')->askmmuauqcuuqsea('TreeSelect')->kakecegieeqyyayu()->qigsyyqgewgskemg('form-group'); } public function iageaauqggcakaqs() : self { return $this->askmmuauqcuuqsea('Select'); } public function oikgogcweiiaocka() : self { $this->qcgocuceocquqcuw('multiple', 'multiple'); return $this->igiywquyccyiaucw('multiple', true); } public function qgsieamsswkgysow(array $ywmkwiwkosakssii = []) : void { $this->kyiucygqsgequoys(''); } }
