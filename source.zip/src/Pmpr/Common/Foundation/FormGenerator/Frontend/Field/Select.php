<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67abdb6f91c28             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\FormGenerator\Frontend\Field; use Pmpr\Common\Foundation\FormGenerator\Traits\SelectTrait; use Pmpr\Common\Foundation\Interfaces\Constants; class Select extends OptionAware { use SelectTrait; public function __construct(string $aokagokqyuysuksm = '') { parent::__construct($aokagokqyuysuksm, Constants::SELECT); $this->qigsyyqgewgskemg("\x66\x6f\x72\155\55\x63\x6f\x6e\x74\162\157\x6c")->askmmuauqcuuqsea("\124\162\x65\145\x53\145\154\145\143\x74")->kakecegieeqyyayu()->qigsyyqgewgskemg("\146\x6f\x72\155\55\x67\162\x6f\165\x70"); } public function oikgogcweiiaocka() : self { $this->qcgocuceocquqcuw("\155\165\154\164\151\160\154\x65", "\155\x75\154\164\x69\160\154\145"); return $this->igiywquyccyiaucw("\x6d\x75\154\164\x69\x70\x6c\x65", true); } }
