<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68e598dc2fa2d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Mediator; use Pmpr\Common\Foundation\Container\Container; use Pmpr\Common\Foundation\Mediator\REST\REST; class Mediator extends Container { public function mameiwsayuyquoeq() { REST::symcgieuakksimmu(); } }
