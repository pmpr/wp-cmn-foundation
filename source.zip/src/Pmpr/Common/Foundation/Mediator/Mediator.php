<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f0d2c87384d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Mediator; use Pmpr\Common\Foundation\Mediator\REST\REST; class Mediator extends Common { public function mameiwsayuyquoeq() { REST::symcgieuakksimmu(); } }
