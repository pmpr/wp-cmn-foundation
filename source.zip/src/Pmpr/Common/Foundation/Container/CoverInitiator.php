<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6843ea91d9067             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Container; abstract class CoverInitiator extends ComponentInitiator { public function ikcgmcycisiccyuc() { $this->canRunSetup = true; } }
