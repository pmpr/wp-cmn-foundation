<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67580c605cb9d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Container\Traits; use Pmpr\Common\Foundation\Asset\Manager; trait CommonTrait { protected bool $canRunSetup = true; public function __construct() { $this->ikcgmcycisiccyuc(); if ($this->kwyscakayqgsqosc()) { $this->gyqeoeemeemicgqi(); } } public function kwyscakayqgsqosc() : bool { return $this->canRunSetup; } public function ikcgmcycisiccyuc() { } public function gyqeoeemeemicgqi() { $this->mameiwsayuyquoeq(); $this->eogyyugasomygcma(); $this->kgewmaycsoykyaso(); $this->wigskegsqequoeks(); $this->kgquecmsgcouyaya(); if ($qgciuiagkkguykgs = $this->caokeucsksukesyo()->ekkwaykokcgqkmoi()->myagqecycsaiyqsk($this, "\x63\x6f\x6d\160\x6f\x6e\145\156\164\163\114\x6f\x61\144\145\144")) { $this->qcsmikeggeemccuu("\143\x6f\x6d\x70\x6f\156\145\x6e\x74\163\x5f\154\157\141\144\145\144", [$this, $qgciuiagkkguykgs])->qcsmikeggeemccuu("\155\157\x64\x75\154\145\163\x5f\154\157\141\x64\145\144", [$this, $qgciuiagkkguykgs]); } } public function mameiwsayuyquoeq() { } public function wigskegsqequoeks() { } public function kgquecmsgcouyaya() { } public function kgewmaycsoykyaso() { } public function eogyyugasomygcma() { } }
