<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68e580c75799f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Container; abstract class ModuleInitiator extends ComponentInitiator { }
