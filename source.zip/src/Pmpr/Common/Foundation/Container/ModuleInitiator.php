<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             694c4d3f4e85c             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Container; abstract class ModuleInitiator extends ComponentInitiator { }
