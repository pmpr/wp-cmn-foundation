<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68874836a5b5c             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Container; abstract class ModuleInitiator extends ComponentInitiator { }
