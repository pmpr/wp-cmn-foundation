<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68df9badab9a0             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Container; abstract class ModuleInitiator extends ComponentInitiator { }
