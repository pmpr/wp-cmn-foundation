<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67d02dbf4efea             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Container; abstract class UtilityInitiator extends ComponentInitiator { public function ikcgmcycisiccyuc() { $this->canRunSetup = true; } }
