<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d1dbc474879             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Container; abstract class UtilityInitiator extends ComponentInitiator { public function ikcgmcycisiccyuc() { $this->canRunSetup = true; } }
