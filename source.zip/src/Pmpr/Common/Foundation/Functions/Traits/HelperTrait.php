<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d303622917b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Traits; use Pmpr\Common\Foundation\Functions\Helper\Helper; trait HelperTrait { public function caokeucsksukesyo() : Helper { return Helper::symcgieuakksimmu(); } public static function iwgqamekocwaigci() : Helper { return Helper::symcgieuakksimmu(); } }
