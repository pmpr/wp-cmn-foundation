<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67143a3375b94             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Wrapper\Plugin; use WP_Error; class Plugin extends Common { public function ciugwooasaqcywas(array $ywmkwiwkosakssii = [], string $aiamqeawckcsuaou = "\x71\x75\145\x72\x79\137\x70\x6c\165\147\151\x6e\x73") { if (!function_exists("\x70\x6c\165\147\x69\x6e\163\137\x61\160\x69")) { include_once ABSPATH . "\x77\160\x2d\141\x64\x6d\151\x6e\x2f\x69\156\143\154\165\x64\145\163\57\160\x6c\x75\147\151\x6e\55\x69\x6e\x73\x74\x61\154\x6c\x2e\x70\150\160"; } return plugins_api($aiamqeawckcsuaou, $ywmkwiwkosakssii); } public function ggocakcisguuokai($mkysicwccoeicumg) : bool { if (!function_exists("\x69\163\x5f\160\154\165\x67\x69\x6e\137\141\x63\x74\151\166\145")) { include_once ABSPATH . "\167\160\55\141\144\x6d\151\156\57\151\156\x63\x6c\165\x64\x65\163\57\x70\154\165\x67\x69\x6e\x2e\160\150\x70"; } return $this->call("\x69\163\x5f\160\154\165\147\x69\x6e\137\141\x63\x74\x69\166\x65", false, $mkysicwccoeicumg); } public function sioyqaykmwwugmgi(string $mkysicwccoeicumg) : bool { return $this->call("\x69\x73\x5f\160\154\165\147\151\156\x5f\x61\x63\x74\x69\x76\145\137\146\157\x72\137\156\x65\164\167\157\x72\153", false, $mkysicwccoeicumg); } }
