<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d2f79b4e2f3             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Wrapper\Plugin; use WP_Error; class Plugin extends Common { public function ciugwooasaqcywas(array $ywmkwiwkosakssii = [], string $aiamqeawckcsuaou = "\x71\165\x65\162\x79\137\160\154\x75\x67\x69\156\163") { if (!function_exists("\160\154\165\x67\x69\x6e\163\x5f\x61\x70\151")) { include_once ABSPATH . "\167\x70\55\141\x64\x6d\x69\156\57\x69\156\x63\154\165\x64\145\163\x2f\160\154\x75\x67\151\156\x2d\151\x6e\163\x74\141\x6c\154\56\160\x68\x70"; } return plugins_api($aiamqeawckcsuaou, $ywmkwiwkosakssii); } public function ggocakcisguuokai($mkysicwccoeicumg) : bool { if (!function_exists("\x69\x73\137\x70\154\x75\x67\x69\x6e\137\141\143\x74\151\166\x65")) { include_once ABSPATH . "\x77\160\x2d\141\144\x6d\151\156\57\151\x6e\143\x6c\x75\144\145\163\x2f\x70\x6c\165\147\x69\x6e\x2e\x70\x68\160"; } return $this->call("\151\x73\x5f\160\x6c\x75\147\151\x6e\x5f\x61\143\164\x69\166\x65", false, $mkysicwccoeicumg); } public function sioyqaykmwwugmgi(string $mkysicwccoeicumg) : bool { return $this->call("\x69\163\137\160\154\x75\x67\x69\156\x5f\x61\143\x74\151\x76\145\x5f\146\157\162\137\156\x65\164\167\x6f\162\153", false, $mkysicwccoeicumg); } }
