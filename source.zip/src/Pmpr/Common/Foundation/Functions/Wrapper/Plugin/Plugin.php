<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6797767677d97             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Wrapper\Plugin; use WP_Error; class Plugin extends Common { public function ciugwooasaqcywas(array $ywmkwiwkosakssii = [], string $aiamqeawckcsuaou = "\161\165\x65\162\171\x5f\160\x6c\x75\147\151\156\163") { if (!function_exists("\x70\154\x75\147\151\x6e\x73\137\141\160\x69")) { include_once ABSPATH . "\167\x70\x2d\141\x64\x6d\x69\x6e\57\x69\x6e\x63\x6c\165\x64\145\163\x2f\160\x6c\165\147\151\156\x2d\151\156\163\164\x61\154\154\56\160\150\160"; } return plugins_api($aiamqeawckcsuaou, $ywmkwiwkosakssii); } public function ggocakcisguuokai($mkysicwccoeicumg) : bool { if (!function_exists("\151\x73\x5f\160\154\x75\x67\x69\156\x5f\x61\143\x74\x69\x76\145")) { include_once ABSPATH . "\x77\160\x2d\141\144\x6d\x69\x6e\x2f\x69\x6e\x63\154\165\x64\145\x73\57\160\x6c\x75\147\151\x6e\x2e\160\x68\x70"; } return $this->call("\x69\x73\x5f\x70\154\165\x67\151\x6e\x5f\x61\x63\164\151\166\145", false, $mkysicwccoeicumg); } public function sioyqaykmwwugmgi(string $mkysicwccoeicumg) : bool { return $this->call("\151\x73\137\160\154\165\x67\x69\156\137\x61\x63\164\151\166\145\137\146\x6f\x72\x5f\156\x65\164\x77\x6f\162\x6b", false, $mkysicwccoeicumg); } }
