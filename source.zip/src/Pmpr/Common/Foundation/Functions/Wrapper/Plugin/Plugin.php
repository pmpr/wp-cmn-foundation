<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ebf63ece5a6             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Wrapper\Plugin; use WP_Error; class Plugin extends Common { public function ciugwooasaqcywas(array $ywmkwiwkosakssii = [], string $aiamqeawckcsuaou = "\x71\x75\x65\162\171\x5f\x70\154\165\x67\151\156\x73") { if (!function_exists("\x70\x6c\x75\147\x69\x6e\163\x5f\x61\x70\x69")) { include_once ABSPATH . "\167\x70\55\x61\x64\x6d\x69\156\57\x69\156\143\154\165\x64\x65\x73\57\160\x6c\x75\x67\x69\156\55\x69\x6e\163\164\x61\154\x6c\56\160\150\160"; } return plugins_api($aiamqeawckcsuaou, $ywmkwiwkosakssii); } public function ggocakcisguuokai($mkysicwccoeicumg) : bool { if (!function_exists("\151\163\137\160\x6c\x75\x67\151\156\x5f\141\x63\x74\x69\x76\145")) { include_once ABSPATH . "\167\x70\55\141\144\155\x69\156\57\x69\x6e\x63\x6c\x75\x64\145\163\x2f\160\154\165\x67\x69\156\x2e\160\150\x70"; } return $this->call("\151\x73\137\160\x6c\x75\147\151\x6e\x5f\141\143\x74\x69\x76\145", false, $mkysicwccoeicumg); } public function sioyqaykmwwugmgi(string $mkysicwccoeicumg) : bool { return $this->call("\x69\x73\137\160\x6c\x75\x67\x69\x6e\137\x61\x63\164\151\166\145\137\146\157\162\x5f\156\x65\164\167\x6f\162\153", false, $mkysicwccoeicumg); } }
