<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67abd9c8f1e03             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Wrapper\Plugin; use WP_Error; class Plugin extends Common { public function ciugwooasaqcywas(array $ywmkwiwkosakssii = [], string $aiamqeawckcsuaou = "\x71\x75\145\162\171\x5f\x70\x6c\x75\x67\x69\x6e\163") { if (!function_exists("\x70\154\x75\147\x69\156\163\x5f\141\x70\x69")) { include_once ABSPATH . "\x77\160\55\141\144\x6d\151\156\x2f\151\156\x63\154\165\144\x65\163\x2f\160\x6c\x75\x67\x69\x6e\55\x69\156\163\164\x61\x6c\x6c\x2e\x70\x68\x70"; } return plugins_api($aiamqeawckcsuaou, $ywmkwiwkosakssii); } public function ggocakcisguuokai($mkysicwccoeicumg) : bool { if (!function_exists("\151\x73\x5f\x70\x6c\x75\147\151\x6e\137\141\143\164\x69\x76\x65")) { include_once ABSPATH . "\x77\160\x2d\x61\x64\x6d\x69\156\x2f\x69\x6e\143\154\165\144\x65\x73\x2f\x70\x6c\165\147\x69\156\56\160\x68\160"; } return $this->call("\x69\x73\x5f\160\x6c\x75\147\151\x6e\x5f\x61\143\164\151\166\x65", false, $mkysicwccoeicumg); } public function sioyqaykmwwugmgi(string $mkysicwccoeicumg) : bool { return $this->call("\x69\163\137\160\154\165\147\x69\156\x5f\x61\143\x74\x69\166\145\137\x66\x6f\x72\137\x6e\145\x74\x77\x6f\x72\x6b", false, $mkysicwccoeicumg); } }
