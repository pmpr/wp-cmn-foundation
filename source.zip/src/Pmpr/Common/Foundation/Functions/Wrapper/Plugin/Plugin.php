<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce3480d954f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Wrapper\Plugin; use WP_Error; class Plugin extends Common { public function ciugwooasaqcywas(array $ywmkwiwkosakssii = [], string $aiamqeawckcsuaou = "\161\x75\145\162\171\137\160\x6c\x75\x67\151\x6e\x73") { if (!function_exists("\160\154\x75\x67\151\x6e\163\137\141\160\151")) { include_once ABSPATH . "\x77\x70\x2d\x61\x64\x6d\151\156\57\x69\x6e\143\154\165\144\145\163\57\x70\x6c\x75\147\151\x6e\55\x69\x6e\x73\x74\141\x6c\154\x2e\x70\150\x70"; } return plugins_api($aiamqeawckcsuaou, $ywmkwiwkosakssii); } public function ggocakcisguuokai($mkysicwccoeicumg) : bool { if (!function_exists("\x69\x73\137\x70\x6c\x75\147\x69\x6e\x5f\141\143\x74\151\x76\x65")) { include_once ABSPATH . "\x77\x70\55\141\144\x6d\x69\x6e\57\151\x6e\143\154\165\x64\145\163\57\160\154\165\x67\x69\x6e\56\x70\150\x70"; } return $this->call("\151\163\137\x70\x6c\x75\x67\151\156\x5f\x61\143\x74\151\x76\x65", false, $mkysicwccoeicumg); } public function sioyqaykmwwugmgi(string $mkysicwccoeicumg) : bool { return $this->call("\151\163\x5f\160\x6c\x75\147\x69\x6e\137\x61\143\x74\x69\x76\x65\x5f\x66\x6f\162\x5f\156\x65\164\167\157\x72\153", false, $mkysicwccoeicumg); } }
