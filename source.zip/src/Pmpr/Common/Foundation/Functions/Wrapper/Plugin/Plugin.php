<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce6343424e0             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Wrapper\Plugin; use WP_Error; class Plugin extends Common { public function ciugwooasaqcywas(array $ywmkwiwkosakssii = [], string $aiamqeawckcsuaou = "\x71\165\145\162\171\137\160\154\x75\147\151\156\163") { if (!function_exists("\160\154\x75\x67\x69\156\163\x5f\x61\160\151")) { include_once ABSPATH . "\x77\160\55\141\144\155\151\156\x2f\151\x6e\143\x6c\x75\x64\x65\163\x2f\160\x6c\165\x67\x69\x6e\x2d\151\x6e\163\x74\x61\x6c\154\x2e\x70\150\x70"; } return plugins_api($aiamqeawckcsuaou, $ywmkwiwkosakssii); } public function ggocakcisguuokai($mkysicwccoeicumg) : bool { if (!function_exists("\x69\163\137\x70\154\x75\x67\x69\x6e\137\141\x63\x74\x69\166\x65")) { include_once ABSPATH . "\x77\x70\55\141\144\x6d\151\x6e\x2f\x69\x6e\143\x6c\x75\144\x65\163\57\x70\x6c\x75\147\151\156\56\160\x68\x70"; } return $this->call("\151\163\x5f\160\x6c\x75\x67\x69\x6e\137\x61\x63\164\x69\166\x65", false, $mkysicwccoeicumg); } public function sioyqaykmwwugmgi(string $mkysicwccoeicumg) : bool { return $this->call("\x69\x73\x5f\160\154\x75\x67\151\x6e\x5f\x61\143\164\x69\166\x65\137\146\x6f\162\x5f\156\x65\164\167\x6f\x72\x6b", false, $mkysicwccoeicumg); } }
