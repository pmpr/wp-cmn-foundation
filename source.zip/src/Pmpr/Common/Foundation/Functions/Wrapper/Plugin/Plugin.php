<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f132f156703             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Wrapper\Plugin; use WP_Error; class Plugin extends Common { public function ciugwooasaqcywas(array $ywmkwiwkosakssii = [], string $aiamqeawckcsuaou = "\161\165\145\x72\x79\137\x70\x6c\x75\x67\x69\x6e\x73") { if (!function_exists("\160\154\x75\147\x69\x6e\x73\137\x61\160\151")) { include_once ABSPATH . "\x77\x70\55\141\144\155\151\x6e\57\x69\x6e\x63\154\x75\144\145\163\x2f\x70\x6c\x75\x67\151\156\55\151\x6e\163\164\141\x6c\x6c\56\x70\150\x70"; } return plugins_api($aiamqeawckcsuaou, $ywmkwiwkosakssii); } public function ggocakcisguuokai($mkysicwccoeicumg) : bool { if (!function_exists("\x69\x73\137\160\154\x75\x67\151\156\137\x61\x63\164\x69\x76\145")) { include_once ABSPATH . "\x77\160\x2d\x61\144\155\151\x6e\57\151\x6e\x63\x6c\x75\x64\x65\163\57\x70\x6c\x75\147\x69\x6e\x2e\160\150\160"; } return $this->call("\x69\163\x5f\160\x6c\x75\147\x69\156\x5f\x61\x63\164\x69\x76\145", false, $mkysicwccoeicumg); } public function sioyqaykmwwugmgi(string $mkysicwccoeicumg) : bool { return $this->call("\x69\x73\137\160\154\165\147\151\x6e\137\x61\143\164\x69\x76\145\137\x66\157\x72\137\x6e\x65\164\167\x6f\162\153", false, $mkysicwccoeicumg); } }
