<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6705246332371             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Wrapper\Plugin; use WP_Error; class Plugin extends Common { public function ciugwooasaqcywas(array $ywmkwiwkosakssii = [], string $aiamqeawckcsuaou = "\161\x75\145\x72\x79\x5f\x70\154\x75\x67\151\156\163") { if (!function_exists("\x70\154\x75\147\x69\156\x73\x5f\x61\160\x69")) { include_once ABSPATH . "\x77\x70\x2d\x61\144\155\151\156\x2f\151\x6e\143\154\x75\x64\145\163\57\160\154\x75\147\x69\156\x2d\151\x6e\163\164\x61\154\154\x2e\x70\x68\x70"; } return plugins_api($aiamqeawckcsuaou, $ywmkwiwkosakssii); } public function ggocakcisguuokai($mkysicwccoeicumg) : bool { if (!function_exists("\x69\x73\137\x70\154\x75\147\151\156\137\141\x63\x74\151\166\145")) { include_once ABSPATH . "\167\x70\x2d\x61\x64\155\151\156\x2f\151\156\143\154\165\144\x65\x73\57\160\x6c\x75\147\151\156\56\160\150\160"; } return $this->call("\151\x73\137\x70\154\x75\147\x69\x6e\x5f\x61\143\164\151\166\145", false, $mkysicwccoeicumg); } public function sioyqaykmwwugmgi(string $mkysicwccoeicumg) : bool { return $this->call("\x69\163\137\x70\154\x75\147\x69\x6e\137\141\x63\164\x69\166\x65\137\146\157\x72\x5f\156\x65\164\x77\x6f\162\x6b", false, $mkysicwccoeicumg); } }
