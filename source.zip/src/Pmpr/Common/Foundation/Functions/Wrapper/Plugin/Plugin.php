<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1d819504ee             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Wrapper\Plugin; use WP_Error; class Plugin extends Common { public function ciugwooasaqcywas(array $ywmkwiwkosakssii = [], string $aiamqeawckcsuaou = "\x71\x75\x65\x72\171\137\x70\154\x75\x67\x69\156\163") { if (!function_exists("\160\154\x75\x67\151\156\x73\137\141\160\x69")) { include_once ABSPATH . "\167\x70\55\x61\144\155\x69\x6e\57\x69\x6e\143\154\x75\x64\145\x73\57\160\154\165\147\151\x6e\55\x69\156\x73\164\141\x6c\x6c\56\160\x68\160"; } return plugins_api($aiamqeawckcsuaou, $ywmkwiwkosakssii); } public function ggocakcisguuokai($mkysicwccoeicumg) : bool { if (!function_exists("\x69\x73\137\x70\154\x75\147\151\x6e\x5f\141\143\164\x69\x76\x65")) { include_once ABSPATH . "\x77\160\55\x61\144\155\151\x6e\57\151\x6e\x63\x6c\165\x64\x65\163\x2f\160\154\x75\147\151\x6e\56\160\x68\160"; } return $this->call("\151\163\137\160\x6c\x75\147\151\156\x5f\141\x63\164\151\166\145", false, $mkysicwccoeicumg); } public function sioyqaykmwwugmgi(string $mkysicwccoeicumg) : bool { return $this->call("\x69\163\137\x70\154\x75\147\151\x6e\137\141\x63\x74\x69\166\x65\x5f\x66\157\162\137\x6e\x65\x74\x77\x6f\162\x6b", false, $mkysicwccoeicumg); } }
