<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec0c5dc5dae             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Wrapper\Plugin; use WP_Error; class Plugin extends Common { public function ciugwooasaqcywas(array $ywmkwiwkosakssii = [], string $aiamqeawckcsuaou = "\161\165\145\x72\171\137\160\154\165\x67\151\x6e\163") { if (!function_exists("\x70\154\165\x67\x69\x6e\x73\137\141\x70\151")) { include_once ABSPATH . "\167\x70\55\141\144\155\x69\x6e\57\151\156\x63\154\x75\144\x65\163\x2f\160\154\x75\x67\x69\x6e\55\151\x6e\x73\164\x61\154\x6c\x2e\160\x68\160"; } return plugins_api($aiamqeawckcsuaou, $ywmkwiwkosakssii); } public function ggocakcisguuokai($mkysicwccoeicumg) : bool { if (!function_exists("\151\163\x5f\160\154\165\x67\151\x6e\x5f\141\x63\x74\x69\166\145")) { include_once ABSPATH . "\167\160\55\x61\x64\155\151\156\x2f\x69\156\x63\x6c\165\144\145\x73\x2f\x70\x6c\x75\147\x69\x6e\x2e\160\150\160"; } return $this->call("\x69\163\x5f\x70\x6c\165\x67\x69\x6e\x5f\141\x63\164\x69\x76\145", false, $mkysicwccoeicumg); } public function sioyqaykmwwugmgi(string $mkysicwccoeicumg) : bool { return $this->call("\151\163\x5f\160\154\165\x67\x69\x6e\137\x61\x63\164\x69\166\x65\x5f\x66\157\162\x5f\x6e\145\164\167\157\162\153", false, $mkysicwccoeicumg); } }
