<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d43c49e811             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Wrapper\Plugin; use WP_Error; class Plugin extends Common { public function ciugwooasaqcywas(array $ywmkwiwkosakssii = [], string $aiamqeawckcsuaou = "\x71\x75\145\162\x79\x5f\160\154\165\x67\151\x6e\163") { if (!function_exists("\160\x6c\x75\x67\151\156\x73\137\x61\x70\x69")) { include_once ABSPATH . "\x77\160\55\x61\x64\155\x69\x6e\57\x69\156\x63\x6c\x75\x64\145\163\57\160\x6c\x75\x67\x69\156\x2d\x69\x6e\x73\x74\x61\154\x6c\x2e\160\x68\x70"; } return plugins_api($aiamqeawckcsuaou, $ywmkwiwkosakssii); } public function ggocakcisguuokai($mkysicwccoeicumg) : bool { if (!function_exists("\x69\163\137\160\154\x75\x67\151\x6e\x5f\x61\143\164\151\166\145")) { include_once ABSPATH . "\167\x70\x2d\141\144\155\151\156\57\x69\156\143\154\165\144\145\163\57\160\154\165\147\151\156\x2e\160\x68\160"; } return $this->call("\151\163\137\x70\154\165\x67\151\x6e\137\x61\x63\x74\x69\x76\x65", false, $mkysicwccoeicumg); } public function sioyqaykmwwugmgi(string $mkysicwccoeicumg) : bool { return $this->call("\151\x73\137\x70\154\165\147\151\x6e\137\141\143\164\151\x76\145\x5f\x66\x6f\x72\137\156\x65\x74\x77\157\162\x6b", false, $mkysicwccoeicumg); } }
