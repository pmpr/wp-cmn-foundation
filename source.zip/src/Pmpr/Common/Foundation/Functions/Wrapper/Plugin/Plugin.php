<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebdb08957             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Wrapper\Plugin; use WP_Error; class Plugin extends Common { public function ciugwooasaqcywas(array $ywmkwiwkosakssii = [], string $aiamqeawckcsuaou = "\161\x75\145\x72\x79\137\160\154\165\x67\x69\156\163") { if (!function_exists("\160\154\165\147\151\156\163\137\x61\x70\x69")) { include_once ABSPATH . "\167\160\x2d\x61\x64\155\151\156\x2f\x69\156\x63\x6c\x75\144\145\163\57\x70\154\x75\147\151\x6e\x2d\x69\x6e\x73\164\141\x6c\x6c\56\x70\150\160"; } return plugins_api($aiamqeawckcsuaou, $ywmkwiwkosakssii); } public function ggocakcisguuokai($mkysicwccoeicumg) : bool { if (!function_exists("\x69\163\x5f\x70\154\165\147\151\x6e\x5f\x61\143\x74\x69\x76\x65")) { include_once ABSPATH . "\167\x70\x2d\x61\144\155\151\x6e\x2f\x69\156\143\154\165\144\x65\x73\x2f\160\x6c\165\x67\x69\156\56\x70\x68\x70"; } return $this->call("\151\163\137\x70\154\x75\147\151\x6e\x5f\141\x63\x74\151\x76\145", false, $mkysicwccoeicumg); } public function sioyqaykmwwugmgi(string $mkysicwccoeicumg) : bool { return $this->call("\151\x73\137\x70\154\165\x67\151\156\x5f\x61\143\x74\151\166\x65\137\146\157\162\137\x6e\x65\164\x77\x6f\x72\153", false, $mkysicwccoeicumg); } }
