<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b649567cd             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Wrapper\Plugin; use WP_Error; class Plugin extends Common { public function ciugwooasaqcywas(array $ywmkwiwkosakssii = [], string $aiamqeawckcsuaou = "\x71\165\x65\x72\171\137\x70\154\x75\147\x69\156\163") { if (!function_exists("\x70\154\x75\147\151\156\163\x5f\x61\x70\x69")) { include_once ABSPATH . "\x77\160\x2d\x61\144\155\x69\x6e\x2f\x69\x6e\x63\154\165\x64\x65\x73\x2f\160\x6c\x75\x67\151\x6e\55\x69\x6e\x73\164\141\154\154\x2e\160\150\x70"; } return plugins_api($aiamqeawckcsuaou, $ywmkwiwkosakssii); } public function ggocakcisguuokai($mkysicwccoeicumg) : bool { if (!function_exists("\x69\x73\x5f\x70\x6c\x75\x67\151\156\137\x61\143\164\151\166\145")) { include_once ABSPATH . "\167\x70\x2d\141\x64\x6d\151\x6e\57\x69\x6e\143\x6c\x75\x64\145\x73\57\160\x6c\165\147\151\156\56\160\x68\x70"; } return $this->call("\x69\163\x5f\160\x6c\x75\147\151\156\x5f\x61\143\164\x69\166\145", false, $mkysicwccoeicumg); } public function sioyqaykmwwugmgi(string $mkysicwccoeicumg) : bool { return $this->call("\151\163\x5f\x70\x6c\x75\x67\151\x6e\137\x61\143\x74\x69\x76\x65\x5f\146\157\162\x5f\x6e\145\x74\x77\157\x72\153", false, $mkysicwccoeicumg); } }
