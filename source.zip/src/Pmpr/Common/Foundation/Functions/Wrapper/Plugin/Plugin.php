<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d1dbc474879             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Wrapper\Plugin; use WP_Error; class Plugin extends Common { public function ciugwooasaqcywas(array $ywmkwiwkosakssii = [], string $aiamqeawckcsuaou = "\x71\x75\145\162\171\137\160\x6c\x75\147\x69\156\x73") { if (!function_exists("\x70\154\165\x67\151\x6e\163\x5f\x61\x70\151")) { include_once ABSPATH . "\x77\x70\55\x61\x64\x6d\151\x6e\57\x69\x6e\x63\x6c\165\x64\x65\x73\x2f\160\x6c\165\x67\x69\156\55\151\x6e\x73\x74\141\x6c\x6c\x2e\x70\150\x70"; } return plugins_api($aiamqeawckcsuaou, $ywmkwiwkosakssii); } public function ggocakcisguuokai($mkysicwccoeicumg) : bool { if (!function_exists("\x69\x73\137\x70\x6c\x75\x67\151\x6e\x5f\141\x63\164\x69\166\x65")) { include_once ABSPATH . "\167\x70\55\x61\x64\155\x69\156\57\x69\x6e\x63\154\x75\144\x65\x73\57\x70\x6c\x75\x67\x69\156\x2e\x70\x68\160"; } return $this->call("\151\163\137\x70\x6c\165\x67\151\156\x5f\x61\143\x74\151\166\145", false, $mkysicwccoeicumg); } public function sioyqaykmwwugmgi(string $mkysicwccoeicumg) : bool { return $this->call("\151\163\137\x70\154\x75\x67\151\x6e\137\141\x63\164\x69\166\145\137\x66\x6f\162\137\156\145\164\167\157\162\153", false, $mkysicwccoeicumg); } }
