<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d303622917b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Wrapper\Plugin; use WP_Error; class Plugin extends Common { public function ciugwooasaqcywas(array $ywmkwiwkosakssii = [], string $aiamqeawckcsuaou = "\161\165\x65\x72\171\137\160\154\x75\x67\151\156\163") { if (!function_exists("\x70\154\x75\147\x69\156\x73\137\x61\160\x69")) { include_once ABSPATH . "\167\160\55\x61\144\155\151\156\x2f\151\x6e\143\x6c\x75\x64\x65\163\x2f\160\x6c\x75\x67\x69\156\x2d\151\156\x73\x74\x61\x6c\154\x2e\x70\150\x70"; } return plugins_api($aiamqeawckcsuaou, $ywmkwiwkosakssii); } public function ggocakcisguuokai($mkysicwccoeicumg) : bool { if (!function_exists("\151\x73\x5f\x70\154\165\147\x69\156\x5f\141\x63\x74\151\x76\145")) { include_once ABSPATH . "\x77\160\55\x61\144\x6d\151\x6e\x2f\151\x6e\143\x6c\165\144\x65\x73\57\x70\x6c\x75\147\151\x6e\x2e\160\150\x70"; } return $this->call("\151\x73\137\x70\x6c\165\147\x69\156\x5f\x61\x63\x74\151\x76\145", false, $mkysicwccoeicumg); } public function sioyqaykmwwugmgi(string $mkysicwccoeicumg) : bool { return $this->call("\151\x73\137\x70\154\165\x67\151\156\x5f\141\x63\164\x69\x76\145\x5f\x66\x6f\162\137\156\145\164\167\157\x72\153", false, $mkysicwccoeicumg); } }
