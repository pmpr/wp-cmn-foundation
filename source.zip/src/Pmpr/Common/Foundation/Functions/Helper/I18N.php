<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebdb08957             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper; class I18N extends Common { public function eusockqasqqmoess($eusockqasqqmoess, $locale = null) { $kcqgsouywoiekwak = $this->caokeucsksukesyo()->mmsykuomogaqoaye()->ocksiywmkyaqseou("\164\x72\141\156\163\x5f\156\165\155\142\145\x72", $eusockqasqqmoess, $locale); if (!(is_numeric($eusockqasqqmoess) && (string) $kcqgsouywoiekwak === (string) $eusockqasqqmoess)) { goto guigkeossquogciu; } $kcqgsouywoiekwak = number_format_i18n((float) $eusockqasqqmoess); guigkeossquogciu: return $kcqgsouywoiekwak; } public function aoaesiikusqamcqc($cmwygeyygwqaemaq, $locale = null) { return $this->caokeucsksukesyo()->mmsykuomogaqoaye()->ocksiywmkyaqseou("\164\162\x61\156\x73\x5f\x77\x6f\x72\x64", $cmwygeyygwqaemaq, $locale); } public function ekasyoagocygouom($ocogsiouoiuuguym, $saqmwwmqiwmkiwaa = null, $locale = null) { return $this->caokeucsksukesyo()->mmsykuomogaqoaye()->ocksiywmkyaqseou("\164\162\x61\156\163\137\144\141\x74\145\x74\151\x6d\145", $ocogsiouoiuuguym, $saqmwwmqiwmkiwaa, $locale); } }
