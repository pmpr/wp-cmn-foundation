<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d303622917b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper; class I18N extends Common { public function eusockqasqqmoess($eusockqasqqmoess, $locale = null) { $kcqgsouywoiekwak = $this->caokeucsksukesyo()->mmsykuomogaqoaye()->ocksiywmkyaqseou("\164\162\141\156\163\137\x6e\x75\155\142\x65\x72", $eusockqasqqmoess, $locale); if (!(is_numeric($eusockqasqqmoess) && (string) $kcqgsouywoiekwak === (string) $eusockqasqqmoess)) { goto waqwicwqkgsgaosm; } $kcqgsouywoiekwak = number_format_i18n((float) $eusockqasqqmoess); waqwicwqkgsgaosm: return $kcqgsouywoiekwak; } public function aoaesiikusqamcqc($cmwygeyygwqaemaq, $locale = null) { return $this->caokeucsksukesyo()->mmsykuomogaqoaye()->ocksiywmkyaqseou("\164\x72\141\x6e\x73\x5f\x77\157\x72\144", $cmwygeyygwqaemaq, $locale); } public function ekasyoagocygouom($ocogsiouoiuuguym, $saqmwwmqiwmkiwaa = null, $locale = null) { return $this->caokeucsksukesyo()->mmsykuomogaqoaye()->ocksiywmkyaqseou("\164\x72\141\x6e\x73\x5f\x64\141\x74\x65\x74\151\x6d\145", $ocogsiouoiuuguym, $saqmwwmqiwmkiwaa, $locale); } }
