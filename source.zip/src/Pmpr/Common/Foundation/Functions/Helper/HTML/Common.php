<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f15ee33c813             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if (!($kuyqaamgacigwcwq = Template::symcgieuakksimmu())) { goto iceweuyyswquiiea; } $nsmgceoqaqogqmuw = $kuyqaamgacigwcwq->iuygowkemiiwqmiw("\100\160\162\x5f\137\143\155\156\137\137\x66\x6f\x75\156\x64\x61\164\x69\x6f\x6e\x2f{$qqscaoyqikuyeoaw}\56\x68\x74\x6d\154\x2e\x74\167\x69\147", $qookweymeqawmcwo); iceweuyyswquiiea: return $nsmgceoqaqogqmuw; } }
