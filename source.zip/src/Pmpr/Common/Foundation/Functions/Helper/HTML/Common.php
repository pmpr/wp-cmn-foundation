<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d8c7809438d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if (!($kuyqaamgacigwcwq = Template::symcgieuakksimmu())) { goto mcyamakgwewogwqi; } $nsmgceoqaqogqmuw = $kuyqaamgacigwcwq->iuygowkemiiwqmiw("\x40\x70\162\x5f\137\143\155\x6e\137\137\x66\157\165\x6e\144\x61\x74\151\157\156\x2f{$qqscaoyqikuyeoaw}\56\x68\x74\x6d\x6c\x2e\x74\x77\x69\147", $qookweymeqawmcwo); mcyamakgwewogwqi: return $nsmgceoqaqogqmuw; } }
