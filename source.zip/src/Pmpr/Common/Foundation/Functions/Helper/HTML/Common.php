<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d31c5675355             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if (!($kuyqaamgacigwcwq = Template::symcgieuakksimmu())) { goto semwcosqeukmgoey; } $nsmgceoqaqogqmuw = $kuyqaamgacigwcwq->iuygowkemiiwqmiw("\100\x70\x72\137\x5f\x63\x6d\x6e\x5f\x5f\x66\x6f\x75\156\x64\141\x74\151\x6f\x6e\57{$qqscaoyqikuyeoaw}\56\150\164\155\x6c\56\x74\x77\x69\147", $qookweymeqawmcwo); semwcosqeukmgoey: return $nsmgceoqaqogqmuw; } }
