<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f6c19d6f1c9             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if (!($kuyqaamgacigwcwq = Template::symcgieuakksimmu())) { goto mgkikasuaseesumm; } $nsmgceoqaqogqmuw = $kuyqaamgacigwcwq->iuygowkemiiwqmiw("\100\x70\x72\137\x5f\x63\x6d\x6e\137\137\x66\157\165\x6e\x64\x61\x74\x69\x6f\x6e\x2f{$qqscaoyqikuyeoaw}\x2e\x68\x74\x6d\154\56\164\167\151\x67", $qookweymeqawmcwo); mgkikasuaseesumm: return $nsmgceoqaqogqmuw; } }
