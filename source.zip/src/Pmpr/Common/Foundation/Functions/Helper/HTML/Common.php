<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67abdb6f91c28             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if ($yykoaiyakemcoqiu = pr_get_foundation()) { $nsmgceoqaqogqmuw = $yykoaiyakemcoqiu->iuygowkemiiwqmiw("\x40\x70\x72\137\x5f\143\x6d\x6e\137\x5f\146\157\165\156\144\141\x74\151\x6f\x6e\x2f{$qqscaoyqikuyeoaw}\x2e\x68\164\x6d\x6c\x2e\164\167\x69\147", $qookweymeqawmcwo); } return $nsmgceoqaqogqmuw; } }
