<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6705246332371             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if ($kuyqaamgacigwcwq = Template::symcgieuakksimmu()) { $nsmgceoqaqogqmuw = $kuyqaamgacigwcwq->iuygowkemiiwqmiw("\100\x70\162\137\x5f\143\155\156\x5f\137\x66\x6f\x75\x6e\144\141\x74\x69\x6f\x6e\x2f{$qqscaoyqikuyeoaw}\56\x68\164\155\154\56\164\167\151\x67", $qookweymeqawmcwo); } return $nsmgceoqaqogqmuw; } }
