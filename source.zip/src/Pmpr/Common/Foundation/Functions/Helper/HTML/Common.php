<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ebe0a571651             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if (!($kuyqaamgacigwcwq = Template::symcgieuakksimmu())) { goto cseucimaukwaskwk; } $nsmgceoqaqogqmuw = $kuyqaamgacigwcwq->iuygowkemiiwqmiw("\x40\160\x72\x5f\x5f\143\x6d\x6e\x5f\137\146\157\165\156\144\141\x74\x69\x6f\156\x2f{$qqscaoyqikuyeoaw}\x2e\x68\x74\155\x6c\56\164\167\x69\x67", $qookweymeqawmcwo); cseucimaukwaskwk: return $nsmgceoqaqogqmuw; } }
