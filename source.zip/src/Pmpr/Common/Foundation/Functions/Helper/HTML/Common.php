<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4df64db6b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if ($yykoaiyakemcoqiu = pr_get_foundation()) { $nsmgceoqaqogqmuw = $yykoaiyakemcoqiu->iuygowkemiiwqmiw("\100\160\x72\x5f\x5f\143\x6d\x6e\x5f\x5f\146\x6f\x75\x6e\x64\x61\164\x69\x6f\x6e\x2f{$qqscaoyqikuyeoaw}\x2e\x68\x74\x6d\x6c\x2e\164\167\x69\147", $qookweymeqawmcwo); } return $nsmgceoqaqogqmuw; } }
