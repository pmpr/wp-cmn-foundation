<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6751a903a9160             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if ($yykoaiyakemcoqiu = pr_get_foundation()) { $nsmgceoqaqogqmuw = $yykoaiyakemcoqiu->iuygowkemiiwqmiw("\100\x70\x72\137\x5f\x63\155\156\x5f\137\146\157\165\x6e\144\x61\164\151\x6f\x6e\57{$qqscaoyqikuyeoaw}\56\150\x74\x6d\154\x2e\164\x77\x69\147", $qookweymeqawmcwo); } return $nsmgceoqaqogqmuw; } }
