<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d303622917b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if (!($kuyqaamgacigwcwq = Template::symcgieuakksimmu())) { goto semwcosqeukmgoey; } $nsmgceoqaqogqmuw = $kuyqaamgacigwcwq->iuygowkemiiwqmiw("\100\x70\x72\x5f\x5f\x63\x6d\156\137\x5f\146\157\x75\156\x64\x61\164\x69\x6f\x6e\x2f{$qqscaoyqikuyeoaw}\x2e\x68\x74\x6d\x6c\56\x74\167\151\x67", $qookweymeqawmcwo); semwcosqeukmgoey: return $nsmgceoqaqogqmuw; } }
