<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce54af64690             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if (!($kuyqaamgacigwcwq = Template::symcgieuakksimmu())) { goto esewmcieucesaqcw; } $nsmgceoqaqogqmuw = $kuyqaamgacigwcwq->iuygowkemiiwqmiw("\100\x70\x72\137\137\143\155\156\137\137\x66\x6f\x75\x6e\x64\x61\x74\151\x6f\156\57{$qqscaoyqikuyeoaw}\56\x68\164\155\x6c\56\164\x77\151\x67", $qookweymeqawmcwo); esewmcieucesaqcw: return $nsmgceoqaqogqmuw; } }
