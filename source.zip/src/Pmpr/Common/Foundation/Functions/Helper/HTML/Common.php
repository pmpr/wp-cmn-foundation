<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f2a5b59cf46             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if (!($kuyqaamgacigwcwq = Template::symcgieuakksimmu())) { goto kimusawigieceeai; } $nsmgceoqaqogqmuw = $kuyqaamgacigwcwq->iuygowkemiiwqmiw("\100\160\162\137\137\x63\x6d\x6e\x5f\137\x66\x6f\165\x6e\144\141\164\x69\x6f\x6e\x2f{$qqscaoyqikuyeoaw}\x2e\x68\164\x6d\154\56\164\167\151\x67", $qookweymeqawmcwo); kimusawigieceeai: return $nsmgceoqaqogqmuw; } }
