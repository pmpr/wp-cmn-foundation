<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebdb08957             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if (!($kuyqaamgacigwcwq = Template::symcgieuakksimmu())) { goto gqqeucaekwcskwqm; } $nsmgceoqaqogqmuw = $kuyqaamgacigwcwq->iuygowkemiiwqmiw("\100\160\162\137\x5f\x63\x6d\x6e\x5f\x5f\146\157\165\156\144\x61\164\151\x6f\156\x2f{$qqscaoyqikuyeoaw}\x2e\x68\x74\155\x6c\56\x74\167\151\x67", $qookweymeqawmcwo); gqqeucaekwcskwqm: return $nsmgceoqaqogqmuw; } }
