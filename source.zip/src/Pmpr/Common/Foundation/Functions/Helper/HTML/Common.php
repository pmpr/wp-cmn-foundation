<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ebf559ba6b4             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if (!($kuyqaamgacigwcwq = Template::symcgieuakksimmu())) { goto cseucimaukwaskwk; } $nsmgceoqaqogqmuw = $kuyqaamgacigwcwq->iuygowkemiiwqmiw("\100\160\x72\137\137\x63\x6d\156\137\137\146\157\x75\156\x64\x61\x74\x69\x6f\156\x2f{$qqscaoyqikuyeoaw}\x2e\x68\x74\x6d\154\56\164\167\x69\147", $qookweymeqawmcwo); cseucimaukwaskwk: return $nsmgceoqaqogqmuw; } }
