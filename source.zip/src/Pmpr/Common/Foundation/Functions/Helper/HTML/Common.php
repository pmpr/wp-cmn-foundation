<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d1dbc474879             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if (!($kuyqaamgacigwcwq = Template::symcgieuakksimmu())) { goto imcseqowgomyokwi; } $nsmgceoqaqogqmuw = $kuyqaamgacigwcwq->iuygowkemiiwqmiw("\x40\x70\x72\137\x5f\143\x6d\x6e\x5f\137\146\x6f\x75\156\x64\x61\x74\x69\x6f\x6e\x2f{$qqscaoyqikuyeoaw}\56\x68\x74\155\x6c\56\x74\167\151\x67", $qookweymeqawmcwo); imcseqowgomyokwi: return $nsmgceoqaqogqmuw; } }
