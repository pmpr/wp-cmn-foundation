<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f7da660aa36             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if (!($kuyqaamgacigwcwq = Template::symcgieuakksimmu())) { goto uossiqykiaouimca; } $nsmgceoqaqogqmuw = $kuyqaamgacigwcwq->iuygowkemiiwqmiw("\x40\x70\162\137\137\x63\x6d\x6e\137\x5f\146\157\165\156\x64\141\x74\x69\157\x6e\57{$qqscaoyqikuyeoaw}\x2e\x68\164\155\x6c\56\164\x77\151\147", $qookweymeqawmcwo); uossiqykiaouimca: return $nsmgceoqaqogqmuw; } }
