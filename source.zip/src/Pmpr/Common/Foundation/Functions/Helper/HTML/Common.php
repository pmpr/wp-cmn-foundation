<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1d819504ee             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if (!($kuyqaamgacigwcwq = Template::symcgieuakksimmu())) { goto eaeokigkusweawki; } $nsmgceoqaqogqmuw = $kuyqaamgacigwcwq->iuygowkemiiwqmiw("\x40\x70\162\137\x5f\143\155\156\x5f\x5f\x66\157\x75\156\x64\x61\x74\151\157\x6e\x2f{$qqscaoyqikuyeoaw}\x2e\x68\x74\155\154\x2e\x74\x77\x69\x67", $qookweymeqawmcwo); eaeokigkusweawki: return $nsmgceoqaqogqmuw; } }
