<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67580c605cb9d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if ($yykoaiyakemcoqiu = pr_get_foundation()) { $nsmgceoqaqogqmuw = $yykoaiyakemcoqiu->iuygowkemiiwqmiw("\x40\160\x72\x5f\x5f\143\155\x6e\x5f\x5f\146\x6f\x75\x6e\144\141\164\151\x6f\156\57{$qqscaoyqikuyeoaw}\56\150\x74\155\x6c\56\164\x77\x69\147", $qookweymeqawmcwo); } return $nsmgceoqaqogqmuw; } }
