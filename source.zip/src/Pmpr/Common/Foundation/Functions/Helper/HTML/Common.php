<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d43c49e811             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if ($yykoaiyakemcoqiu = pr_get_foundation()) { $nsmgceoqaqogqmuw = $yykoaiyakemcoqiu->iuygowkemiiwqmiw("\100\x70\x72\137\x5f\x63\155\x6e\137\137\146\157\x75\156\x64\x61\164\151\157\x6e\57{$qqscaoyqikuyeoaw}\56\150\x74\x6d\154\x2e\164\x77\151\147", $qookweymeqawmcwo); } return $nsmgceoqaqogqmuw; } }
