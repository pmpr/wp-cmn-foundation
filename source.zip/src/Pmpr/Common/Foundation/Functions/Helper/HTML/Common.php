<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d3160ad4f5b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if (!($kuyqaamgacigwcwq = Template::symcgieuakksimmu())) { goto semwcosqeukmgoey; } $nsmgceoqaqogqmuw = $kuyqaamgacigwcwq->iuygowkemiiwqmiw("\x40\160\162\137\x5f\x63\x6d\x6e\x5f\x5f\146\157\165\x6e\144\x61\164\151\x6f\156\x2f{$qqscaoyqikuyeoaw}\56\x68\164\x6d\154\x2e\164\x77\151\x67", $qookweymeqawmcwo); semwcosqeukmgoey: return $nsmgceoqaqogqmuw; } }
