<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce6343424e0             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if (!($kuyqaamgacigwcwq = Template::symcgieuakksimmu())) { goto aimwoikqsqkyicsu; } $nsmgceoqaqogqmuw = $kuyqaamgacigwcwq->iuygowkemiiwqmiw("\x40\160\x72\137\x5f\x63\155\x6e\x5f\x5f\x66\x6f\x75\156\144\141\164\151\x6f\x6e\57{$qqscaoyqikuyeoaw}\56\x68\164\x6d\154\56\164\167\151\147", $qookweymeqawmcwo); aimwoikqsqkyicsu: return $nsmgceoqaqogqmuw; } }
