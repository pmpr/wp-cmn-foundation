<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce373d0ef0a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if (!($kuyqaamgacigwcwq = Template::symcgieuakksimmu())) { goto saoickmcegceesyw; } $nsmgceoqaqogqmuw = $kuyqaamgacigwcwq->iuygowkemiiwqmiw("\100\x70\162\137\x5f\143\x6d\x6e\x5f\x5f\x66\x6f\x75\156\x64\141\x74\151\157\x6e\57{$qqscaoyqikuyeoaw}\x2e\x68\164\x6d\x6c\56\x74\167\151\147", $qookweymeqawmcwo); saoickmcegceesyw: return $nsmgceoqaqogqmuw; } }
