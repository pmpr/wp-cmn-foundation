<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1e2ec7c9c7             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if (!($kuyqaamgacigwcwq = Template::symcgieuakksimmu())) { goto omkwqeiacwosgskq; } $nsmgceoqaqogqmuw = $kuyqaamgacigwcwq->iuygowkemiiwqmiw("\100\x70\x72\137\137\143\x6d\x6e\x5f\x5f\146\157\x75\156\144\141\x74\151\157\x6e\57{$qqscaoyqikuyeoaw}\56\x68\164\155\x6c\x2e\164\167\x69\147", $qookweymeqawmcwo); omkwqeiacwosgskq: return $nsmgceoqaqogqmuw; } }
