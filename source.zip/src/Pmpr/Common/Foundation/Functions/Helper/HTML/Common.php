<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f16aff73538             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if (!($kuyqaamgacigwcwq = Template::symcgieuakksimmu())) { goto ugiuakmiswagycwy; } $nsmgceoqaqogqmuw = $kuyqaamgacigwcwq->iuygowkemiiwqmiw("\x40\x70\162\x5f\x5f\x63\x6d\x6e\x5f\x5f\x66\x6f\165\156\x64\141\x74\x69\x6f\156\x2f{$qqscaoyqikuyeoaw}\x2e\150\164\x6d\x6c\x2e\164\x77\x69\x67", $qookweymeqawmcwo); ugiuakmiswagycwy: return $nsmgceoqaqogqmuw; } }
