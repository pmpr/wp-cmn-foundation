<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ced35949c89             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if (!($kuyqaamgacigwcwq = Template::symcgieuakksimmu())) { goto qiggceewmyagkisq; } $nsmgceoqaqogqmuw = $kuyqaamgacigwcwq->iuygowkemiiwqmiw("\100\160\162\137\x5f\143\x6d\156\137\137\146\x6f\x75\156\144\x61\164\151\x6f\156\x2f{$qqscaoyqikuyeoaw}\x2e\150\164\x6d\154\56\x74\x77\151\147", $qookweymeqawmcwo); qiggceewmyagkisq: return $nsmgceoqaqogqmuw; } }
