<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671269d4e15e3             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if ($yykoaiyakemcoqiu = pr_get_foundation()) { $nsmgceoqaqogqmuw = $yykoaiyakemcoqiu->iuygowkemiiwqmiw("\100\x70\x72\137\137\143\x6d\x6e\137\x5f\x66\157\165\156\x64\141\164\x69\x6f\x6e\57{$qqscaoyqikuyeoaw}\56\x68\164\155\x6c\x2e\x74\167\151\x67", $qookweymeqawmcwo); } return $nsmgceoqaqogqmuw; } }
