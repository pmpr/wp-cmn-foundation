<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f132f156703             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper\HTML; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Common\Foundation\Template\Template; abstract class Common extends BaseClass { protected function auqoykuwiywsocis(string $qqscaoyqikuyeoaw, array $qookweymeqawmcwo = []) : string { $nsmgceoqaqogqmuw = ''; if (!($kuyqaamgacigwcwq = Template::symcgieuakksimmu())) { goto iceweuyyswquiiea; } $nsmgceoqaqogqmuw = $kuyqaamgacigwcwq->iuygowkemiiwqmiw("\x40\160\x72\137\137\143\x6d\156\x5f\x5f\146\x6f\165\156\x64\141\164\151\x6f\156\57{$qqscaoyqikuyeoaw}\x2e\x68\164\x6d\x6c\x2e\x74\167\151\147", $qookweymeqawmcwo); iceweuyyswquiiea: return $nsmgceoqaqogqmuw; } }
