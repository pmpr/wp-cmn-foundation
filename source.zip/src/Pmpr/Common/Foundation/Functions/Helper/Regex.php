<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d8c7809438d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper; class Regex extends Common { }
