<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6807817a954f1             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper; use Pmpr\Common\Foundation\Interfaces\Constants; class Tool extends Common { public function iyiccksyewqymmqg($sogksuscggsicmac, $gwmokccqwwksmwye) : bool { $ymiyawysimukkoso = $sogksuscggsicmac[Constants::ycuusiweasqygwiw] ?? []; return (int) ($ymiyawysimukkoso[Constants::yusuiaeueqwieqqq] ?? 1) <= (int) $gwmokccqwwksmwye; } }
