<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6817b3c04cb4a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper; use Pmpr\Common\Foundation\Interfaces\Constants; class Tool extends Common { public function iyiccksyewqymmqg($sogksuscggsicmac, $gwmokccqwwksmwye) : bool { $ymiyawysimukkoso = $sogksuscggsicmac[Constants::ycuusiweasqygwiw] ?? []; return (int) ($ymiyawysimukkoso[Constants::yusuiaeueqwieqqq] ?? 1) <= (int) $gwmokccqwwksmwye; } public function mail(?string $acuayeeoiwokyomo, ?string $iosuwkkwwioumeqg, ?string $uamcoiueqaamsqma, array $aieaqakyuyewkkwe = [], array $uykgysuswksgmwqy = []) { if ($this->caokeucsksukesyo()->gyecsegqciqykomu()->qmyusgwkaqieouwi($uamcoiueqaamsqma)) { $uykgysuswksgmwqy[] = 'Content-Type: text/html; charset=UTF-8'; } return $this->uwkmaywceaaaigwo()->asgqmkcukouykiie()->mail($acuayeeoiwokyomo, $iosuwkkwwioumeqg, $uamcoiueqaamsqma, $uykgysuswksgmwqy, $aieaqakyuyewkkwe); } }
