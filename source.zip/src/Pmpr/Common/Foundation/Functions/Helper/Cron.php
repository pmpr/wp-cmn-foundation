<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ebf63ece5a6             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper; use Pmpr\Common\Foundation\Interfaces\Constants; class Cron extends Common { public function ecwaeokygwoiqmkk() : array { $qiouiwasaauyaaue = []; $immuisiomomksweo = $this->uwkmaywceaaaigwo()->cuwcwgaeiugaccei()->mggeycowqkwsieew(); $gkyciwoiiisgywcs = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc(); foreach ($immuisiomomksweo as $ymqmyyeuycgmigyo => $immaoamcsocgawcg) { if (!($kugsomueokogcawo = $gkyciwoiiisgywcs->get($immaoamcsocgawcg, Constants::qoawsacmmgmimqaw))) { goto qqqseeocmmummkga; } $qiouiwasaauyaaue[$ymqmyyeuycgmigyo] = $kugsomueokogcawo; qqqseeocmmummkga: maiokoamiosssisk: } kqacoqsymeyimagg: return $qiouiwasaauyaaue; } }
