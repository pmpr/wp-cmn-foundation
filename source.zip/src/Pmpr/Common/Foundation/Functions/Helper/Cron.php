<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce3480d954f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Functions\Helper; class Cron extends Common { public function ecwaeokygwoiqmkk() : array { $qiouiwasaauyaaue = []; $immuisiomomksweo = $this->uwkmaywceaaaigwo()->cuwcwgaeiugaccei()->mggeycowqkwsieew(); $gkyciwoiiisgywcs = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc(); foreach ($immuisiomomksweo as $ymqmyyeuycgmigyo => $immaoamcsocgawcg) { if (!($kugsomueokogcawo = $gkyciwoiiisgywcs->get($immaoamcsocgawcg, Constants::qoawsacmmgmimqaw))) { goto ywymuuggyeqggyqo; } $qiouiwasaauyaaue[$ymqmyyeuycgmigyo] = $kugsomueokogcawo; ywymuuggyeqggyqo: auwsmkeaswcqwkiy: } ouyqacmgssaeeyaq: return $qiouiwasaauyaaue; } }
