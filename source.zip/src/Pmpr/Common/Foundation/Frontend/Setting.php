<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67abce98c052e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Frontend; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Setting as BaseClass; class Setting extends BaseClass { public function __construct(?string $aokagokqyuysuksm = '', $meqocwsecsywiiqs = '') { $this->title = $meqocwsecsywiiqs; $this->hasLicense = false; $this->igiywquyccyiaucw(Constants::qoquaeuooeycomks, "\x6e\157\x2d\160\141\x72\x65\156\164"); parent::__construct($aokagokqyuysuksm); } }
