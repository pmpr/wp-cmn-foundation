<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ebe0a571651             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Asset\Traits; trait ManagerTrait { }
