<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f6b04b9a178             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Asset; use Pmpr\Common\Foundation\Container\Container; abstract class Common extends Container { const soyyisyeyqyeecog = "\x6a\x71\x75\145\162\171"; const qoeywcokwqacqsya = self::soyyisyeyqyeecog . "\x2d\143\x6f\162\x65"; const gioisuaakmsiauug = self::soyyisyeyqyeecog . "\x2d\x6d\x69\x67\x72\x61\x74\145"; }
