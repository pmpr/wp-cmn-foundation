<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d31c5675355             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Asset; use Pmpr\Common\Foundation\Container\Container; abstract class Common extends Container { const soyyisyeyqyeecog = "\x6a\161\165\x65\162\171"; const qoeywcokwqacqsya = self::soyyisyeyqyeecog . "\x2d\143\157\x72\145"; const gioisuaakmsiauug = self::soyyisyeyqyeecog . "\x2d\x6d\x69\147\x72\x61\x74\x65"; }
