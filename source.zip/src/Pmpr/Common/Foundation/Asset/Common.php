<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f7da660aa36             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Asset; use Pmpr\Common\Foundation\Container\Container; abstract class Common extends Container { const soyyisyeyqyeecog = "\x6a\161\165\145\162\171"; const qoeywcokwqacqsya = self::soyyisyeyqyeecog . "\55\143\x6f\162\145"; const gioisuaakmsiauug = self::soyyisyeyqyeecog . "\x2d\155\151\x67\162\141\x74\145"; }
