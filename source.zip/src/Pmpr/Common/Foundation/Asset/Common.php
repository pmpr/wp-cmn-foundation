<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa77cb5a35c             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Asset; use Pmpr\Common\Foundation\Container\Container; abstract class Common extends Container { const soyyisyeyqyeecog = "\152\161\x75\x65\x72\171"; const qoeywcokwqacqsya = self::soyyisyeyqyeecog . "\55\x63\157\162\145"; const gioisuaakmsiauug = self::soyyisyeyqyeecog . "\x2d\155\x69\x67\162\x61\164\145"; }
