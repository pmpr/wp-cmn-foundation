<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce54af64690             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Asset; use Pmpr\Common\Foundation\Container\Container; abstract class Common extends Container { const soyyisyeyqyeecog = "\x6a\161\165\x65\x72\x79"; const qoeywcokwqacqsya = self::soyyisyeyqyeecog . "\55\143\157\x72\x65"; const gioisuaakmsiauug = self::soyyisyeyqyeecog . "\55\155\x69\147\x72\141\x74\145"; }
