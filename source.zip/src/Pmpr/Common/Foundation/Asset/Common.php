<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cf4bac87f58             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Asset; use Pmpr\Common\Foundation\Container\Container; abstract class Common extends Container { const soyyisyeyqyeecog = "\152\161\165\145\162\x79"; const qoeywcokwqacqsya = self::soyyisyeyqyeecog . "\55\x63\157\x72\145"; const gioisuaakmsiauug = self::soyyisyeyqyeecog . "\55\155\151\147\x72\x61\164\145"; }
