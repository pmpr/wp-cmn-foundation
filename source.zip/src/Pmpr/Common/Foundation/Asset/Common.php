<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce3480d954f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Asset; use Pmpr\Common\Foundation\Container\Container; abstract class Common extends Container { const soyyisyeyqyeecog = "\x6a\161\x75\x65\x72\x79"; const qoeywcokwqacqsya = self::soyyisyeyqyeecog . "\55\x63\x6f\162\x65"; const gioisuaakmsiauug = self::soyyisyeyqyeecog . "\x2d\x6d\151\x67\x72\141\164\145"; }
