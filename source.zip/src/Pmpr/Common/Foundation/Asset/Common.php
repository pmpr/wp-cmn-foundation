<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f6c19d6f1c9             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Asset; use Pmpr\Common\Foundation\Container\Container; abstract class Common extends Container { const soyyisyeyqyeecog = "\152\161\x75\145\x72\171"; const qoeywcokwqacqsya = self::soyyisyeyqyeecog . "\x2d\x63\157\x72\x65"; const gioisuaakmsiauug = self::soyyisyeyqyeecog . "\x2d\155\x69\x67\162\x61\164\x65"; }
