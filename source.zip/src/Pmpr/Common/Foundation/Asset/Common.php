<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec08eec428e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Asset; use Pmpr\Common\Foundation\Container\Container; abstract class Common extends Container { const soyyisyeyqyeecog = "\152\x71\165\145\x72\x79"; const qoeywcokwqacqsya = self::soyyisyeyqyeecog . "\x2d\143\157\x72\145"; const gioisuaakmsiauug = self::soyyisyeyqyeecog . "\55\x6d\x69\147\162\x61\x74\x65"; }
