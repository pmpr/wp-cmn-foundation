<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1e3829f9fd             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Asset; use Pmpr\Common\Foundation\Container\Container; abstract class Common extends Container { const soyyisyeyqyeecog = "\x6a\161\x75\x65\162\x79"; const qoeywcokwqacqsya = self::soyyisyeyqyeecog . "\55\x63\157\162\145"; const gioisuaakmsiauug = self::soyyisyeyqyeecog . "\x2d\x6d\151\x67\162\141\x74\x65"; }
