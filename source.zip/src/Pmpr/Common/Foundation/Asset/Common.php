<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ebe0a571651             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Asset; use Pmpr\Common\Foundation\Container\Container; abstract class Common extends Container { const soyyisyeyqyeecog = "\152\161\165\x65\x72\x79"; const qoeywcokwqacqsya = self::soyyisyeyqyeecog . "\x2d\143\157\162\x65"; const gioisuaakmsiauug = self::soyyisyeyqyeecog . "\x2d\x6d\151\x67\x72\x61\164\145"; }
