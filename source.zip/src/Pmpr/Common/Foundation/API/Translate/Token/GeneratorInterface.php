<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6838de18a2884             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\API\Translate\Token; interface GeneratorInterface { }
