<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68dbbdda66681             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\API\Translate\Token; interface GeneratorInterface { }
