<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68d2c86bc35fa             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\API\Translate\Token; interface GeneratorInterface { }
