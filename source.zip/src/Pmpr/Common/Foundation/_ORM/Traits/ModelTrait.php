<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ebe0a571651             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\_ORM\Traits; use Pmpr\Common\Foundation\_ORM\Model; trait ModelTrait { protected Model $model; public function mgogaykgkoogasim() : Model { return $this->model; } public function asumqyigwsqmyeoc(Model $meywaqqsugaoeyys) : self { $this->model = $meywaqqsugaoeyys; return $this; } }
