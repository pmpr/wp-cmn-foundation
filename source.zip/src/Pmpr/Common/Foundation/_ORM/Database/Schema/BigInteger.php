<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f132f156703             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\_ORM\Database\Schema; class BigInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\142\x69\147\151\x6e\164"); parent::__construct("\x62\151\147\111\x6e\164\x65\147\x65\x72", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
