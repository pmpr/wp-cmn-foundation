<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ebf63ece5a6             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\_ORM\Database\Schema; class BigInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\x62\151\x67\x69\x6e\164"); parent::__construct("\x62\151\147\111\x6e\164\145\x67\x65\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
