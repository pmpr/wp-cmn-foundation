<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ebf559ba6b4             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\_ORM\Database\Schema; class BigInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\x62\151\147\x69\156\164"); parent::__construct("\142\x69\x67\111\x6e\x74\x65\x67\145\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
