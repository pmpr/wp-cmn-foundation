<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebdb08957             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\_ORM\Database\Schema; class BigInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->originType = "\142\151\x67\151\x6e\164"; parent::__construct("\x62\x69\147\111\156\164\145\x67\x65\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
