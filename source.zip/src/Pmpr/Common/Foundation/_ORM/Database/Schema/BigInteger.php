<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1e3829f9fd             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\_ORM\Database\Schema; class BigInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\x62\151\x67\151\x6e\x74"); parent::__construct("\142\x69\147\x49\x6e\164\145\147\x65\162", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
