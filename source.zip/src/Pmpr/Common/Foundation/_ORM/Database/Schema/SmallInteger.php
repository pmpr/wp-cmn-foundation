<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1e2ec7c9c7             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\_ORM\Database\Schema; class SmallInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\x73\x6d\141\x6c\154\151\x6e\x74"); parent::__construct("\163\155\141\x6c\x6c\111\x6e\x74\145\147\x65\x72", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
