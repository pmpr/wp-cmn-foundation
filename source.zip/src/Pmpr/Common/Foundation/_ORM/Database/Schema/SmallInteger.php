<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa77cb5a35c             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\_ORM\Database\Schema; class SmallInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\163\x6d\141\x6c\x6c\151\x6e\164"); parent::__construct("\163\155\141\x6c\154\111\156\164\x65\x67\145\x72", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
