<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec08eec428e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\_ORM\Database\Schema; class SmallInteger extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\163\155\x61\x6c\154\151\x6e\164"); parent::__construct("\163\x6d\141\154\154\x49\x6e\x74\x65\147\145\x72", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
