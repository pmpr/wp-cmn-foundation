<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f27b578294c             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\_ORM\Database\Schema; class Str extends Schema { public function __construct(string $aokagokqyuysuksm, ?string $meqocwsecsywiiqs = null) { $this->omqeokeyimawioym("\x76\x61\162\x63\150\141\x72"); parent::__construct("\x73\x74\162\151\156\x67", $aokagokqyuysuksm, $meqocwsecsywiiqs); } }
