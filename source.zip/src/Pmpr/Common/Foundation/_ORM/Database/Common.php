<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f2a5b59cf46             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\_ORM\Database; use Pmpr\Common\Foundation\_ORM\Common as BaseClass; class Common extends BaseClass { }
