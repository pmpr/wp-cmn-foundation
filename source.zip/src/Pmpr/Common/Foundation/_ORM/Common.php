<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f6c19d6f1c9             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\_ORM; use Pmpr\Common\Foundation\Container\Container; abstract class Common extends Container { }
