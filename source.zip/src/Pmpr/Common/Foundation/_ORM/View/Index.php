<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebdb08957             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\_ORM\View; class Index extends View { protected ?ListTable $listTable = null; public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\143\165\x72\162\145\x6e\164\x5f\163\x63\x72\145\x65\156", [$this, "\155\143\x6d\163\x63\x63\151\171\x75\153\x61\165\x65\163\141\165"]); } public function waeasakssissiuqg() : ListTable { if (!empty($this->listTable)) { goto ugoqkakikayagkmm; } $this->listTable = new ListTable(); ugoqkakikayagkmm: return $this->listTable; } }
