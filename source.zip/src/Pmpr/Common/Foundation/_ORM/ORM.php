<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec0c5dc5dae             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\_ORM; class ORM extends Common { public function mameiwsayuyquoeq() { if (!$this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq(Ajax::PREFIX)) { goto kosaqwikueyksqmw; } Ajax::symcgieuakksimmu(); kosaqwikueyksqmw: } }
