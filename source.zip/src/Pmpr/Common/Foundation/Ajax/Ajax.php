<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670da38bb56b4             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Ajax; use Pmpr\Common\Foundation\Container\Container; use Pmpr\Common\Foundation\Interfaces\Constants; class Ajax extends Container { public function mameiwsayuyquoeq() { Icon::ksyueceqagwomguk(); User::ksyueceqagwomguk(); Term::ksyueceqagwomguk(); Post::ksyueceqagwomguk(); Model::ksyueceqagwomguk(); Theme::ksyueceqagwomguk(); Plugin::ksyueceqagwomguk(); Comment::ksyueceqagwomguk(); StaticImage::ksyueceqagwomguk(); $this->iqkqummseggmikgo("\160\162\x5f\x66\162\x6f\x6e\164\x65\x6e\144\137\x67\x65\164\137\x6e\x6f\156\x63\145", [$this, "\x6b\x67\147\163\165\145\171\x75\171\161\x65\x71\x65\x75\x73\143"]); } public function kggsueyuyqeqeusc() { $keccaugmemegoimu = $this->uwkmaywceaaaigwo()->ogciwyoqgciosgcw()->ewgquygaowykwacc(Constants::waoywqksqecymesy, Constants::xwwaeweqegiqeqkm, true, false); $this->caokeucsksukesyo()->giiecckwoyiawoyy()->uaggqsoeugksgooc($keccaugmemegoimu); } }
