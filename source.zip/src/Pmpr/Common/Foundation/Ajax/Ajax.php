<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d3160ad4f5b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Ajax; use Pmpr\Common\Foundation\Container\Container; use Pmpr\Common\Foundation\Interfaces\Constants; class Ajax extends Container { public function mameiwsayuyquoeq() { Icon::ksyueceqagwomguk(); User::ksyueceqagwomguk(); Term::ksyueceqagwomguk(); Post::ksyueceqagwomguk(); Model::ksyueceqagwomguk(); Theme::ksyueceqagwomguk(); Plugin::ksyueceqagwomguk(); Comment::ksyueceqagwomguk(); StaticImage::ksyueceqagwomguk(); $this->iqkqummseggmikgo("\160\x72\x5f\x66\x72\x6f\x6e\x74\145\156\144\137\147\145\164\x5f\156\x6f\156\143\x65", [$this, "\153\x67\147\163\x75\145\x79\x75\171\x71\x65\161\x65\x75\163\x63"]); } public function kggsueyuyqeqeusc() { $keccaugmemegoimu = $this->uwkmaywceaaaigwo()->ogciwyoqgciosgcw()->ewgquygaowykwacc(Constants::waoywqksqecymesy, Constants::xwwaeweqegiqeqkm, true, false); $this->caokeucsksukesyo()->giiecckwoyiawoyy()->uaggqsoeugksgooc($keccaugmemegoimu); } }
