<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678038cba6aad             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Ajax; use Pmpr\Common\Foundation\Container\Container; use Pmpr\Common\Foundation\Interfaces\Constants; class Ajax extends Container { public function mameiwsayuyquoeq() { Icon::ksyueceqagwomguk(); User::ksyueceqagwomguk(); Term::ksyueceqagwomguk(); Post::ksyueceqagwomguk(); Model::ksyueceqagwomguk(); Theme::ksyueceqagwomguk(); Plugin::ksyueceqagwomguk(); Comment::ksyueceqagwomguk(); StaticImage::ksyueceqagwomguk(); $this->iqkqummseggmikgo("\160\x72\137\x66\162\157\156\164\x65\x6e\144\137\x67\145\164\x5f\x6e\x6f\x6e\x63\x65", [$this, "\153\147\x67\x73\x75\145\x79\x75\x79\x71\145\x71\145\x75\x73\x63"]); } public function kggsueyuyqeqeusc() { $keccaugmemegoimu = $this->uwkmaywceaaaigwo()->ogciwyoqgciosgcw()->ewgquygaowykwacc(Constants::waoywqksqecymesy, Constants::xwwaeweqegiqeqkm, true, false); $this->caokeucsksukesyo()->giiecckwoyiawoyy()->uaggqsoeugksgooc($keccaugmemegoimu); } }
