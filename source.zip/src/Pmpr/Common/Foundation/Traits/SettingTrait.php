<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d3160ad4f5b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Traits; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Setting; trait SettingTrait { protected ?Setting $settingObj = null; public final function kmuweyayaqoeqiyw() : ?Setting { return $this->settingObj; } public final function aoqykkmokwseeeie() : array { $qeqooyuoiasweuck = []; if (!($mksyucucyswaukig = $this->kmuweyayaqoeqiyw())) { goto gekuacoquiucucoa; } $qeqooyuoiasweuck = $mksyucucyswaukig->gkwkqmwweiawigae(); gekuacoquiucucoa: return $qeqooyuoiasweuck; } public final function weysguygiseoukqw(string $uusmaiomayssaecw, $ggauoeuaesiymgee = null) { $amakmumgguksgmum = $ggauoeuaesiymgee; if (!($mksyucucyswaukig = $this->kmuweyayaqoeqiyw())) { goto samuycgcmqkmcgea; } $amakmumgguksgmum = $mksyucucyswaukig->giiuwsmyumqwwiyq($uusmaiomayssaecw, $ggauoeuaesiymgee); samuycgcmqkmcgea: return $amakmumgguksgmum; } }
