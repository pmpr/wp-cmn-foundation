<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbd6d87474a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Traits; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Setting; trait SettingTrait { protected ?Setting $settingObj = null; public final function kmuweyayaqoeqiyw() : ?Setting { return $this->settingObj; } public final function aoqykkmokwseeeie() : array { $qeqooyuoiasweuck = []; if (!($mksyucucyswaukig = $this->kmuweyayaqoeqiyw())) { goto kmgimueiaqoamoiq; } $qeqooyuoiasweuck = $mksyucucyswaukig->gkwkqmwweiawigae(); kmgimueiaqoamoiq: return $qeqooyuoiasweuck; } public final function weysguygiseoukqw(string $uusmaiomayssaecw, $ggauoeuaesiymgee = null) { $amakmumgguksgmum = $ggauoeuaesiymgee; if (!($mksyucucyswaukig = $this->kmuweyayaqoeqiyw())) { goto uyesmwqkkaeqyqsw; } $amakmumgguksgmum = $mksyucucyswaukig->giiuwsmyumqwwiyq($uusmaiomayssaecw, $ggauoeuaesiymgee); uyesmwqkkaeqyqsw: return $amakmumgguksgmum; } }
