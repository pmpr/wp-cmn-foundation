<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d1dbc474879             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin; use Pmpr\Common\Foundation\Plugin\Ticket\Ticket; class Plugin extends Common { public function mameiwsayuyquoeq() { Ticket::ksyueceqagwomguk(); } }
