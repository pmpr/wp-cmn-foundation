<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce373d0ef0a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin; use Pmpr\Common\Foundation\Plugin\Ticket\Ticket; class Plugin extends Common { public function mameiwsayuyquoeq() { Ticket::ksyueceqagwomguk(); } }
