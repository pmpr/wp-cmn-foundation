<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6940431f1d8bd             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin; use Pmpr\Common\Foundation\Container\Container; use Pmpr\Common\Foundation\Plugin\Ticket\Ticket; class Plugin extends Container { public function mameiwsayuyquoeq() { Ticket::ksyueceqagwomguk(); } }
