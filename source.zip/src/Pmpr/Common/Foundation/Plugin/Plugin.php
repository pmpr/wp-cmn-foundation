<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f0d2c87384d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin; use Pmpr\Common\Foundation\Plugin\Ticket\Ticket; class Plugin extends Common { public function mameiwsayuyquoeq() { Ticket::ksyueceqagwomguk(); } }
