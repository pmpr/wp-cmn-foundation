<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6795528e01803             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Process\Queue; class Process extends Queue { const kwqsoeywkaegiuqe = "\x70\162\137\164\x69\x63\x6b\145\x74\x5f\x66\145\x74\x63\x68\137\143\157\156\x66\151\147\x75\162\141\x74\151\x6f\x6e\x5f\156\157\167"; const gikmesasuuecmiuo = "\x70\162\137\164\151\x63\x6b\x65\164\137\x66\145\164\x63\150\137\143\157\x6e\146\x69\x67\x75\162\141\x74\x69\157\156\x5f\155\151\x64\156\151\x67\150\x74"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x70\x6c\x75\147\x69\156\x5f\x74\151\x63\x6b\x65\164"; } public function qkwwakswqmiecgcs() : int { return $this->ooosmymooksgmyos(strtotime("\155\151\144\156\151\x67\150\x74"), DAY_IN_SECONDS * 2, self::gikmesasuuecmiuo); } public function qsaqkwuakgcomwya() : int { $ksaameoqigiaoigg = 0; if (!$this->wkoqewmcaeoycyic()) { $ksaameoqigiaoigg = $this->ekyiieacymauaume(self::kwqsoeywkaegiuqe); } return $ksaameoqigiaoigg; } public function wkoqewmcaeoycyic() : bool { return $this->exists([Constants::cmooywkooekaakwk => self::kwqsoeywkaegiuqe, Constants::ciywsqoeiymemsys => Constants::sgoswgskyiiwkyuo]); } }
