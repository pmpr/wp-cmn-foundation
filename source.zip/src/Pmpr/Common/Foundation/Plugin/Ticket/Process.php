<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d8808b3d38             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Process\Queue; class Process extends Queue { const kwqsoeywkaegiuqe = "\x70\162\137\x74\x69\x63\153\145\164\137\146\x65\164\x63\150\137\x63\x6f\x6e\146\x69\x67\165\x72\x61\164\151\x6f\156\137\x6e\157\167"; const gikmesasuuecmiuo = "\x70\x72\137\x74\151\143\153\x65\x74\137\x66\x65\x74\x63\150\x5f\x63\x6f\156\x66\x69\x67\x75\x72\x61\164\151\x6f\156\137\155\151\x64\x6e\151\147\x68\x74"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x70\154\x75\147\151\x6e\x5f\x74\x69\x63\x6b\145\x74"; } public function qkwwakswqmiecgcs() : int { return $this->ooosmymooksgmyos(strtotime("\155\151\x64\x6e\151\x67\x68\164"), DAY_IN_SECONDS * 2, self::gikmesasuuecmiuo); } public function qsaqkwuakgcomwya() : int { $ksaameoqigiaoigg = 0; if (!$this->wkoqewmcaeoycyic()) { $ksaameoqigiaoigg = $this->ekyiieacymauaume(self::kwqsoeywkaegiuqe); } return $ksaameoqigiaoigg; } public function wkoqewmcaeoycyic() : bool { return $this->exists([Constants::cmooywkooekaakwk => self::kwqsoeywkaegiuqe, Constants::ciywsqoeiymemsys => Constants::sgoswgskyiiwkyuo]); } }
