<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6714d8c066478             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Process\Queue; class Process extends Queue { const kwqsoeywkaegiuqe = "\160\x72\x5f\x74\x69\x63\x6b\x65\x74\137\146\145\x74\x63\150\x5f\143\x6f\x6e\x66\151\x67\165\x72\x61\x74\x69\157\156\137\156\x6f\167"; const gikmesasuuecmiuo = "\160\x72\x5f\164\151\143\x6b\145\164\x5f\146\x65\164\x63\x68\137\143\x6f\x6e\x66\151\147\x75\x72\x61\164\x69\x6f\x6e\137\155\x69\x64\156\151\x67\x68\164"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x70\x6c\x75\x67\x69\156\137\164\x69\x63\x6b\145\164"; } public function qkwwakswqmiecgcs() : int { return $this->ooosmymooksgmyos(strtotime("\155\151\x64\x6e\x69\147\x68\x74"), DAY_IN_SECONDS * 2, self::gikmesasuuecmiuo); } public function qsaqkwuakgcomwya() : int { $ksaameoqigiaoigg = 0; if (!$this->wkoqewmcaeoycyic()) { $ksaameoqigiaoigg = $this->ekyiieacymauaume(self::kwqsoeywkaegiuqe); } return $ksaameoqigiaoigg; } public function wkoqewmcaeoycyic() : bool { return $this->exists([Constants::cmooywkooekaakwk => self::kwqsoeywkaegiuqe, Constants::ciywsqoeiymemsys => Constants::sgoswgskyiiwkyuo]); } }
