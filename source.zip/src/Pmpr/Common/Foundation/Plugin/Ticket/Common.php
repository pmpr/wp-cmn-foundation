<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d8c7809438d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Plugin\Common as BaseClass; use Pmpr\Common\Foundation\Plugin\Ticket\Traits\SettingTrait; abstract class Common extends BaseClass { use SettingTrait; public function umqeyekmoagusaiq($iiwuoccgisuaoaka) : string { $iiwuoccgisuaoaka = (array) $iiwuoccgisuaoaka; if (isset($iiwuoccgisuaoaka[Constants::ckmsuwamgymouaeu])) { goto wsqiqkiucakewgou; } $igwimgwceysgwimw = get_custom_logo(); if ($igwimgwceysgwimw) { goto ywsywoumuaykkeaa; } $igwimgwceysgwimw = $this->uwkmaywceaaaigwo()->issssuygyewuaswa()->aeymcyaqkmmukomc(); ywsywoumuaykkeaa: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $igwimgwceysgwimw; goto yaumwqeommqigswq; wsqiqkiucakewgou: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $this->qaawomkouwoaoqma(Constants::mscgqqsgosmsqygq); yaumwqeommqigswq: $iiwuoccgisuaoaka[Constants::yqemseykugmsyeqa] = sprintf(__("\x25\163\40\x61\164\x20\x25\163", PR__CMN__FOUNDATION), "\x6a\x20\106\40\x59", "\x48\x3a\151"); return $this->iuygowkemiiwqmiw("\x63\157\x6e\166\x65\x72\x73\141\x74\x69\x6f\x6e", $iiwuoccgisuaoaka); } }
