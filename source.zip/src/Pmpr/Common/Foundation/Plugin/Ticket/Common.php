<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d31c5675355             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Plugin\Common as BaseClass; use Pmpr\Common\Foundation\Plugin\Ticket\Traits\SettingTrait; abstract class Common extends BaseClass { use SettingTrait; public function umqeyekmoagusaiq($iiwuoccgisuaoaka) : string { $iiwuoccgisuaoaka = (array) $iiwuoccgisuaoaka; if (isset($iiwuoccgisuaoaka[Constants::ckmsuwamgymouaeu])) { goto goaaoqkgsieiyuqm; } $igwimgwceysgwimw = get_custom_logo(); if ($igwimgwceysgwimw) { goto aywsyyewoswacqqy; } $igwimgwceysgwimw = $this->uwkmaywceaaaigwo()->issssuygyewuaswa()->aeymcyaqkmmukomc(); aywsyyewoswacqqy: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $igwimgwceysgwimw; goto wqiwmousomaigmgm; goaaoqkgsieiyuqm: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $this->qaawomkouwoaoqma(Constants::mscgqqsgosmsqygq); wqiwmousomaigmgm: $iiwuoccgisuaoaka[Constants::yqemseykugmsyeqa] = sprintf(__("\45\163\40\141\x74\40\45\163", PR__CMN__FOUNDATION), "\x6a\40\x46\40\x59", "\110\x3a\151"); return $this->iuygowkemiiwqmiw("\x63\157\x6e\x76\145\x72\163\x61\x74\x69\x6f\x6e", $iiwuoccgisuaoaka); } }
