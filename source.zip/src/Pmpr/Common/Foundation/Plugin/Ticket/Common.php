<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1d819504ee             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Plugin\Common as BaseClass; use Pmpr\Common\Foundation\Plugin\Ticket\Traits\SettingTrait; abstract class Common extends BaseClass { use SettingTrait; public function umqeyekmoagusaiq($iiwuoccgisuaoaka) : string { $iiwuoccgisuaoaka = (array) $iiwuoccgisuaoaka; if (isset($iiwuoccgisuaoaka[Constants::ckmsuwamgymouaeu])) { goto imyyokaecggauwca; } $igwimgwceysgwimw = get_custom_logo(); if ($igwimgwceysgwimw) { goto mwsogcaisqkoyoyo; } $igwimgwceysgwimw = $this->uwkmaywceaaaigwo()->issssuygyewuaswa()->aeymcyaqkmmukomc(); mwsogcaisqkoyoyo: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $igwimgwceysgwimw; goto iiieosoykaeycaks; imyyokaecggauwca: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $this->qaawomkouwoaoqma(Constants::mscgqqsgosmsqygq); iiieosoykaeycaks: $iiwuoccgisuaoaka[Constants::yqemseykugmsyeqa] = sprintf(__("\x25\163\x20\x61\x74\x20\45\163", PR__CMN__FOUNDATION), "\x6a\x20\106\40\131", "\x48\x3a\x69"); return $this->iuygowkemiiwqmiw("\x63\x6f\156\166\145\162\163\x61\x74\x69\x6f\x6e", $iiwuoccgisuaoaka); } }
