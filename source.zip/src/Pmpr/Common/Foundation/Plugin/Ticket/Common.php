<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1e3829f9fd             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Plugin\Common as BaseClass; use Pmpr\Common\Foundation\Plugin\Ticket\Traits\SettingTrait; abstract class Common extends BaseClass { use SettingTrait; public function umqeyekmoagusaiq($iiwuoccgisuaoaka) : string { $iiwuoccgisuaoaka = (array) $iiwuoccgisuaoaka; if (isset($iiwuoccgisuaoaka[Constants::ckmsuwamgymouaeu])) { goto aysgkuigyuqqcuae; } $igwimgwceysgwimw = get_custom_logo(); if ($igwimgwceysgwimw) { goto qiygeqkamwuomgie; } $igwimgwceysgwimw = $this->uwkmaywceaaaigwo()->issssuygyewuaswa()->aeymcyaqkmmukomc(); qiygeqkamwuomgie: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $igwimgwceysgwimw; goto ykyauiwkesygwwyq; aysgkuigyuqqcuae: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $this->qaawomkouwoaoqma(Constants::mscgqqsgosmsqygq); ykyauiwkesygwwyq: $iiwuoccgisuaoaka[Constants::yqemseykugmsyeqa] = sprintf(__("\45\x73\x20\x61\164\x20\x25\163", PR__CMN__FOUNDATION), "\152\40\106\x20\x59", "\x48\72\151"); return $this->iuygowkemiiwqmiw("\x63\157\x6e\x76\x65\162\163\141\164\x69\x6f\156", $iiwuoccgisuaoaka); } }
