<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce373d0ef0a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Plugin\Common as BaseClass; use Pmpr\Common\Foundation\Plugin\Ticket\Traits\SettingTrait; abstract class Common extends BaseClass { use SettingTrait; public function umqeyekmoagusaiq($iiwuoccgisuaoaka) : string { $iiwuoccgisuaoaka = (array) $iiwuoccgisuaoaka; if (isset($iiwuoccgisuaoaka[Constants::ckmsuwamgymouaeu])) { goto kkoukeoyauekomau; } $igwimgwceysgwimw = get_custom_logo(); if ($igwimgwceysgwimw) { goto qogyssukouuesqis; } $igwimgwceysgwimw = $this->uwkmaywceaaaigwo()->issssuygyewuaswa()->aeymcyaqkmmukomc(); qogyssukouuesqis: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $igwimgwceysgwimw; goto wgeqwaisweikegck; kkoukeoyauekomau: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $this->qaawomkouwoaoqma(Constants::mscgqqsgosmsqygq); wgeqwaisweikegck: $iiwuoccgisuaoaka[Constants::yqemseykugmsyeqa] = sprintf(__("\45\x73\x20\141\x74\x20\45\x73", PR__CMN__FOUNDATION), "\x6a\x20\106\x20\x59", "\x48\x3a\x69"); return $this->iuygowkemiiwqmiw("\x63\157\156\166\x65\x72\163\141\x74\151\157\x6e", $iiwuoccgisuaoaka); } }
