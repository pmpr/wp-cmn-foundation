<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae85ba078b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Plugin\Common as BaseClass; use Pmpr\Common\Foundation\Plugin\Ticket\Traits\SettingTrait; abstract class Common extends BaseClass { use SettingTrait; public function umqeyekmoagusaiq($iiwuoccgisuaoaka) : string { $iiwuoccgisuaoaka = (array) $iiwuoccgisuaoaka; if (isset($iiwuoccgisuaoaka[Constants::ckmsuwamgymouaeu])) { goto acaeigkmigikeuyu; } $igwimgwceysgwimw = get_custom_logo(); if ($igwimgwceysgwimw) { goto mciumqyyossyiuyk; } $igwimgwceysgwimw = $this->uwkmaywceaaaigwo()->issssuygyewuaswa()->aeymcyaqkmmukomc(); mciumqyyossyiuyk: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $igwimgwceysgwimw; goto kqyeukywmgismyaq; acaeigkmigikeuyu: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $this->qaawomkouwoaoqma(Constants::mscgqqsgosmsqygq); kqyeukywmgismyaq: $iiwuoccgisuaoaka[Constants::yqemseykugmsyeqa] = sprintf(__("\45\163\40\x61\x74\40\45\x73", PR__CMN__FOUNDATION), "\x6a\40\x46\x20\131", "\x48\x3a\151"); return $this->iuygowkemiiwqmiw("\x63\x6f\x6e\x76\x65\162\x73\141\x74\151\x6f\156", $iiwuoccgisuaoaka); } }
