<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f27b578294c             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Plugin\Common as BaseClass; use Pmpr\Common\Foundation\Plugin\Ticket\Traits\SettingTrait; abstract class Common extends BaseClass { use SettingTrait; public function umqeyekmoagusaiq($iiwuoccgisuaoaka) : string { $iiwuoccgisuaoaka = (array) $iiwuoccgisuaoaka; if (isset($iiwuoccgisuaoaka[Constants::ckmsuwamgymouaeu])) { goto ykyauiwkesygwwyq; } $igwimgwceysgwimw = get_custom_logo(); if ($igwimgwceysgwimw) { goto aysgkuigyuqqcuae; } $igwimgwceysgwimw = $this->uwkmaywceaaaigwo()->issssuygyewuaswa()->aeymcyaqkmmukomc(); aysgkuigyuqqcuae: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $igwimgwceysgwimw; goto kwacykquqegccocg; ykyauiwkesygwwyq: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $this->qaawomkouwoaoqma(Constants::mscgqqsgosmsqygq); kwacykquqegccocg: $iiwuoccgisuaoaka[Constants::yqemseykugmsyeqa] = sprintf(__("\45\163\x20\x61\x74\x20\x25\163", PR__CMN__FOUNDATION), "\152\x20\x46\x20\x59", "\110\x3a\x69"); return $this->iuygowkemiiwqmiw("\143\x6f\156\166\x65\162\x73\141\164\151\157\x6e", $iiwuoccgisuaoaka); } }
