<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d1dbc474879             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Plugin\Common as BaseClass; use Pmpr\Common\Foundation\Plugin\Ticket\Traits\SettingTrait; abstract class Common extends BaseClass { use SettingTrait; public function umqeyekmoagusaiq($iiwuoccgisuaoaka) : string { $iiwuoccgisuaoaka = (array) $iiwuoccgisuaoaka; if (isset($iiwuoccgisuaoaka[Constants::ckmsuwamgymouaeu])) { goto aywsyyewoswacqqy; } $igwimgwceysgwimw = get_custom_logo(); if ($igwimgwceysgwimw) { goto mogweaaaqocouiug; } $igwimgwceysgwimw = $this->uwkmaywceaaaigwo()->issssuygyewuaswa()->aeymcyaqkmmukomc(); mogweaaaqocouiug: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $igwimgwceysgwimw; goto goaaoqkgsieiyuqm; aywsyyewoswacqqy: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $this->qaawomkouwoaoqma(Constants::mscgqqsgosmsqygq); goaaoqkgsieiyuqm: $iiwuoccgisuaoaka[Constants::yqemseykugmsyeqa] = sprintf(__("\x25\163\40\141\164\40\x25\163", PR__CMN__FOUNDATION), "\152\40\106\x20\131", "\x48\x3a\151"); return $this->iuygowkemiiwqmiw("\x63\x6f\156\x76\145\162\163\141\x74\x69\x6f\x6e", $iiwuoccgisuaoaka); } }
