<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cf4bac87f58             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Plugin\Common as BaseClass; use Pmpr\Common\Foundation\Plugin\Ticket\Traits\SettingTrait; abstract class Common extends BaseClass { use SettingTrait; public function umqeyekmoagusaiq($iiwuoccgisuaoaka) : string { $iiwuoccgisuaoaka = (array) $iiwuoccgisuaoaka; if (isset($iiwuoccgisuaoaka[Constants::ckmsuwamgymouaeu])) { goto aywsyyewoswacqqy; } $igwimgwceysgwimw = get_custom_logo(); if ($igwimgwceysgwimw) { goto mogweaaaqocouiug; } $igwimgwceysgwimw = $this->uwkmaywceaaaigwo()->issssuygyewuaswa()->aeymcyaqkmmukomc(); mogweaaaqocouiug: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $igwimgwceysgwimw; goto goaaoqkgsieiyuqm; aywsyyewoswacqqy: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $this->qaawomkouwoaoqma(Constants::mscgqqsgosmsqygq); goaaoqkgsieiyuqm: $iiwuoccgisuaoaka[Constants::yqemseykugmsyeqa] = sprintf(__("\x25\x73\x20\x61\x74\40\45\x73", PR__CMN__FOUNDATION), "\x6a\x20\x46\40\x59", "\110\x3a\151"); return $this->iuygowkemiiwqmiw("\143\157\156\166\145\162\163\141\x74\x69\157\x6e", $iiwuoccgisuaoaka); } }
