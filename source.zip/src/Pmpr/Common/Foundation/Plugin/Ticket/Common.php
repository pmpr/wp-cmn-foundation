<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d3160ad4f5b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Plugin\Common as BaseClass; use Pmpr\Common\Foundation\Plugin\Ticket\Traits\SettingTrait; abstract class Common extends BaseClass { use SettingTrait; public function umqeyekmoagusaiq($iiwuoccgisuaoaka) : string { $iiwuoccgisuaoaka = (array) $iiwuoccgisuaoaka; if (isset($iiwuoccgisuaoaka[Constants::ckmsuwamgymouaeu])) { goto goaaoqkgsieiyuqm; } $igwimgwceysgwimw = get_custom_logo(); if ($igwimgwceysgwimw) { goto aywsyyewoswacqqy; } $igwimgwceysgwimw = $this->uwkmaywceaaaigwo()->issssuygyewuaswa()->aeymcyaqkmmukomc(); aywsyyewoswacqqy: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $igwimgwceysgwimw; goto wqiwmousomaigmgm; goaaoqkgsieiyuqm: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $this->qaawomkouwoaoqma(Constants::mscgqqsgosmsqygq); wqiwmousomaigmgm: $iiwuoccgisuaoaka[Constants::yqemseykugmsyeqa] = sprintf(__("\45\163\40\141\164\40\x25\x73", PR__CMN__FOUNDATION), "\152\40\x46\x20\131", "\x48\72\151"); return $this->iuygowkemiiwqmiw("\143\x6f\156\x76\x65\162\163\141\164\x69\157\x6e", $iiwuoccgisuaoaka); } }
