<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa77cb5a35c             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Plugin\Common as BaseClass; use Pmpr\Common\Foundation\Plugin\Ticket\Traits\SettingTrait; abstract class Common extends BaseClass { use SettingTrait; public function umqeyekmoagusaiq($iiwuoccgisuaoaka) : string { $iiwuoccgisuaoaka = (array) $iiwuoccgisuaoaka; if (isset($iiwuoccgisuaoaka[Constants::ckmsuwamgymouaeu])) { goto cwuiegmgmaoasqys; } $igwimgwceysgwimw = get_custom_logo(); if ($igwimgwceysgwimw) { goto agosuskgagmqkcqq; } $igwimgwceysgwimw = $this->uwkmaywceaaaigwo()->issssuygyewuaswa()->aeymcyaqkmmukomc(); agosuskgagmqkcqq: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $igwimgwceysgwimw; goto oqsgqmmoqoyoicia; cwuiegmgmaoasqys: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $this->qaawomkouwoaoqma(Constants::mscgqqsgosmsqygq); oqsgqmmoqoyoicia: $iiwuoccgisuaoaka[Constants::yqemseykugmsyeqa] = sprintf(__("\45\163\40\141\x74\40\45\x73", PR__CMN__FOUNDATION), "\x6a\x20\106\40\131", "\110\72\x69"); return $this->iuygowkemiiwqmiw("\x63\x6f\156\166\x65\162\163\x61\164\x69\157\x6e", $iiwuoccgisuaoaka); } }
