<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f16aff73538             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Plugin\Common as BaseClass; use Pmpr\Common\Foundation\Plugin\Ticket\Traits\SettingTrait; abstract class Common extends BaseClass { use SettingTrait; public function umqeyekmoagusaiq($iiwuoccgisuaoaka) : string { $iiwuoccgisuaoaka = (array) $iiwuoccgisuaoaka; if (isset($iiwuoccgisuaoaka[Constants::ckmsuwamgymouaeu])) { goto ieacisiumswqewsq; } $igwimgwceysgwimw = get_custom_logo(); if ($igwimgwceysgwimw) { goto keaaqaugoyquwsos; } $igwimgwceysgwimw = $this->uwkmaywceaaaigwo()->issssuygyewuaswa()->aeymcyaqkmmukomc(); keaaqaugoyquwsos: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $igwimgwceysgwimw; goto kskqckgmygiwqucm; ieacisiumswqewsq: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $this->qaawomkouwoaoqma(Constants::mscgqqsgosmsqygq); kskqckgmygiwqucm: $iiwuoccgisuaoaka[Constants::yqemseykugmsyeqa] = sprintf(__("\x25\x73\40\141\164\x20\45\163", PR__CMN__FOUNDATION), "\152\40\x46\x20\131", "\x48\72\151"); return $this->iuygowkemiiwqmiw("\x63\x6f\x6e\x76\145\x72\x73\x61\164\151\x6f\x6e", $iiwuoccgisuaoaka); } }
