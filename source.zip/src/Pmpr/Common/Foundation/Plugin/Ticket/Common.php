<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e16aefd43f6             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Plugin\Common as BaseClass; use Pmpr\Common\Foundation\Plugin\Ticket\Traits\SettingTrait; abstract class Common extends BaseClass { use SettingTrait; public function umqeyekmoagusaiq($iiwuoccgisuaoaka) : string { $iiwuoccgisuaoaka = (array) $iiwuoccgisuaoaka; if (isset($iiwuoccgisuaoaka[Constants::ckmsuwamgymouaeu])) { goto wsqiqkiucakewgou; } $igwimgwceysgwimw = get_custom_logo(); if ($igwimgwceysgwimw) { goto ywsywoumuaykkeaa; } $igwimgwceysgwimw = $this->uwkmaywceaaaigwo()->issssuygyewuaswa()->aeymcyaqkmmukomc(); ywsywoumuaykkeaa: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $igwimgwceysgwimw; goto yaumwqeommqigswq; wsqiqkiucakewgou: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $this->qaawomkouwoaoqma(Constants::mscgqqsgosmsqygq); yaumwqeommqigswq: $iiwuoccgisuaoaka[Constants::yqemseykugmsyeqa] = sprintf(__("\x25\163\40\141\164\x20\x25\x73", PR__CMN__FOUNDATION), "\152\x20\106\x20\131", "\110\72\151"); return $this->iuygowkemiiwqmiw("\143\x6f\x6e\166\145\162\x73\x61\x74\151\x6f\x6e", $iiwuoccgisuaoaka); } }
