<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ced75618540             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Plugin\Common as BaseClass; use Pmpr\Common\Foundation\Plugin\Ticket\Traits\SettingTrait; abstract class Common extends BaseClass { use SettingTrait; public function umqeyekmoagusaiq($iiwuoccgisuaoaka) : string { $iiwuoccgisuaoaka = (array) $iiwuoccgisuaoaka; if (isset($iiwuoccgisuaoaka[Constants::ckmsuwamgymouaeu])) { goto ukcoymqsgmcwokoq; } $igwimgwceysgwimw = get_custom_logo(); if ($igwimgwceysgwimw) { goto mgkaweokcicgiegg; } $igwimgwceysgwimw = $this->uwkmaywceaaaigwo()->issssuygyewuaswa()->aeymcyaqkmmukomc(); mgkaweokcicgiegg: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $igwimgwceysgwimw; goto degewusuggmqqeso; ukcoymqsgmcwokoq: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $this->qaawomkouwoaoqma(Constants::mscgqqsgosmsqygq); degewusuggmqqeso: $iiwuoccgisuaoaka[Constants::yqemseykugmsyeqa] = sprintf(__("\x25\163\40\141\164\x20\x25\163", PR__CMN__FOUNDATION), "\x6a\40\106\40\x59", "\x48\72\151"); return $this->iuygowkemiiwqmiw("\x63\x6f\x6e\x76\x65\x72\x73\x61\164\151\x6f\156", $iiwuoccgisuaoaka); } }
