<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f7da660aa36             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Plugin\Common as BaseClass; use Pmpr\Common\Foundation\Plugin\Ticket\Traits\SettingTrait; abstract class Common extends BaseClass { use SettingTrait; public function umqeyekmoagusaiq($iiwuoccgisuaoaka) : string { $iiwuoccgisuaoaka = (array) $iiwuoccgisuaoaka; if (isset($iiwuoccgisuaoaka[Constants::ckmsuwamgymouaeu])) { goto agosuskgagmqkcqq; } $igwimgwceysgwimw = get_custom_logo(); if ($igwimgwceysgwimw) { goto mqkkmgeccukekuus; } $igwimgwceysgwimw = $this->uwkmaywceaaaigwo()->issssuygyewuaswa()->aeymcyaqkmmukomc(); mqkkmgeccukekuus: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $igwimgwceysgwimw; goto cwuiegmgmaoasqys; agosuskgagmqkcqq: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $this->qaawomkouwoaoqma(Constants::mscgqqsgosmsqygq); cwuiegmgmaoasqys: $iiwuoccgisuaoaka[Constants::yqemseykugmsyeqa] = sprintf(__("\45\163\x20\x61\164\x20\x25\163", PR__CMN__FOUNDATION), "\x6a\x20\x46\40\x59", "\110\x3a\151"); return $this->iuygowkemiiwqmiw("\143\157\156\x76\145\162\x73\141\164\151\x6f\x6e", $iiwuoccgisuaoaka); } }
