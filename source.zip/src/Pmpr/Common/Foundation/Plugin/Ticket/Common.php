<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d2eee324173             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Plugin\Common as BaseClass; use Pmpr\Common\Foundation\Plugin\Ticket\Traits\SettingTrait; abstract class Common extends BaseClass { use SettingTrait; public function umqeyekmoagusaiq($iiwuoccgisuaoaka) : string { $iiwuoccgisuaoaka = (array) $iiwuoccgisuaoaka; if (isset($iiwuoccgisuaoaka[Constants::ckmsuwamgymouaeu])) { goto aywsyyewoswacqqy; } $igwimgwceysgwimw = get_custom_logo(); if ($igwimgwceysgwimw) { goto mogweaaaqocouiug; } $igwimgwceysgwimw = $this->uwkmaywceaaaigwo()->issssuygyewuaswa()->aeymcyaqkmmukomc(); mogweaaaqocouiug: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $igwimgwceysgwimw; goto goaaoqkgsieiyuqm; aywsyyewoswacqqy: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $this->qaawomkouwoaoqma(Constants::mscgqqsgosmsqygq); goaaoqkgsieiyuqm: $iiwuoccgisuaoaka[Constants::yqemseykugmsyeqa] = sprintf(__("\x25\163\40\x61\x74\x20\x25\163", PR__CMN__FOUNDATION), "\152\40\x46\40\131", "\x48\72\151"); return $this->iuygowkemiiwqmiw("\x63\x6f\156\x76\x65\162\163\x61\x74\151\157\156", $iiwuoccgisuaoaka); } }
