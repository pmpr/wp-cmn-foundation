<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce54af64690             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Plugin\Common as BaseClass; use Pmpr\Common\Foundation\Plugin\Ticket\Traits\SettingTrait; abstract class Common extends BaseClass { use SettingTrait; public function umqeyekmoagusaiq($iiwuoccgisuaoaka) : string { $iiwuoccgisuaoaka = (array) $iiwuoccgisuaoaka; if (isset($iiwuoccgisuaoaka[Constants::ckmsuwamgymouaeu])) { goto egmauuemqqqqsgic; } $igwimgwceysgwimw = get_custom_logo(); if ($igwimgwceysgwimw) { goto ogaqcigmoyoqcsws; } $igwimgwceysgwimw = $this->uwkmaywceaaaigwo()->issssuygyewuaswa()->aeymcyaqkmmukomc(); ogaqcigmoyoqcsws: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $igwimgwceysgwimw; goto agwyiymkkwmywcsw; egmauuemqqqqsgic: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $this->qaawomkouwoaoqma(Constants::mscgqqsgosmsqygq); agwyiymkkwmywcsw: $iiwuoccgisuaoaka[Constants::yqemseykugmsyeqa] = sprintf(__("\45\x73\40\x61\164\40\45\x73", PR__CMN__FOUNDATION), "\x6a\x20\x46\40\131", "\110\x3a\x69"); return $this->iuygowkemiiwqmiw("\143\x6f\x6e\x76\x65\x72\163\x61\164\x69\157\156", $iiwuoccgisuaoaka); } }
