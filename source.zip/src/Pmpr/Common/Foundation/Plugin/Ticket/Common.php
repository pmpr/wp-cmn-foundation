<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ebf63ece5a6             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Plugin\Common as BaseClass; use Pmpr\Common\Foundation\Plugin\Ticket\Traits\SettingTrait; abstract class Common extends BaseClass { use SettingTrait; public function umqeyekmoagusaiq($iiwuoccgisuaoaka) : string { $iiwuoccgisuaoaka = (array) $iiwuoccgisuaoaka; if (isset($iiwuoccgisuaoaka[Constants::ckmsuwamgymouaeu])) { goto gsscqquysycuswow; } $igwimgwceysgwimw = get_custom_logo(); if ($igwimgwceysgwimw) { goto eisoouawyymkasou; } $igwimgwceysgwimw = $this->uwkmaywceaaaigwo()->issssuygyewuaswa()->aeymcyaqkmmukomc(); eisoouawyymkasou: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $igwimgwceysgwimw; goto uwcgosckamuosimw; gsscqquysycuswow: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $this->qaawomkouwoaoqma(Constants::mscgqqsgosmsqygq); uwcgosckamuosimw: $iiwuoccgisuaoaka[Constants::yqemseykugmsyeqa] = sprintf(__("\45\163\40\141\164\40\45\163", PR__CMN__FOUNDATION), "\x6a\40\x46\40\x59", "\110\x3a\151"); return $this->iuygowkemiiwqmiw("\x63\x6f\156\166\145\x72\163\x61\164\151\x6f\156", $iiwuoccgisuaoaka); } }
