<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ced35949c89             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Plugin\Common as BaseClass; use Pmpr\Common\Foundation\Plugin\Ticket\Traits\SettingTrait; abstract class Common extends BaseClass { use SettingTrait; public function umqeyekmoagusaiq($iiwuoccgisuaoaka) : string { $iiwuoccgisuaoaka = (array) $iiwuoccgisuaoaka; if (isset($iiwuoccgisuaoaka[Constants::ckmsuwamgymouaeu])) { goto ukcoymqsgmcwokoq; } $igwimgwceysgwimw = get_custom_logo(); if ($igwimgwceysgwimw) { goto mgkaweokcicgiegg; } $igwimgwceysgwimw = $this->uwkmaywceaaaigwo()->issssuygyewuaswa()->aeymcyaqkmmukomc(); mgkaweokcicgiegg: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $igwimgwceysgwimw; goto degewusuggmqqeso; ukcoymqsgmcwokoq: $iiwuoccgisuaoaka[Constants::owsgqueosiqycgky] = $this->qaawomkouwoaoqma(Constants::mscgqqsgosmsqygq); degewusuggmqqeso: $iiwuoccgisuaoaka[Constants::yqemseykugmsyeqa] = sprintf(__("\45\163\40\x61\164\x20\45\163", PR__CMN__FOUNDATION), "\x6a\40\x46\40\x59", "\110\x3a\x69"); return $this->iuygowkemiiwqmiw("\143\x6f\x6e\x76\145\x72\163\141\x74\151\157\156", $iiwuoccgisuaoaka); } }
