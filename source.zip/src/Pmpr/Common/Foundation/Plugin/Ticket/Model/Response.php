<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67abdb6f91c28             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Response extends AbstractResponse { public function register() { $this->saemoowcasogykak(IconInterface::osaqwqwkkmocawgs)->guiaswksukmgageq(__("\x52\x65\x73\x70\x6f\x6e\163\145", PR__CMN__FOUNDATION))->muuwuqssqkaieqge(__("\x52\145\x73\160\157\x6e\x73\145\x73", PR__CMN__FOUNDATION)); parent::register(); } public function uwmqacgewuauagai() { parent::uwmqacgewuauagai(); $eqwoegegiamegqsm = $this->caokeucsksukesyo()->skckwsgymkimyuwo(); $this->cquokmemekqqywgi($eqwoegegiamegqsm->qoemykoeuecmsmwe(Constants::ckmsuwamgymouaeu)->gswweykyogmsyawy(__("\x52\x65\x73\x70\157\x6e\x64\x65\162", PR__CMN__FOUNDATION))->acceqyqygswoecwe(8)); } }
