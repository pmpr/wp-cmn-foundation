<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f0d2c87384d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Response extends AbstractResponse { public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->oyeskqayoscwciem()->yioesawwewqaigow(IconInterface::osaqwqwkkmocawgs)->guiaswksukmgageq(__("\122\x65\163\x70\x6f\x6e\163\145", PR__CMN__FOUNDATION))->muuwuqssqkaieqge(__("\122\145\x73\160\x6f\156\x73\145\x73", PR__CMN__FOUNDATION)); } public function ewaqwooqoqmcoomi() { parent::ewaqwooqoqmcoomi(); $this->cquokmemekqqywgi($this->qoemykoeuecmsmwe(Constants::ckmsuwamgymouaeu)->acceqyqygswoecwe(8)->gswweykyogmsyawy(__("\x52\x65\163\160\157\156\144\x65\x72", PR__CMN__FOUNDATION))); } }
