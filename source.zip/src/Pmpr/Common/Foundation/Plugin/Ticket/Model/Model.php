<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ced75618540             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket\Model; use Pmpr\Common\Foundation\Plugin\Ticket\Common; class Model extends Common { public function aqyikqugcomoqqqi() { Ticket::symcgieuakksimmu(); Request::symcgieuakksimmu(); Response::symcgieuakksimmu(); } }
