<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e16aefd43f6             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket\Model; use Pmpr\Common\Foundation\Interfaces\Constants; abstract class AbstractResponse extends Common { const asywgyemkouimocw = "\x74\x69\143\x6b\x65\164" . Constants::mswocgcucqoaesaa; public $timestamps = [self::CREATED_AT]; public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->esoauokkgywesoku([Constants::cqycgsyykemiygou => __("\x41\164\x74\141\143\x68\x6d\x65\x6e\164", PR__CMN__FOUNDATION)]); } public function ewaqwooqoqmcoomi() { $this->cquokmemekqqywgi($this->gysoeyaguiyewoes(Constants::TEXT)->gswweykyogmsyawy(__("\x54\145\170\x74", PR__CMN__FOUNDATION)))->cquokmemekqqywgi($this->eoaomaokwkwqyqiq(self::asywgyemkouimocw)->gswweykyogmsyawy(__("\124\x69\x63\x6b\x65\164", PR__CMN__FOUNDATION))->wuuqgaekqeymecag(Ticket::class)->eewuieiqoqmekwmw(Constants::sayycgcceusuyycg)); parent::ewaqwooqoqmcoomi(); } }
