<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d1dbc474879             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\ORM\DB\Model; use Pmpr\Common\Foundation\Plugin\Ticket\Traits\SettingTrait; abstract class Common extends Model { use SettingTrait; const yeaekcacwwyyqigq = "\x74\151\143\153\145\x74"; const asywgyemkouimocw = self::yeaekcacwwyyqigq . Constants::mswocgcucqoaesaa; public function ckgmycmaukqgkosk() { $quowyokcwswmuois = $this->akuociswqmoigkas(); $this->oyeskqayoscwciem()->myysgyqcumekoueo()->okgmqaeuaeymaocm($quowyokcwswmuois); parent::ckgmycmaukqgkosk(); } public function ewaqwooqoqmcoomi() { $this->cquokmemekqqywgi($this->gysoeyaguiyewoes(Constants::IDENTIFIER)->acokiqqgsmoqaeyu()->gswweykyogmsyawy(__("\111\144\x65\x6e\x74\151\x66\151\145\162", PR__CMN__FOUNDATION))); parent::ewaqwooqoqmcoomi(); } }
