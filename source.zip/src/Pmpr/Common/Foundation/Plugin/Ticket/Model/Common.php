<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             679574b80d243             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\ORM\Model; use Pmpr\Common\Foundation\Plugin\Ticket\Traits\SettingTrait; abstract class Common extends Model { use SettingTrait; const yeaekcacwwyyqigq = "\164\x69\x63\x6b\145\x74"; const asywgyemkouimocw = self::yeaekcacwwyyqigq . Constants::mswocgcucqoaesaa; public function uwmqacgewuauagai() { $eqwoegegiamegqsm = $this->caokeucsksukesyo()->skckwsgymkimyuwo(); $this->cquokmemekqqywgi($eqwoegegiamegqsm->gysoeyaguiyewoes(Constants::IDENTIFIER)->gswweykyogmsyawy(__("\x49\x64\x65\156\164\x69\146\x69\145\x72", PR__CMN__FOUNDATION))->acokiqqgsmoqaeyu()); parent::uwmqacgewuauagai(); } }
