<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ced75618540             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Plugin\Ticket\Traits; trait SettingTrait { public function gsqkwyaueoaeyqqs() { static $qeqooyuoiasweuck; if (!empty($qeqooyuoiasweuck)) { goto awwgggeiaceyecco; } $qeqooyuoiasweuck = $this->uwkmaywceaaaigwo()->giiuwsmyumqwwiyq()->get("\164\x69\143\153\145\x74\x5f\x73\145\164\164\151\x6e\147\163", []); awwgggeiaceyecco: return $qeqooyuoiasweuck; } public function qaawomkouwoaoqma(string $uusmaiomayssaecw, $ggauoeuaesiymgee = null) { return $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($this->gsqkwyaueoaeyqqs(), $uusmaiomayssaecw, $ggauoeuaesiymgee); } }
