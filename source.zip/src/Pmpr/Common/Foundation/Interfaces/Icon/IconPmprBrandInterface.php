<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d9fc9a7712             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\155\160\162\57\61\x2f\x62\162\141\156\x64\57\x70\155\160\162\55\163\155\141\x6c\x6c"; const aoceigukcccyimew = "\160\x6d\x70\x72\x2f\x31\x2f\x62\162\x61\x6e\x64\x2f\x63\154\x6f\165\x64\146\154\x61\x72\x65"; }
