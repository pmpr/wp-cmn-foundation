<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ebf63ece5a6             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\x6d\x70\x72\57\61\57\x62\162\141\x6e\x64\57\160\155\160\x72\x2d\163\155\x61\154\x6c"; const aoceigukcccyimew = "\160\155\x70\x72\x2f\61\x2f\x62\162\x61\x6e\144\57\143\154\x6f\x75\144\x66\154\141\162\x65"; }
