<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d43c49e811             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\x6d\x70\162\x2f\61\x2f\142\x72\141\156\x64\57\x70\x6d\160\x72\55\x73\155\x61\x6c\154"; const aoceigukcccyimew = "\x70\x6d\160\162\57\x31\x2f\142\162\x61\x6e\x64\57\x63\154\157\x75\x64\146\x6c\x61\x72\145"; }
