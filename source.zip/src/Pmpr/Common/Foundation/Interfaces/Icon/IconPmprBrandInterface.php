<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ebf559ba6b4             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\155\x70\x72\x2f\61\57\x62\162\141\x6e\144\57\160\x6d\x70\162\55\x73\x6d\x61\x6c\x6c"; const aoceigukcccyimew = "\x70\x6d\160\162\57\61\x2f\x62\162\141\156\144\57\x63\x6c\157\165\x64\x66\x6c\141\x72\x65"; }
