<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1d819504ee             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\x6d\160\162\57\x31\x2f\142\162\141\x6e\x64\57\160\155\x70\162\55\x73\x6d\141\154\x6c"; const aoceigukcccyimew = "\x70\x6d\160\x72\57\x31\x2f\x62\x72\141\156\144\x2f\x63\x6c\x6f\x75\144\x66\x6c\141\162\145"; }
