<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6751a9817f249             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\x6d\160\162\x2f\x31\x2f\x62\x72\x61\x6e\x64\57\x70\x6d\x70\x72\x2d\x73\155\141\x6c\154"; const aoceigukcccyimew = "\x70\x6d\160\x72\x2f\x31\57\x62\162\141\x6e\144\x2f\143\154\157\165\x64\x66\154\141\x72\x65"; }
