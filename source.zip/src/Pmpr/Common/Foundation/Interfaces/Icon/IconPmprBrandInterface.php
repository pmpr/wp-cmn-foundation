<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f2a5b59cf46             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\155\x70\x72\x2f\x31\57\x62\x72\141\156\144\57\x70\x6d\x70\x72\x2d\x73\x6d\141\x6c\x6c"; const aoceigukcccyimew = "\x70\x6d\160\162\x2f\x31\x2f\x62\162\x61\156\144\57\x63\x6c\x6f\165\144\146\154\x61\x72\145"; }
