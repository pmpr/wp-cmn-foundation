<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4a8d73504             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\x6d\x70\x72\57\61\57\142\162\x61\156\144\57\160\x6d\x70\x72\x2d\163\x6d\x61\154\x6c"; const aoceigukcccyimew = "\x70\x6d\160\x72\x2f\x31\x2f\x62\162\141\156\x64\x2f\143\154\157\x75\x64\x66\154\x61\162\x65"; }
