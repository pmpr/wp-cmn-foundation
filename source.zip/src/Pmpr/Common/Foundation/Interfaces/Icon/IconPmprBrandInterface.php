<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d8c7809438d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\155\160\x72\x2f\61\x2f\142\162\141\x6e\x64\57\160\155\160\x72\x2d\163\155\141\x6c\154"; const aoceigukcccyimew = "\x70\x6d\160\x72\57\x31\x2f\x62\162\141\156\144\57\x63\154\x6f\x75\144\146\x6c\141\162\145"; }
