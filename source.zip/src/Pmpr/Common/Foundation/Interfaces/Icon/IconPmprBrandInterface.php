<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f15ee33c813             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\155\x70\162\x2f\x31\57\x62\x72\141\156\x64\57\160\155\160\162\x2d\x73\x6d\141\154\154"; const aoceigukcccyimew = "\160\155\160\162\x2f\61\x2f\x62\x72\x61\156\x64\57\x63\x6c\x6f\x75\x64\146\154\x61\x72\x65"; }
