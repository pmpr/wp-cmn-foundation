<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e16aefd43f6             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\155\x70\162\x2f\61\x2f\x62\x72\x61\x6e\x64\x2f\160\x6d\160\162\55\x73\x6d\x61\154\x6c"; const aoceigukcccyimew = "\160\155\x70\162\x2f\61\x2f\x62\x72\x61\x6e\144\57\x63\154\x6f\x75\x64\146\x6c\x61\162\145"; }
