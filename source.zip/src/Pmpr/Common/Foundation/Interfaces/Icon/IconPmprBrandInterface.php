<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d3160ad4f5b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\155\x70\162\57\61\x2f\x62\x72\141\x6e\144\57\x70\x6d\160\162\x2d\163\x6d\141\154\x6c"; const aoceigukcccyimew = "\x70\155\160\162\57\x31\x2f\x62\162\x61\156\x64\x2f\143\154\x6f\165\144\x66\x6c\x61\x72\145"; }
