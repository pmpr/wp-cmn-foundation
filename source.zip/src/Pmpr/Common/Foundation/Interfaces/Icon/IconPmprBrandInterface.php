<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ced75618540             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\155\160\162\x2f\61\57\x62\x72\141\x6e\144\57\160\x6d\160\162\55\163\x6d\x61\x6c\154"; const aoceigukcccyimew = "\x70\x6d\x70\162\x2f\61\x2f\142\x72\141\x6e\x64\57\143\x6c\x6f\165\x64\x66\x6c\141\162\145"; }
