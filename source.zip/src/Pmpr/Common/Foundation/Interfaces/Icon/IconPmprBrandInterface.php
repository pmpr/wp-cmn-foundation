<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6751a903a9160             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\155\x70\x72\x2f\x31\57\142\x72\141\156\x64\x2f\160\155\160\x72\x2d\x73\155\141\x6c\x6c"; const aoceigukcccyimew = "\160\x6d\x70\162\x2f\x31\57\x62\162\141\x6e\x64\57\x63\x6c\157\165\x64\146\x6c\141\x72\x65"; }
