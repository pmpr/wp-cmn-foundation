<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f7da660aa36             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\x6d\x70\x72\x2f\x31\57\x62\162\x61\x6e\144\x2f\x70\x6d\x70\x72\55\x73\x6d\141\154\x6c"; const aoceigukcccyimew = "\160\155\160\162\57\61\57\142\x72\141\156\144\57\143\x6c\x6f\165\x64\x66\154\x61\x72\145"; }
