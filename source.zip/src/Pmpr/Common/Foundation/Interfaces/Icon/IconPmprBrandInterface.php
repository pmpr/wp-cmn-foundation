<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6758160d13747             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\x6d\x70\162\x2f\x31\x2f\142\x72\141\x6e\x64\57\160\155\x70\162\x2d\163\155\141\154\154"; const aoceigukcccyimew = "\160\x6d\x70\x72\x2f\x31\x2f\142\x72\141\x6e\144\57\143\x6c\157\165\x64\146\x6c\x61\x72\145"; }
