<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670ed89ca3e21             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\155\x70\162\x2f\x31\x2f\142\x72\141\x6e\144\57\160\155\160\162\55\x73\155\141\x6c\154"; const aoceigukcccyimew = "\160\x6d\x70\162\57\x31\57\x62\x72\141\156\x64\x2f\x63\154\157\165\144\146\x6c\x61\162\145"; }
