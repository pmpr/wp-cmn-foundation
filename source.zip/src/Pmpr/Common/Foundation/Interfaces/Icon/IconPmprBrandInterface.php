<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6797767677d97             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\155\160\x72\57\61\57\x62\162\141\156\x64\57\x70\155\x70\162\55\x73\x6d\141\154\154"; const aoceigukcccyimew = "\160\155\160\x72\57\x31\x2f\142\x72\141\156\144\x2f\x63\154\157\x75\144\146\154\141\x72\x65"; }
