<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bbd8a709c0             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\155\160\x72\x2f\x31\57\x62\162\x61\156\x64\57\160\155\160\x72\x2d\163\x6d\141\x6c\x6c"; const aoceigukcccyimew = "\160\x6d\x70\162\x2f\61\x2f\x62\x72\141\156\x64\57\143\154\x6f\165\x64\146\x6c\x61\162\x65"; }
