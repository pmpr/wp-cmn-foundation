<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce54af64690             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\x6d\x70\x72\x2f\x31\x2f\142\x72\141\x6e\144\57\x70\155\160\x72\55\163\155\x61\154\x6c"; const aoceigukcccyimew = "\160\155\x70\x72\x2f\x31\x2f\142\x72\x61\156\x64\57\143\154\157\165\144\x66\154\x61\162\x65"; }
