<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67580c605cb9d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\x6d\160\x72\x2f\x31\x2f\142\162\x61\x6e\x64\x2f\160\155\x70\x72\55\x73\155\141\154\154"; const aoceigukcccyimew = "\160\155\160\x72\x2f\x31\57\x62\x72\x61\156\144\x2f\143\154\x6f\x75\x64\x66\154\x61\162\x65"; }
