<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f6c19d6f1c9             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\155\160\162\57\61\x2f\x62\162\x61\x6e\144\57\160\155\160\x72\55\163\155\x61\x6c\154"; const aoceigukcccyimew = "\x70\x6d\x70\162\57\x31\x2f\142\x72\141\x6e\144\57\143\x6c\157\x75\144\x66\x6c\141\162\145"; }
