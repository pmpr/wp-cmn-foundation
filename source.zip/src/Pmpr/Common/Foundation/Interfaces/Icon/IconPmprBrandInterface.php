<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6795528e01803             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\155\x70\162\x2f\61\57\x62\x72\x61\156\144\x2f\x70\155\160\162\x2d\163\155\141\x6c\154"; const aoceigukcccyimew = "\160\x6d\x70\162\x2f\x31\57\x62\162\141\156\144\57\x63\154\157\165\x64\x66\x6c\141\x72\x65"; }
