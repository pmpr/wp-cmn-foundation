<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d83a3160ed             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\155\160\162\57\x31\x2f\x62\x72\141\x6e\x64\x2f\x70\155\160\162\55\x73\155\141\x6c\154"; const aoceigukcccyimew = "\160\155\x70\162\x2f\61\57\x62\x72\x61\156\x64\x2f\x63\x6c\x6f\x75\144\146\x6c\x61\162\145"; }
