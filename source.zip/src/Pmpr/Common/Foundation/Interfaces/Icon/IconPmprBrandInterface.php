<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             679576175075e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\x6d\160\x72\x2f\61\x2f\142\x72\141\x6e\x64\x2f\x70\x6d\x70\x72\55\x73\x6d\141\154\x6c"; const aoceigukcccyimew = "\x70\x6d\x70\x72\57\x31\x2f\x62\162\141\x6e\x64\x2f\x63\154\157\165\x64\x66\154\x61\162\x65"; }
