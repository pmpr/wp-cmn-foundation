<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6705246332371             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\x6d\160\x72\x2f\61\57\x62\162\141\x6e\x64\57\160\155\x70\x72\x2d\163\155\141\x6c\154"; const aoceigukcccyimew = "\x70\155\160\x72\x2f\x31\57\x62\x72\141\156\x64\x2f\x63\x6c\157\x75\x64\146\154\141\162\x65"; }
