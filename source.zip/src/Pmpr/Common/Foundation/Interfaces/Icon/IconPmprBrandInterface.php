<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ced35949c89             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\155\x70\x72\57\x31\x2f\x62\162\141\x6e\x64\57\x70\x6d\x70\162\x2d\x73\x6d\x61\154\x6c"; const aoceigukcccyimew = "\x70\x6d\160\x72\57\61\57\142\x72\141\156\144\x2f\x63\154\x6f\165\144\x66\x6c\x61\x72\145"; }
