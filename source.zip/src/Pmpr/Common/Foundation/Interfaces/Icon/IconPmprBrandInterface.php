<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebdb08957             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\155\160\162\x2f\x31\x2f\x62\162\x61\x6e\x64\57\160\155\160\162\55\x73\155\141\x6c\x6c"; const aoceigukcccyimew = "\x70\155\160\x72\57\61\57\x62\162\141\156\x64\57\x63\154\157\x75\144\146\154\141\x72\x65"; }
