<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce6343424e0             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\155\160\x72\57\61\x2f\x62\x72\x61\x6e\144\57\x70\155\x70\x72\x2d\163\155\141\x6c\x6c"; const aoceigukcccyimew = "\x70\x6d\x70\x72\x2f\x31\x2f\x62\x72\x61\156\x64\x2f\143\x6c\157\165\x64\x66\x6c\141\x72\x65"; }
