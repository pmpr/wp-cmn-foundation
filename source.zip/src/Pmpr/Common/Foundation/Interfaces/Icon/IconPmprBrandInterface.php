<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d8808b3d38             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\155\x70\162\57\x31\57\142\162\141\x6e\144\57\160\x6d\x70\x72\x2d\163\x6d\x61\x6c\x6c"; const aoceigukcccyimew = "\160\155\x70\162\x2f\x31\x2f\x62\x72\x61\x6e\144\x2f\143\154\x6f\x75\x64\146\x6c\141\162\x65"; }
