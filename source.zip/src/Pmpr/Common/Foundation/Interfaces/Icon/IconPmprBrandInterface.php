<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d2eee324173             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\155\x70\162\57\61\57\142\162\x61\x6e\144\57\160\155\160\x72\55\163\x6d\141\154\x6c"; const aoceigukcccyimew = "\160\155\x70\162\57\x31\57\x62\162\141\x6e\144\57\143\x6c\x6f\x75\x64\x66\x6c\x61\162\145"; }
