<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce38dda53fd             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\155\x70\x72\57\x31\57\x62\162\x61\x6e\x64\x2f\160\x6d\x70\162\55\x73\155\141\154\154"; const aoceigukcccyimew = "\x70\155\x70\x72\x2f\61\57\x62\x72\141\x6e\x64\x2f\x63\154\x6f\x75\144\146\x6c\141\162\145"; }
