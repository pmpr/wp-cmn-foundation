<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675819f57c47e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\155\x70\162\x2f\x31\57\142\x72\141\156\x64\x2f\160\155\x70\162\x2d\163\155\141\154\154"; const aoceigukcccyimew = "\x70\155\160\162\x2f\x31\57\x62\x72\141\156\x64\57\x63\154\x6f\x75\144\x66\154\x61\x72\x65"; }
