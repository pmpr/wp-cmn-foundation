<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d1dbc474879             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\x6d\160\162\x2f\61\x2f\x62\x72\x61\156\x64\x2f\160\x6d\160\162\x2d\x73\x6d\141\154\154"; const aoceigukcccyimew = "\160\x6d\160\162\x2f\x31\57\142\x72\141\156\x64\57\143\154\157\165\x64\146\154\141\162\145"; }
