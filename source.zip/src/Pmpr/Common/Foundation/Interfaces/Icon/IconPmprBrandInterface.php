<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f16aff73538             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\155\160\162\x2f\61\x2f\x62\162\141\x6e\144\x2f\160\x6d\160\162\x2d\163\155\141\154\x6c"; const aoceigukcccyimew = "\160\155\x70\x72\57\x31\57\x62\162\141\156\144\57\x63\154\157\165\144\146\x6c\x61\x72\145"; }
