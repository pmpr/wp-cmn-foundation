<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae85ba078b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\x6d\160\162\x2f\61\x2f\142\162\141\156\144\57\160\155\160\x72\x2d\x73\155\x61\154\x6c"; const aoceigukcccyimew = "\x70\x6d\160\x72\57\61\57\142\x72\x61\x6e\144\57\143\154\x6f\x75\144\146\154\141\x72\x65"; }
