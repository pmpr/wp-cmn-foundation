<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6793da3275295             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\155\x70\x72\57\x31\x2f\142\162\141\x6e\x64\57\160\155\x70\162\55\163\155\x61\x6c\x6c"; const aoceigukcccyimew = "\160\x6d\160\162\57\61\x2f\x62\x72\x61\156\x64\57\x63\154\157\x75\x64\x66\154\141\x72\145"; }
