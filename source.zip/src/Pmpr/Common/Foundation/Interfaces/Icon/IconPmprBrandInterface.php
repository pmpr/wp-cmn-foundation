<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678d3d485c530             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\x6d\x70\162\57\x31\57\x62\162\x61\x6e\x64\x2f\160\x6d\160\162\55\163\x6d\141\154\x6c"; const aoceigukcccyimew = "\160\x6d\x70\162\x2f\61\57\142\x72\141\x6e\144\x2f\x63\154\157\165\144\x66\x6c\141\x72\145"; }
