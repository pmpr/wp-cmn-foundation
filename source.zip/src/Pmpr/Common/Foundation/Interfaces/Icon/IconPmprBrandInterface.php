<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671269d4e15e3             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\x6d\160\x72\x2f\61\57\142\x72\x61\156\144\x2f\160\155\160\x72\x2d\x73\155\141\154\x6c"; const aoceigukcccyimew = "\160\155\x70\162\57\61\57\x62\x72\141\156\x64\x2f\143\x6c\157\165\144\x66\x6c\x61\x72\x65"; }
