<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             679154a5c86d8             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\155\160\162\x2f\61\x2f\x62\x72\141\156\x64\57\x70\x6d\160\x72\55\x73\155\x61\x6c\154"; const aoceigukcccyimew = "\160\x6d\160\162\57\x31\57\x62\x72\x61\156\x64\57\143\154\157\x75\x64\x66\154\x61\162\x65"; }
