<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1e2ec7c9c7             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\x6d\x70\x72\57\61\x2f\142\162\x61\x6e\x64\57\x70\x6d\x70\162\x2d\163\155\141\x6c\x6c"; const aoceigukcccyimew = "\x70\x6d\160\x72\x2f\x31\x2f\x62\x72\x61\156\144\57\143\x6c\x6f\165\144\x66\x6c\141\162\x65"; }
