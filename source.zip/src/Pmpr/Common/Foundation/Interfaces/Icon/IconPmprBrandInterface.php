<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67235720c72e8             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\x70\155\160\x72\57\61\57\142\162\x61\156\144\57\x70\x6d\x70\162\x2d\x73\155\141\154\154"; const aoceigukcccyimew = "\x70\155\160\x72\57\x31\57\x62\162\141\x6e\144\x2f\x63\x6c\x6f\x75\144\x66\x6c\141\162\x65"; }
