<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             679574b80d243             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\x6d\160\162\57\61\57\142\x72\x61\x6e\x64\x2f\x70\x6d\160\x72\55\x73\x6d\141\154\x6c"; const aoceigukcccyimew = "\160\155\x70\x72\57\x31\57\142\x72\141\x6e\x64\57\x63\x6c\157\x75\144\x66\x6c\x61\162\x65"; }
