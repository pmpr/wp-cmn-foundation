<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec08eec428e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\x6d\x70\162\x2f\x31\57\142\162\141\156\144\x2f\x70\155\x70\162\55\163\155\x61\154\x6c"; const aoceigukcccyimew = "\x70\x6d\x70\162\57\61\x2f\142\162\141\x6e\144\x2f\x63\x6c\x6f\165\x64\146\x6c\x61\162\x65"; }
