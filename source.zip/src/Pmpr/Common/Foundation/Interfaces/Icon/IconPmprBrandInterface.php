<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67143a3375b94             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\x6d\160\x72\57\x31\57\142\162\x61\x6e\x64\57\x70\155\x70\162\55\x73\x6d\141\154\154"; const aoceigukcccyimew = "\160\x6d\x70\x72\57\61\57\142\x72\x61\156\x64\57\x63\154\x6f\x75\144\x66\154\x61\x72\145"; }
