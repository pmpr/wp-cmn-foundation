<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec0c5dc5dae             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Interfaces\Icon; interface IconPmprBrandInterface { const yqkugkuyygummmsk = "\160\x6d\160\162\x2f\x31\57\x62\x72\141\x6e\x64\57\160\x6d\x70\x72\x2d\x73\x6d\141\154\154"; const aoceigukcccyimew = "\160\155\160\162\57\61\57\x62\x72\141\156\144\57\x63\x6c\157\x75\144\146\154\x61\162\145"; }
