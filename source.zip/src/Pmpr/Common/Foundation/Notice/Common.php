<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ebf559ba6b4             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Notice; use Pmpr\Common\Foundation\Container\Container; abstract class Common extends Container { }
