<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             689e6bb423bb9             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Convert; abstract class Convert { }
