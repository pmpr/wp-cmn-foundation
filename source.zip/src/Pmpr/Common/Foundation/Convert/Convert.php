<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68ddc938571ad             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Convert; abstract class Convert { }
