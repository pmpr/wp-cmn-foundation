<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6751a903a9160             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Convert\Type; use Pmpr\Common\Foundation\Convert\Convert; abstract class Common extends Convert { }
