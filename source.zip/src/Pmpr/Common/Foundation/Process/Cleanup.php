<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670da38bb56b4             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\x70\x72\x5f\x71\165\x65\165\145\x5f\x63\154\x65\x61\156\x75\160\x5f\157\154\144\x5f\151\x74\x65\x6d\163"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\146\157\x75\x6e\144\141\164\151\x6f\x6e\137\x63\x6c\145\141\x6e\165\x70"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\155\151\x6e\x5f\x69\156\x69\x74", [$this, "\171\145\x79\x69\147\x75\171\x65\147\155\x6d\171\165\x73\x65\x61"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\163\161\x73\145\155\153\151\x6b\x6b\x69\141\x61\161\145\x69\147"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\155\151\144\x6e\151\x67\x68\x74"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
