<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f132f156703             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\160\162\x5f\x71\x75\145\165\x65\137\143\x6c\145\x61\x6e\165\160\137\x6f\x6c\x64\137\x69\164\x65\x6d\x73"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\146\x6f\x75\156\x64\141\164\151\x6f\x6e\x5f\x63\154\x65\141\156\165\160"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\155\151\x6e\x5f\151\x6e\x69\x74", [$this, "\171\145\171\151\147\165\x79\145\x67\155\x6d\171\x75\x73\x65\x61"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\x73\x71\x73\145\155\x6b\x69\x6b\153\151\x61\x61\x71\145\151\147"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\x6d\151\144\x6e\x69\147\150\164"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
