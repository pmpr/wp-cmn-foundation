<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e16aefd43f6             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\x70\x72\x5f\x71\165\145\165\x65\137\143\x6c\145\141\156\x75\x70\137\157\154\x64\137\x69\x74\145\x6d\163"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x66\x6f\x75\x6e\144\x61\164\151\x6f\156\137\143\x6c\x65\x61\156\x75\160"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\x6d\151\x6e\x5f\x69\x6e\151\164", [$this, "\171\x65\171\151\x67\x75\171\x65\x67\155\155\x79\165\163\x65\x61"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\x73\x71\163\145\x6d\153\x69\153\153\151\x61\x61\161\145\151\147"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\155\x69\144\156\151\147\x68\x74"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
