<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae85ba078b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\x70\x72\x5f\x71\165\145\x75\x65\x5f\143\x6c\x65\x61\x6e\x75\x70\137\157\154\x64\x5f\x69\164\x65\155\x73"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x66\157\165\x6e\144\141\164\x69\157\x6e\137\143\154\x65\x61\x6e\x75\x70"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\x64\x6d\x69\x6e\x5f\151\156\151\164", [$this, "\171\145\171\151\x67\165\171\x65\x67\155\x6d\x79\x75\163\x65\141"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\163\x71\x73\x65\x6d\153\151\153\x6b\151\x61\x61\161\x65\x69\147"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\x6d\x69\x64\156\x69\x67\150\x74"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
