<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ced35949c89             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\x70\x72\x5f\x71\165\x65\x75\145\137\143\x6c\145\x61\156\x75\160\x5f\x6f\x6c\x64\137\151\x74\x65\x6d\163"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\146\157\x75\156\144\x61\x74\x69\x6f\x6e\x5f\143\x6c\145\141\156\x75\x70"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\x64\x6d\x69\x6e\x5f\151\x6e\x69\x74", [$this, "\x79\x65\171\151\x67\x75\171\x65\x67\155\155\171\165\163\145\141"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\x73\161\x73\145\155\153\x69\153\153\151\x61\141\x71\145\151\147"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\155\x69\144\156\x69\x67\x68\x74"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
