<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670dbd405b5c8             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\x70\x72\137\x71\x75\x65\x75\145\x5f\143\x6c\145\x61\x6e\165\160\x5f\157\x6c\x64\x5f\151\164\145\x6d\163"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x66\157\x75\x6e\144\141\x74\x69\x6f\x6e\137\x63\154\145\141\156\165\160"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\x64\x6d\x69\x6e\137\x69\x6e\151\x74", [$this, "\x79\x65\x79\151\147\165\x79\x65\x67\x6d\x6d\171\x75\x73\x65\141"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\x73\x71\x73\x65\155\153\151\153\153\151\x61\x61\161\x65\x69\147"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\x6d\151\144\156\151\x67\x68\164"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
