<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1d819504ee             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\x70\162\137\x71\x75\145\x75\145\137\143\154\x65\141\x6e\x75\160\137\157\154\144\137\x69\x74\145\x6d\x73"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\146\157\x75\x6e\x64\x61\164\x69\157\156\x5f\143\x6c\145\x61\156\x75\x70"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\x6d\x69\156\137\151\156\x69\164", [$this, "\x79\x65\171\x69\147\x75\x79\145\147\155\x6d\x79\x75\163\145\x61"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\x73\161\x73\145\155\x6b\x69\x6b\x6b\151\x61\x61\x71\145\x69\147"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\x6d\151\x64\x6e\151\x67\150\x74"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
