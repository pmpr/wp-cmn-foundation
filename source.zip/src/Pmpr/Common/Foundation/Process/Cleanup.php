<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f6c272cccf4             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\x70\x72\137\x71\x75\x65\165\x65\137\143\154\145\x61\156\x75\160\137\x6f\x6c\144\x5f\x69\164\145\155\163"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x66\157\x75\x6e\144\x61\164\151\x6f\156\137\143\154\x65\x61\156\165\160"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\x64\155\151\156\137\x69\156\151\164", [$this, "\171\x65\x79\151\147\165\x79\145\147\155\155\171\x75\x73\x65\x61"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\163\x71\163\x65\155\x6b\x69\153\153\x69\x61\x61\161\145\151\147"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\x6d\x69\x64\156\x69\x67\150\x74"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
