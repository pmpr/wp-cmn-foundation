<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675fac6c7c17d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\160\162\137\x71\165\145\165\x65\137\143\x6c\145\x61\156\165\160\x5f\x6f\x6c\144\137\x69\x74\x65\x6d\x73"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\146\157\165\x6e\x64\x61\x74\151\157\156\137\143\154\145\141\156\x75\x70"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\x64\x6d\151\x6e\x5f\151\x6e\151\164", [$this, "\x79\145\x79\x69\147\165\x79\145\147\155\x6d\x79\165\163\145\x61"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\x73\x71\163\145\x6d\153\x69\153\x6b\151\141\141\161\145\x69\x67"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\x6d\151\144\x6e\151\147\150\x74"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
