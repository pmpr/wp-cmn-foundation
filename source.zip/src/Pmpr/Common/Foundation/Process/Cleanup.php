<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ced75618540             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\160\162\x5f\x71\x75\145\x75\x65\x5f\x63\x6c\x65\x61\156\165\x70\x5f\x6f\154\144\x5f\151\x74\145\155\x73"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\146\157\x75\x6e\x64\141\164\151\x6f\x6e\x5f\143\x6c\x65\141\x6e\x75\x70"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\155\x69\x6e\x5f\151\x6e\151\x74", [$this, "\171\145\171\151\x67\x75\x79\145\x67\155\x6d\x79\x75\x73\x65\141"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\163\161\x73\145\x6d\x6b\151\x6b\153\x69\141\x61\x71\145\151\147"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\155\x69\144\x6e\x69\x67\150\164"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
