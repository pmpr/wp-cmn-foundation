<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d8c7809438d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\160\162\137\161\165\x65\165\x65\x5f\x63\154\145\x61\x6e\x75\160\x5f\x6f\x6c\144\x5f\x69\164\x65\155\x73"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x66\157\x75\x6e\144\141\164\151\157\x6e\x5f\143\154\145\x61\x6e\165\x70"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\x64\x6d\x69\x6e\x5f\151\156\151\x74", [$this, "\171\x65\171\151\147\x75\171\145\x67\x6d\155\x79\165\163\145\x61"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\x73\161\x73\145\155\153\151\153\153\x69\x61\x61\x71\x65\151\x67"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\155\x69\144\x6e\151\x67\x68\164"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
