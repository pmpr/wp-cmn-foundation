<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716d8b4c5936             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\x70\x72\137\x71\165\x65\165\145\137\x63\154\145\x61\156\x75\160\137\x6f\x6c\x64\x5f\151\x74\145\x6d\x73"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x66\x6f\165\x6e\x64\x61\x74\x69\157\x6e\137\x63\154\145\141\156\x75\160"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\x64\155\151\156\137\151\156\151\164", [$this, "\171\x65\x79\x69\147\165\171\145\147\x6d\x6d\x79\165\163\145\x61"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\163\x71\x73\x65\x6d\153\x69\x6b\x6b\x69\141\x61\x71\145\x69\x67"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\155\x69\144\156\151\x67\150\164"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
