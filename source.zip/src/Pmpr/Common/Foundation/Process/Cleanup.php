<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d2f79b4e2f3             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\x70\162\137\161\165\x65\165\145\137\143\154\145\x61\156\165\160\x5f\x6f\154\144\137\151\164\145\155\x73"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\146\157\165\156\144\x61\164\151\x6f\156\137\143\154\x65\x61\156\165\160"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\x6d\151\x6e\137\151\x6e\151\x74", [$this, "\x79\145\x79\x69\147\165\x79\x65\x67\155\x6d\x79\x75\163\x65\141"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\163\161\163\145\155\x6b\x69\153\153\151\141\x61\x71\145\x69\x67"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\155\151\x64\156\151\x67\x68\164"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
