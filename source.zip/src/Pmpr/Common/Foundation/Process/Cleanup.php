<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d303622917b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\x70\162\x5f\161\x75\x65\x75\x65\137\x63\154\x65\141\x6e\x75\x70\x5f\x6f\x6c\x64\137\151\x74\x65\x6d\x73"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\146\x6f\x75\156\144\x61\164\x69\x6f\x6e\x5f\x63\x6c\145\x61\156\165\x70"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\155\x69\156\x5f\151\x6e\x69\x74", [$this, "\171\x65\x79\x69\x67\165\x79\145\x67\x6d\x6d\x79\x75\x73\145\x61"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\x73\161\x73\145\155\153\151\x6b\x6b\151\x61\x61\x71\x65\x69\147"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\155\x69\144\x6e\x69\147\x68\x74"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
