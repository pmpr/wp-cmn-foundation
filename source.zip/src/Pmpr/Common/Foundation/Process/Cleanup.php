<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6714d8c066478             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\x70\x72\137\161\165\145\x75\x65\137\143\154\145\x61\x6e\165\x70\x5f\x6f\x6c\144\x5f\151\164\x65\155\x73"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x66\157\x75\156\x64\x61\x74\x69\157\156\x5f\x63\154\x65\141\x6e\x75\160"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\x64\x6d\151\156\137\x69\156\x69\164", [$this, "\171\145\x79\151\x67\165\x79\145\147\155\x6d\171\x75\x73\x65\x61"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\163\x71\163\x65\155\153\151\153\153\151\x61\x61\x71\x65\151\147"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\155\151\x64\156\x69\147\x68\x74"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
