<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             679576175075e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\x70\x72\x5f\x71\165\x65\x75\x65\137\143\154\x65\141\x6e\x75\160\x5f\x6f\154\144\x5f\151\164\145\x6d\x73"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\146\157\165\x6e\144\141\x74\x69\x6f\156\137\143\x6c\x65\141\156\165\160"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\x64\x6d\151\156\x5f\x69\156\x69\164", [$this, "\171\145\171\151\x67\165\x79\145\x67\155\x6d\x79\165\x73\145\141"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\163\161\x73\x65\x6d\x6b\x69\153\x6b\x69\x61\x61\x71\x65\151\x67"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\155\x69\144\x6e\x69\147\x68\164"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
