<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6791523fa4639             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\160\x72\x5f\x71\165\145\x75\145\137\143\x6c\145\141\156\165\x70\137\157\154\144\137\x69\x74\x65\x6d\163"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x66\x6f\x75\156\x64\141\164\151\157\x6e\137\143\x6c\x65\x61\156\x75\x70"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\x64\x6d\x69\x6e\x5f\151\x6e\x69\164", [$this, "\x79\145\x79\151\x67\x75\x79\145\147\x6d\x6d\171\x75\x73\145\x61"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\163\161\163\145\x6d\153\x69\153\153\x69\x61\x61\x71\145\151\x67"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\x6d\151\x64\156\151\x67\150\x74"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
