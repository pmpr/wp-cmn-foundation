<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675819f57c47e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\160\162\x5f\161\x75\x65\x75\x65\137\143\x6c\145\x61\x6e\x75\160\137\x6f\154\x64\137\151\164\x65\155\163"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x66\x6f\165\156\144\x61\x74\x69\x6f\156\x5f\143\x6c\145\141\x6e\165\x70"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\x64\155\151\x6e\137\x69\156\x69\x74", [$this, "\171\145\171\x69\x67\165\x79\x65\x67\155\x6d\x79\165\163\x65\x61"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\163\x71\x73\x65\155\x6b\x69\153\x6b\x69\141\x61\x71\145\151\x67"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\x6d\151\x64\x6e\x69\147\150\x74"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
