<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d31c5675355             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\160\x72\x5f\x71\165\x65\x75\145\x5f\x63\154\x65\x61\156\165\160\137\x6f\154\144\x5f\151\x74\145\155\x73"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x66\x6f\165\x6e\x64\x61\x74\x69\x6f\x6e\x5f\143\154\x65\141\x6e\x75\x70"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\155\x69\x6e\137\x69\x6e\x69\164", [$this, "\171\145\171\151\147\x75\x79\145\147\155\x6d\x79\165\x73\x65\141"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\163\161\163\x65\x6d\153\151\153\x6b\151\141\141\161\145\x69\147"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\155\151\x64\156\151\147\150\164"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
