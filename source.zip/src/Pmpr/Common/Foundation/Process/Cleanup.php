<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             679574b80d243             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\x70\x72\x5f\161\165\145\165\x65\137\143\x6c\145\141\156\165\x70\x5f\x6f\x6c\x64\x5f\x69\164\145\155\x73"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x66\x6f\x75\156\144\x61\x74\151\157\x6e\x5f\x63\154\145\x61\x6e\x75\160"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\x64\x6d\151\156\137\151\x6e\x69\164", [$this, "\x79\145\171\x69\147\165\171\145\147\155\x6d\171\165\163\145\141"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\x73\161\x73\145\155\153\151\x6b\x6b\x69\x61\x61\x71\x65\151\x67"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\x6d\151\144\x6e\x69\147\x68\164"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
