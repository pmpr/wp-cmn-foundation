<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67abce98c052e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\x70\x72\137\x71\165\145\x75\145\x5f\x63\x6c\x65\141\x6e\165\160\x5f\157\154\144\137\x69\164\x65\155\x73"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\146\157\165\156\144\141\x74\x69\x6f\156\137\143\x6c\145\141\156\x75\160"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\155\151\x6e\x5f\151\x6e\x69\x74", [$this, "\x79\145\171\151\147\x75\171\x65\147\x6d\x6d\171\165\x73\145\x61"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\x73\161\x73\145\155\153\x69\153\x6b\x69\x61\141\x71\x65\x69\x67"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\x6d\x69\144\156\x69\x67\x68\x74"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
