<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebdb08957             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\160\162\137\x71\x75\x65\165\145\x5f\143\x6c\145\141\x6e\165\x70\x5f\157\154\x64\x5f\x69\164\x65\x6d\163"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x66\x6f\x75\x6e\144\141\x74\x69\157\x6e\137\143\154\x65\141\156\x75\x70"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\x6d\151\x6e\137\x69\156\x69\164", [$this, "\171\x65\x79\x69\147\x75\x79\145\x67\155\x6d\171\165\x73\145\x61"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\163\161\x73\x65\x6d\153\x69\153\x6b\151\141\141\161\x65\x69\x67"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\155\151\144\x6e\151\147\x68\x74"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
