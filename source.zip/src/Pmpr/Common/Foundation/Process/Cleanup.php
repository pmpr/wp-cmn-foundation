<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f16aff73538             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Foundation\Process; class Cleanup extends Queue { const ekqmweaocsoswsmc = "\160\162\x5f\161\165\x65\x75\145\x5f\x63\x6c\145\x61\156\165\160\x5f\x6f\154\x64\137\151\164\145\155\x73"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\146\157\x75\156\144\141\164\151\x6f\x6e\137\143\154\145\141\x6e\x75\160"; } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\155\x69\x6e\x5f\151\x6e\x69\164", [$this, "\171\x65\x79\151\x67\165\171\x65\147\155\x6d\x79\x75\x73\145\141"])->qcsmikeggeemccuu(self::ekqmweaocsoswsmc, [$this, "\x73\161\163\x65\x6d\153\x69\153\153\x69\141\x61\161\145\x69\x67"]); } public function yeyiguyegmmyusea() { return $this->ooosmymooksgmyos(strtotime("\x6d\x69\144\x6e\x69\147\x68\164"), DAY_IN_SECONDS, self::ekqmweaocsoswsmc); } public function sqsemkikkiaaqeig() { } }
